console.log("✅ Email Header Editor loaded");

/* =======================
WAIT FOR ELEMENT (GENERIC)
======================= */
function waitFor(fn, callback) {
  const interval = setInterval(() => {
    const result = fn();
    if (result) {
      clearInterval(interval);
      callback(result);
    }
  }, 300);
}

/* =======================
HEADER PARSER (RFC SAFE)
======================= */
function parseHeadersPreserveFolding(headerText) {
  const lines = headerText.split(/\r?\n/);
  const headers = [];
  let current = "";
  lines.forEach(line => {
    if (/^[ \t]/.test(line)) {
      current += "\n" + line;
    } else {
      if (current) headers.push(current);
      current = line;
    }
  });
  if (current) headers.push(current);
  return headers;
}

/* =======================
INIT UI (BETWEEN HEADERS)
======================= */
waitFor(() => {
  const h4s = [...document.querySelectorAll("h4")];
  const receivedTitle = h4s.find(h =>
    h.textContent.replace(/\s+/g, " ").toLowerCase().includes("received")
  );
  if (!receivedTitle) return null;
  const receivedRow = receivedTitle.closest(".row");
  return receivedRow || null;
}, (receivedRow) => {
  if (document.getElementById("email-header-editor")) return;
  const wrapper = document.createElement("div");
  wrapper.id = "email-header-editor";
  wrapper.className = "row";
  wrapper.style.margin = "10px 0";
  wrapper.innerHTML = `
    <div class="col-lg-12">
      <div class="panel panel-default" style="padding:15px;">
        <h4 style="margin-top:0;">
          <i class="fa fa-list-ul"></i> Change Header Parameters
        </h4>
        <div class="row">
          <div class="col-lg-4">
            <label>From (domain only)</label>
            <input class="form-control input-sm" id="hFrom">
          </div>
          <div class="col-lg-4">
            <label>Sender (domain only)</label>
            <input class="form-control input-sm" id="hSender">
          </div>
          <div class="col-lg-4">
            <label>Subject</label>
            <input class="form-control input-sm" id="hSubject">
          </div>
        </div>

        <div class="row" style="margin-top:8px;">
          <div class="col-lg-4">
            <label>To</label>
            <input class="form-control input-sm" id="hTo">
          </div>
          <div class="col-lg-4">
            <label>Cc</label>
            <input class="form-control input-sm" id="hCc">
          </div>
          <div class="col-lg-4">
            <label>Date</label>
            <input class="form-control input-sm" id="hDate">
          </div>
        </div>

        <div class="row" style="margin-top:10px;">
          <div class="col-lg-12">
            <label>Allowed Headers (semicolon separated)</label>
            <textarea id="allowedHeadersInput" class="form-control input-sm" rows="4">Received;X-Received;Content-Type;Date;From;Mime-Version;Message-ID;Subject;Feedback-ID;List-Unsubscribe;List-Unsubscribe-Post;Precedence;X-Report-Abuse;X-Report-Spam;X-SG-EID;X-SG-ID;To;X-Entity-ID;Sender;Content-Transfer-Encoding;Cc</textarea>
          </div>
        </div>

        <div class="row" style="margin-top:10px;">
          <div class="col-lg-12">
            <label>Custom Headers (one per line: Header: value)</label>
            <textarea id="customHeadersInput" class="form-control input-sm" rows="3" placeholder="Return-Path: bounce@example.com &#10;Delivered-To: user@example.com"></textarea>
          </div>
        </div>

        <!-- ✅ NEW: Links Remover Checkbox -->
        <div class="row" style="margin-top:10px;">
          <div class="col-lg-12">
            <label style="cursor:pointer; font-weight:normal;">
              <input type="checkbox" id="removeLinks" style="margin-right:5px; margin-top:3px;"> Links Remover
            </label>
          </div>
        </div>

        <div class="text-right" style="margin-top:12px;">
          <button id="applyHeader" type="button" class="btn btn-success btn-sm">
            <i class="fa fa-check"></i> Change
          </button>
        </div>
      </div>
    </div>
  `;
  // ✅ INSERT BETWEEN Header(s) and Received(s)
  receivedRow.parentNode.insertBefore(wrapper, receivedRow);
  document.getElementById("applyHeader").addEventListener("click", applyChanges);
});

/* =======================
APPLY HEADER CHANGES
======================= */
function applyChanges(e) {
  e.preventDefault();
  e.stopPropagation();
  const textareas = document.querySelectorAll("textarea.header");
  if (!textareas.length) {
    alert("No header textarea found!");
    return;
  }

  const allowedHeaders = document.getElementById("allowedHeadersInput").value
    .split(";").map(h => h.trim().toLowerCase()).filter(Boolean);

  const customHeaders = document.getElementById("customHeadersInput").value
    .split("\n").map(l => l.trim()).filter(l => l.includes(":"))
    .map(l => {
      const [name, ...rest] = l.split(":");
      return { name: name.trim(), value: rest.join(":").trim() };
    });

  const values = {
    From: document.getElementById("hFrom").value.trim(),
    Sender: document.getElementById("hSender").value.trim(),
    Subject: document.getElementById("hSubject").value.trim(),
    To: document.getElementById("hTo").value.trim(),
    Cc: document.getElementById("hCc").value.trim(),
    Date: document.getElementById("hDate").value.trim()
  };

  const removeLinks = document.getElementById("removeLinks").checked;

  textareas.forEach(textarea => {
    const parts = textarea.value.split(/\r?\n\r?\n/);
    const headerPart = parts.shift() || "";
    let bodyPart = parts.join("\n\n");

    let headers = parseHeadersPreserveFolding(headerPart)
      .filter(h => {
        const name = h.split(":")[0]?.trim().toLowerCase();
        return allowedHeaders.includes(name);
      });

    const fromIndex = headers.findIndex(h => h.toLowerCase().startsWith("from:"));

    // Message-ID → add [EID]
    headers = headers.map(h => {
      if (!h.toLowerCase().startsWith("message-id:")) return h;
      if (h.includes("[EID]")) return h;
      return h.replace(/<([^@>]+)@/, (_, id) => `<${id.slice(0, 8)}[EID]${id.slice(8)}@`);
    });

    Object.keys(values).forEach(key => {
      if (!values[key]) return;
      const idx = headers.findIndex(h => h.toLowerCase().startsWith(key.toLowerCase() + ":"));
      if (key === "Sender" && idx === -1) return;
      if (idx !== -1) {
        if (key === "From" || key === "Sender") {
          headers[idx] = headers[idx].replace(/@[^>\s]+/, "@" + values[key]);
        } else {
          headers[idx] = `${key}: ${values[key]}`;
        }
      } else {
        const line = `${key}: ${values[key]}`;
        if (fromIndex !== -1) headers.splice(fromIndex + 1, 0, line);
        else headers.push(line);
      }
    });

    customHeaders.forEach(({ name, value }) => {
      const lname = name.toLowerCase();
      const idx = headers.findIndex(h => h.toLowerCase().startsWith(lname + ":"));
      const line = `${name}: ${value}`;
      if (idx !== -1) headers[idx] = line;
      else if (fromIndex !== -1) headers.splice(fromIndex + 1, 0, line);
      else headers.push(line);
    });

    // ✅ Links Remover (QP & Folding Safe)
    if (removeLinks && bodyPart) {
      bodyPart = bodyPart.replace(/(<a\b[^>]*?\bhref\s*=\s*(?:3D)?\s*)["'][^"']*["']/gi, '$1""');
    }

    textarea.value = bodyPart
      ? headers.join("\n") + "\n\n" + bodyPart
      : headers.join("\n");
  });
}