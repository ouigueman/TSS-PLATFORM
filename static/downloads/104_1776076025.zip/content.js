// ── Firefox MV2 compatibility shim ──────────────────────────
var browser = (typeof browser !== "undefined") ? browser : chrome;

// ===============================
// KEEP-ALIVE SYSTEM
// ===============================
let _keepAliveInterval = null;
let _isProcessRunning  = false;

// ===============================
// PROCESS CONTROL STATE
// ===============================
let _processState         = "running";
let _resumeResolvers      = [];
let _pausedCountdownSecs  = null;
let _pausedCountdownLabel = null;
let _pausedCountdownDrop  = null;
let _pausedCountdownTotal = null;
let _pauseStartedAt       = null;   // wall-clock ms when the process was paused

// Notifiers woken up immediately on any state change (pause/stop/resume).
// Used by wait() to break out of sleep early.
let _stateChangeNotifiers = [];

function _notifyStateChange() {
    const notifiers = _stateChangeNotifiers.splice(0);
    notifiers.forEach(r => r());
}

class ProcessStoppedError extends Error {
    constructor() { super("Process stopped by user."); this.name = "ProcessStoppedError"; }
}

async function checkPauseOrStop() {
    if (_processState === "stopped") throw new ProcessStoppedError();
    if (_processState === "paused") {
        console.log('[Control] Process paused — waiting for resume…');
        await new Promise(resolve => _resumeResolvers.push(resolve));
        if (_processState === "stopped") throw new ProcessStoppedError();
    }
}

function startKeepAlive() {
    if (_keepAliveInterval) return;
    _isProcessRunning = true;
    console.log('[KeepAlive] Starting (setInterval only)…');
    _keepAliveInterval = setInterval(() => {
        if (!_isProcessRunning) return;
        browser.runtime.sendMessage({ type: "HEARTBEAT", timestamp: Date.now() })
            .catch(() => {});
    }, 5000);
}

function stopKeepAlive() {
    _isProcessRunning = false;
    if (_keepAliveInterval) {
        clearInterval(_keepAliveInterval);
        _keepAliveInterval = null;
    }
    console.log('[KeepAlive] Stopped.');
}

// ===============================
// TELEGRAM REMOTE STOP LISTENER
// ===============================
let _telegramListenerInterval = null;
let _lastTelegramUpdateId = null;

async function _initTelegramOffset() {
    try {
        const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUpdates?allowed_updates=["message"]`;
        const response = await fetch(url);
        const data = await response.json();
        if (data.ok && data.result.length > 0) {
            // Anchor to the latest existing update so old messages are never processed
            _lastTelegramUpdateId = data.result[data.result.length - 1].update_id;
        }
    } catch (err) {
        // Ignore — worst case we might catch one old message on the first poll
    }
}

async function checkTelegramStopCommand(chatId) {
    if (!chatId) return;
    try {
        let url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUpdates?allowed_updates=["message"]`;
        if (_lastTelegramUpdateId !== null) {
            url += `&offset=${_lastTelegramUpdateId + 1}`;
        }

        const response = await fetch(url);
        const data = await response.json();

        if (data.ok && data.result.length > 0) {
            for (const update of data.result) {
                _lastTelegramUpdateId = update.update_id;

                if (update.message && update.message.chat && String(update.message.chat.id) === String(chatId)) {
                    const text = (update.message.text || '').trim().toLowerCase();
                    if (text === 'stop') {
                        console.log('[Telegram Control] Stop command received via Telegram!');
                        if (typeof _handleStop === 'function') {
                            _handleStop();
                            stopTelegramListener(); // Stop polling after triggering
                        }
                    }
                }
            }
        }
    } catch (err) {
        // Ignore fetch errors to avoid crashing process or spamming logs
    }
}

function startTelegramListener(chatId) {
    if (_telegramListenerInterval) stopTelegramListener();
    _lastTelegramUpdateId = null;
    // Fetch the current latest update_id BEFORE starting the poll loop so that
    // any "stop" messages sent during a previous session are never acted upon.
    _initTelegramOffset().then(() => {
        _telegramListenerInterval = setInterval(() => checkTelegramStopCommand(chatId), 5000);
        console.log('[Telegram Control] Listening for stop commands on chat:', chatId);
    });
}

function stopTelegramListener() {
    if (_telegramListenerInterval) {
        clearInterval(_telegramListenerInterval);
        _telegramListenerInterval = null;
        console.log('[Telegram Control] Stopped listening.');
    }
}

document.addEventListener('visibilitychange', () => {
    if (!document.hidden && _isProcessRunning) {
        console.log('[KeepAlive] Tab visible again — running safety cleanup…');
        _safeCleanupOrphanBackdrops();
    }
});

function _safeCleanupOrphanBackdrops() {
    const hasOpenModal =
        !!document.querySelector('.modal.in') ||
        !!document.querySelector('.modal.show');
    if (!hasOpenModal) {
        document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
        // Also hide any modal stuck at display:block without .in/.show
        document.querySelectorAll('.modal').forEach(el => {
            el.style.display = 'none';
            el.setAttribute('aria-hidden', 'true');
            el.removeAttribute('aria-modal');
        });
        document.body.classList.remove('modal-open');
        document.body.style.removeProperty('padding-right');
        document.body.style.removeProperty('overflow');
    }
}

function _forceCloseAllModals() {
    // Remove all backdrop overlays
    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());

    // Hide any modal still visible (display:block) regardless of .in/.show class
    // These invisible full-page overlays block all clicks and keyboard input
    document.querySelectorAll('.modal').forEach(el => {
        el.classList.remove('in', 'show', 'fade');
        el.style.cssText += ';display:none!important;';
        el.setAttribute('aria-hidden', 'true');
        el.removeAttribute('aria-modal');
    });

    // Restore body to fully interactive state.
    // Bootstrap 3 sets overflow:hidden + padding-right both via .modal-open class
    // AND as inline styles. We must clear both the class and the inline styles.
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('padding-right');
    document.body.style.removeProperty('overflow');

    // Belt-and-suspenders: if Bootstrap's transition callback fires AFTER us and
    // re-applies overflow:hidden, the MutationObserver in _startBodyGuardian()
    // will catch and undo it within one animation frame.
}

// ── Body guardian ─────────────────────────────────────────────
// Watches <body> for Bootstrap silently re-adding overflow:hidden or
// .modal-open while no modal is actually open, and immediately undoes it.
let _bodyGuardian = null;

function _startBodyGuardian() {
    if (_bodyGuardian) return;
    _bodyGuardian = new MutationObserver(() => {
        // Only act when there is no genuinely open modal
        const hasOpenModal =
            !!document.querySelector('.modal.in') ||
            !!document.querySelector('.modal.show');
        if (hasOpenModal) return;

        let fixed = false;
        if (document.body.classList.contains('modal-open')) {
            document.body.classList.remove('modal-open');
            fixed = true;
        }
        if (document.body.style.overflow === 'hidden') {
            document.body.style.removeProperty('overflow');
            fixed = true;
        }
        if (fixed) {
            // Also sweep any leftover backdrops
            document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
        }
    });
    _bodyGuardian.observe(document.body, {
        attributes      : true,
        attributeFilter : ['class', 'style']
    });
}

function _stopBodyGuardian() {
    if (_bodyGuardian) {
        _bodyGuardian.disconnect();
        _bodyGuardian = null;
    }
}

// Robust modal-close helper: clicks the button, waits for the modal AND
// backdrop to vanish, then calls _forceCloseAllModals() as a safety net.
// Returns after everything is gone (or after maxWaitMs at the latest).
async function _closeModalAndWait(closeBtn, maxWaitMs = 10000) {
    if (closeBtn) closeBtn.click();

    const INTERVAL = 200;
    const deadline = Date.now() + maxWaitMs;
    await new Promise(resolve => {
        const t = setInterval(() => {
            const modal    = document.querySelector('.modal.in, .modal.show');
            const backdrop = document.querySelector('.modal-backdrop');
            if ((!modal && !backdrop) || Date.now() >= deadline) {
                clearInterval(t);
                resolve();
            }
        }, INTERVAL);
    });

    // Final sweep — clears anything Bootstrap left behind
    _forceCloseAllModals();

    // Give Bootstrap's own JS one tick to finish, then verify body is clean
    await new Promise(r => setTimeout(r, 120));
    _forceCloseAllModals();
}

// ===============================
// Utilities
// ===============================

// Interruptible wait — resolves early when paused or stopped so that
// checkPauseOrStop() can react at the next await point without waiting
// for the full delay to elapse.
function wait(ms) {
    if (ms <= 0) return Promise.resolve();
    return new Promise(resolve => {
        let timer = null;
        const notifier = () => { clearTimeout(timer); resolve(); };
        _stateChangeNotifiers.push(notifier);
        timer = setTimeout(() => {
            const idx = _stateChangeNotifiers.indexOf(notifier);
            if (idx !== -1) _stateChangeNotifiers.splice(idx, 1);
            resolve();
        }, ms);
    });
}

function randomDelay(min = 8000, max = 12000) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ── Core interruptible poll loop ──────────────────────────────
// Polls `condition()` every `interval` ms, honouring pause/stop.
// Throws ProcessStoppedError instantly on stop.
// Blocks (without ticking elapsed) while paused, then resumes polling.
async function _pollUntil(condition, interval, timeout, timeoutMsg) {
    let elapsed = 0;
    while (true) {
        if (_processState === 'stopped') throw new ProcessStoppedError();
        if (_processState === 'paused') {
            // Block until resumed or stopped; don't tick elapsed while paused
            await new Promise(r => _resumeResolvers.push(r));
            if (_processState === 'stopped') throw new ProcessStoppedError();
            continue;
        }
        const result = condition();
        if (result) return result;
        elapsed += interval;
        if (elapsed >= timeout) throw new Error(timeoutMsg);
        await new Promise(resolve => {
            let t = null;
            const notifier = () => { clearTimeout(t); resolve(); };
            _stateChangeNotifiers.push(notifier);
            t = setTimeout(() => {
                const idx = _stateChangeNotifiers.indexOf(notifier);
                if (idx !== -1) _stateChangeNotifiers.splice(idx, 1);
                resolve();
            }, interval);
        });
    }
}

function waitForElement(selector, timeout = 30000) {
    return _pollUntil(
        () => document.querySelector(selector),
        300, timeout, "Element not found: " + selector
    );
}

function waitForElementVisible(selector, timeout = 30000) {
    return _pollUntil(
        () => { const el = document.querySelector(selector); return (el && !el.disabled) ? el : null; },
        300, timeout, "Element not found / disabled: " + selector
    );
}

function waitForCommandItem(text, timeout = 30000) {
    return _pollUntil(
        () => Array.from(document.querySelectorAll(".ms-list .ms-elem-selectable")).find(el => el.innerText.trim() === text) || null,
        300, timeout, "Command item not found: " + text
    );
}

function waitForChildElement(parent, selector, timeout = 30000) {
    return _pollUntil(
        () => parent.querySelector(selector),
        300, timeout, "Child element not found: " + selector
    );
}

function waitForModalReady(timeout = 90000) {
    return _pollUntil(
        () => {
            const modal = document.querySelector(".modal.in, .modal.show");
            if (!modal) return null;
            return (modal.querySelector(".modal-content") || modal.querySelector(".modal-body")) ? modal : null;
        },
        400, timeout, "Modal did not become ready."
    );
}

async function safeClickChild(parent, selector, extraWait = 400) {
    const el = await waitForChildElement(parent, selector);
    await wait(extraWait);
    el.click();
    return el;
}

async function executeRunCommandModal(label, repeatClicks = 1) {
    const form = await waitForElement('#run-cmd-form', 30000);

    const chk = await waitForElementVisible('#check-cmd-by-server', 15000);
    if (!chk.checked) { chk.click(); await wait(600); }

    const submitBtn = await waitForChildElement(form, "button[type='submit']", 15000);
    await wait(800);

    // First click
    submitBtn.click();
    if (label) sendStatus(`${label} — executing… (click 1/${repeatClicks})`);

    // Extra clicks spaced 5 s apart
    for (let i = 2; i <= repeatClicks; i++) {
        await wait(5000);
        submitBtn.click();
        if (label) sendStatus(`${label} — executing… (click ${i}/${repeatClicks})`);
    }

    const dismissBtn = await new Promise(resolve => {
        const TIMEOUT  = 90000;
        const INTERVAL = 500;
        let elapsed = 0;
        const timer = setInterval(() => {
            const btn =
                form.querySelector("button[data-dismiss='modal']") ||
                document.querySelector(".modal.in button[data-dismiss='modal']") ||
                document.querySelector(".modal.show button[data-dismiss='modal']");
            if (btn) { clearInterval(timer); resolve(btn); return; }
            elapsed += INTERVAL;
            if (elapsed >= TIMEOUT) { clearInterval(timer); resolve(null); }
        }, INTERVAL);
    });

    await wait(6000);

    await _closeModalAndWait(dismissBtn, 10000);
    await wait(800);
}

function sendStatus(text) {
    browser.runtime.sendMessage({ type: "STATUS_UPDATE", text });
}

function bgMessage(msg) {
    return new Promise(resolve => browser.runtime.sendMessage(msg, resolve));
}

function fmtTime(s) {
    const h   = Math.floor(s / 3600);
    const m   = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return h + 'h ' + String(m).padStart(2,'0') + 'm ' + String(sec).padStart(2,'0') + 's';
    if (m > 0) return m + 'm ' + String(sec).padStart(2,'0') + 's';
    return sec + 's';
}

let _deployTabId      = null;
let _telegramChatId   = null;
let _effectiveProcessType = null;
let _ipServerMap      = {};

// ===============================
// OVERLAY CARD UI
// ===============================

let _overlayEl      = null;
let _countdownTimer = null;
let _mainCard       = null;

function ensureOverlay() {
    if (document.getElementById('__deploy_overlay__')) {
        _overlayEl = document.getElementById('__deploy_overlay__');
        return;
    }
    const style = document.createElement('style');
    style.id = '__deploy_styles__';
    style.textContent = `
        #__deploy_overlay__ {
            position:fixed; top:20px; right:20px; z-index:999999; width:320px;
            font-family:'Segoe UI',system-ui,sans-serif;
            display:flex; flex-direction:column; gap:10px; pointer-events:none;
        }
        .deploy-card {
            background:linear-gradient(135deg,#1a1f35 0%,#242b45 100%);
            border:1px solid rgba(255,255,255,0.08); border-radius:14px; padding:14px 16px;
            box-shadow:0 8px 32px rgba(0,0,0,0.45),0 1px 0 rgba(255,255,255,0.06) inset;
            color:#e8eaf0; pointer-events:all;
            animation:deployCardIn 0.3s cubic-bezier(0.34,1.56,0.64,1);
        }
        @keyframes deployCardIn {
            from{opacity:0;transform:translateX(40px) scale(0.95);}
            to  {opacity:1;transform:translateX(0)    scale(1);}
        }
        .deploy-card.fade-out{animation:deployCardOut 0.35s ease forwards;}
        @keyframes deployCardOut{to{opacity:0;transform:translateX(40px) scale(0.93);}}
        .deploy-card .dc-header{display:flex;align-items:center;gap:8px;margin-bottom:9px;}
        .deploy-card .dc-icon{
            width:28px;height:28px;border-radius:8px;
            display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;
        }
        .deploy-card .dc-icon.blue  {background:rgba(59,130,246,0.22);}
        .deploy-card .dc-icon.green {background:rgba(34,197,94,0.2);}
        .deploy-card .dc-icon.amber {background:rgba(245,158,11,0.2);}
        .deploy-card .dc-icon.red   {background:rgba(239,68,68,0.2);}
        .deploy-card .dc-icon.purple{background:rgba(168,85,247,0.2);}
        .deploy-card .dc-title{
            font-size:11px;font-weight:700;letter-spacing:0.07em;text-transform:uppercase;color:#94a3b8;
        }
        .deploy-card .dc-badge{
            margin-left:auto;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;
            background:rgba(255,255,255,0.08);color:#94a3b8;letter-spacing:0.04em;white-space:nowrap;
        }
        .deploy-card .dc-body{font-size:13px;color:#cbd5e1;line-height:1.55;}
        .deploy-card .dc-body strong{color:#f1f5f9;}
        .deploy-card .dc-progress-wrap{
            margin-top:10px;background:rgba(255,255,255,0.06);border-radius:6px;overflow:hidden;height:5px;
        }
        .deploy-card .dc-progress-bar{height:100%;border-radius:6px;transition:width 0.6s ease;}
        .deploy-card .dc-progress-bar.blue  {background:linear-gradient(90deg,#3b82f6,#60a5fa);}
        .deploy-card .dc-progress-bar.green {background:linear-gradient(90deg,#22c55e,#4ade80);}
        .deploy-card .dc-progress-bar.amber {background:linear-gradient(90deg,#f59e0b,#fbbf24);}
        .deploy-card .dc-progress-bar.purple{background:linear-gradient(90deg,#a855f7,#c084fc);}
        .deploy-card .dc-progress-bar.red   {background:linear-gradient(90deg,#ef4444,#f87171);}

        /* ── Process control bar ───────────────────────────────── */
        #__deploy_ctrl_bar__ {
            display:flex; gap:8px;
            background:linear-gradient(135deg,#1a1f35 0%,#242b45 100%);
            border:1px solid rgba(255,255,255,0.08); border-radius:14px; padding:10px 14px;
            box-shadow:0 8px 32px rgba(0,0,0,0.45);
            pointer-events:all;
            animation:deployCardIn 0.3s cubic-bezier(0.34,1.56,0.64,1);
        }
        #__deploy_ctrl_bar__ button {
            flex:1; padding:8px 6px; border:none; border-radius:9px;
            font-size:11px; font-weight:700; cursor:pointer; letter-spacing:0.04em;
            transition:opacity 0.15s, transform 0.1s;
            font-family:'Segoe UI',system-ui,sans-serif;
        }
        #__deploy_ctrl_bar__ button:hover  { opacity:0.85; transform:translateY(-1px); }
        #__deploy_ctrl_bar__ button:active { transform:translateY(0); }
        #__ctrl_pause_btn__ {
            background:linear-gradient(135deg,#f59e0b,#fbbf24);
            color:#1a1000;
            box-shadow:0 3px 10px rgba(245,158,11,0.35);
        }
        #__ctrl_resume_btn__ {
            background:linear-gradient(135deg,#22c55e,#4ade80);
            color:#001a00;
            box-shadow:0 3px 10px rgba(34,197,94,0.35);
            display:none;
        }
        #__ctrl_stop_btn__ {
            background:linear-gradient(135deg,#ef4444,#f87171);
            color:#fff;
            box-shadow:0 3px 10px rgba(239,68,68,0.35);
        }
        #__deploy_ctrl_bar__.paused #__ctrl_pause_btn__  { display:none; }
        #__deploy_ctrl_bar__.paused #__ctrl_resume_btn__ { display:block; }
        #__deploy_pause_banner__ {
            display:none;
            background:linear-gradient(135deg,#1a1f35,#242b45);
            border:1px solid rgba(245,158,11,0.4);
            border-radius:14px; padding:12px 15px;
            box-shadow:0 8px 32px rgba(0,0,0,0.45);
            pointer-events:all;
            animation:deployCardIn 0.3s cubic-bezier(0.34,1.56,0.64,1);
        }
        #__deploy_pause_banner__.visible { display:block; }
        #__deploy_pause_banner__ .pb-title {
            font-size:11px; font-weight:700; letter-spacing:0.07em;
            text-transform:uppercase; color:#fbbf24; margin-bottom:5px;
        }
        #__deploy_pause_banner__ .pb-body {
            font-size:12px; color:#cbd5e1; line-height:1.5;
        }
        #__deploy_pause_banner__ .pb-body strong { color:#f1f5f9; }
    `;
    if (!document.getElementById('__deploy_styles__')) document.head.appendChild(style);
    const overlay = document.createElement('div');
    overlay.id = '__deploy_overlay__';
    document.body.appendChild(overlay);
    _overlayEl = overlay;
}

function getOverlay() { ensureOverlay(); return _overlayEl; }

function ensureControlBar() {
    if (document.getElementById('__deploy_ctrl_bar__')) return;
    const overlay = getOverlay();

    const banner = document.createElement('div');
    banner.id = '__deploy_pause_banner__';
    banner.innerHTML = `<div class="pb-title">⏸ Process Paused</div><div class="pb-body" id="__pb_body__">Waiting for resume…</div>`;
    overlay.appendChild(banner);

    const bar = document.createElement('div');
    bar.id = '__deploy_ctrl_bar__';
    bar.innerHTML = `
        <button id="__ctrl_pause_btn__">⏸&nbsp; Pause</button>
        <button id="__ctrl_resume_btn__">▶&nbsp; Resume</button>
        <button id="__ctrl_stop_btn__">🛑&nbsp; Stop</button>`;
    overlay.appendChild(bar);

    document.getElementById('__ctrl_pause_btn__').addEventListener('click', () => _handlePause());
    document.getElementById('__ctrl_resume_btn__').addEventListener('click', () => _handleResume());
    document.getElementById('__ctrl_stop_btn__').addEventListener('click', () => _handleStop());
}

function _setControlBarPaused(isPaused) {
    const bar = document.getElementById('__deploy_ctrl_bar__');
    if (!bar) return;
    if (isPaused) bar.classList.add('paused');
    else          bar.classList.remove('paused');
}

function _showPauseBanner(bodyHTML) {
    const banner = document.getElementById('__deploy_pause_banner__');
    if (!banner) return;
    banner.classList.add('visible');
    const body = document.getElementById('__pb_body__');
    if (body) body.innerHTML = bodyHTML;
}

function _hidePauseBanner() {
    const banner = document.getElementById('__deploy_pause_banner__');
    if (banner) banner.classList.remove('visible');
}

function removeControlBar() {
    const bar    = document.getElementById('__deploy_ctrl_bar__');
    const banner = document.getElementById('__deploy_pause_banner__');
    if (bar)    { bar.classList.add('fade-out');    setTimeout(() => bar.remove(),    380); }
    if (banner) { banner.classList.add('fade-out'); setTimeout(() => banner.remove(), 380); }
}

async function _sendTelegramControlMsg(action, extra = '') {
    if (!_telegramChatId) return;
    const now  = new Date();
    const pad  = n => String(n).padStart(2, '0');
    const dt   = `${pad(now.getDate())}-${pad(now.getMonth()+1)}-${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    const div  = '='.repeat(38);

    let icon, title;
    if      (action === 'paused')  { icon = '⏸'; title = 'PROCESS PAUSED';  }
    else if (action === 'resumed') { icon = '▶️'; title = 'PROCESS RESUMED'; }
    else                           { icon = '🛑'; title = 'PROCESS STOPPED'; }

    const lines = [
        `${icon}  WARMUP CONTROLLER — ${title}`,
        div,
        `Date / Time  :  ${dt}`,
        div,
        extra,
        div,
        `This message was sent automatically by the Warmup Extension.`,
    ].filter(l => l !== '');

    const text = '```\n' + lines.join('\n') + '\n```';
    try {
        await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
            method  : 'POST',
            headers : { 'Content-Type': 'application/json' },
            body    : JSON.stringify({ chat_id: _telegramChatId, text, parse_mode: 'Markdown' })
        });
    } catch(e) { console.warn('[Control] Telegram control msg failed:', e); }
}

async function _handlePause() {
    if (_processState !== "running") return;
    _processState   = "paused";
    _pauseStartedAt = Date.now();
    _setControlBarPaused(true);

    // Wake all sleeping wait() / _pollUntil() calls immediately so they
    // can enter the paused-block inside checkPauseOrStop / _pollUntil.
    _notifyStateChange();

    // _pausedCountdownSecs is frozen by pauseAwareWait at the moment of pause.
    const remainSecs = _pausedCountdownSecs;
    let bannerBody = `The process will pause at the next safe checkpoint.<br>`;
    if (remainSecs !== null) {
        bannerBody += `Countdown frozen — <strong>${fmtTime(remainSecs)}</strong> remaining. Time is paused.`;
    }
    _showPauseBanner(bannerBody);

    sendStatus('⏸ Pausing at next checkpoint…');
    await _sendTelegramControlMsg('paused',
        `The warmup process has been PAUSED by the operator.\n` +
        (remainSecs !== null
            ? `Countdown is FROZEN — ${fmtTime(remainSecs)} remaining when paused. Time will not advance until resumed.`
            : `The process will pause at the next safe checkpoint.`)
    );
}

async function _handleResume() {
    if (_processState !== "paused") return;

    // ── Extend the shared deadline BEFORE waking up waiters ──────────────
    // This eliminates the race where the countdown card timer ticks between
    // the resolver firing and pauseAwareWait extending _pauseAwareDeadline.
    if (_pauseStartedAt !== null && _pauseAwareDeadline !== null) {
        const pausedDuration = Date.now() - _pauseStartedAt;
        _pauseAwareDeadline += pausedDuration;
    }
    _pauseStartedAt = null;

    _processState = "running";
    _setControlBarPaused(false);
    _hidePauseBanner();

    // _pausedCountdownSecs was frozen at pause time — it is the exact remaining time
    // that will be restored (the deadline was extended by the full paused duration).
    let extraInfo = '';
    if (_pausedCountdownSecs !== null) {
        const remainNow = _pausedCountdownSecs;
        if (remainNow > 0) {
            const resumeAt  = new Date(Date.now() + remainNow * 1000);
            const pad       = n => String(n).padStart(2,'0');
            const resumeStr = `${pad(resumeAt.getHours())}:${pad(resumeAt.getMinutes())}:${pad(resumeAt.getSeconds())}`;
            extraInfo = `Countdown resumes with ${fmtTime(remainNow)} still left (time was frozen).\nNext drop step expected around: ${resumeStr}`;
        } else {
            extraInfo = `Countdown already expired — next task will start immediately.`;
        }
    }

    sendStatus('▶️ Process resumed.');
    await _sendTelegramControlMsg('resumed',
        `The warmup process has been RESUMED by the operator.\n` + extraInfo
    );

    const resolvers = _resumeResolvers.splice(0);
    resolvers.forEach(r => r());
    _pausedCountdownSecs  = null;
    _pausedCountdownLabel = null;
}

async function _handleStop() {
    if (_processState === "stopped") return;
    const wasPaused = _processState === "paused";
    _processState    = "stopped";
    _pauseStartedAt  = null;
    _setControlBarPaused(false);
    _hidePauseBanner();

    // Wake ALL sleeping calls (wait, _pollUntil, pauseAwareWait) immediately.
    _notifyStateChange();

    stopTelegramListener();

    sendStatus('🛑 Process stopped by user.');
    await _sendTelegramControlMsg('stopped',
        `The warmup process has been STOPPED by the operator.\n` +
        (wasPaused ? `(Was paused when stop was triggered.)` : `(Was running when stop was triggered.)`)
    );

    const resolvers = _resumeResolvers.splice(0);
    resolvers.forEach(r => r());
    _pausedCountdownSecs = null;
}

function showMainCard(drop, displayTotal, stepHTML, color = 'blue', icon = '🚀') {
    const overlay = getOverlay();
    if (_mainCard && _mainCard.isConnected) {
        _mainCard.querySelector('.dc-badge').textContent = `DROP ${drop}/${displayTotal}`;
        _mainCard.querySelector('.dc-body').innerHTML = stepHTML;
        const iconEl = _mainCard.querySelector('.dc-icon');
        iconEl.className = `dc-icon ${color}`;
        iconEl.textContent = icon;
        const bar = _mainCard.querySelector('.dc-progress-bar');
        if (bar) bar.className = `dc-progress-bar ${color}`;
        return;
    }
    const card = document.createElement('div');
    card.className = 'deploy-card';
    card.id = '__deploy_main__';
    card.innerHTML = `
        <div class="dc-header">
            <div class="dc-icon ${color}">${icon}</div>
            <div class="dc-title">Warmup Controller</div>
            <div class="dc-badge">DROP ${drop}/${displayTotal}</div>
        </div>
        <div class="dc-body">${stepHTML}</div>
        <div class="dc-progress-wrap">
            <div class="dc-progress-bar ${color}" style="width:100%"></div>
        </div>`;
    overlay.insertBefore(card, overlay.firstChild);
    _mainCard = card;
}

function updateMainCard(drop, displayTotal, stepHTML, color = 'blue', icon = '🚀') {
    showMainCard(drop, displayTotal, stepHTML, color, icon);
}

function removeMainCard() {
    if (_mainCard && _mainCard.isConnected) {
        _mainCard.classList.add('fade-out');
        setTimeout(() => { if (_mainCard) { _mainCard.remove(); _mainCard = null; } }, 380);
    }
}

function showCountdownCard(seconds, drop, displayTotal, label = 'Waiting…') {
    const overlay = getOverlay();
    const old = document.getElementById('__deploy_countdown__');
    if (old) old.remove();
    if (_countdownTimer) { clearInterval(_countdownTimer); _countdownTimer = null; }

    const card = document.createElement('div');
    card.className = 'deploy-card';
    card.id = '__deploy_countdown__';
    card.innerHTML = `
        <div class="dc-header">
            <div class="dc-icon amber">⏱️</div>
            <div class="dc-title">${label}</div>
            <div class="dc-badge">DROP ${drop}/${displayTotal}</div>
        </div>
        <div class="dc-body">Time remaining: <strong><span id="__cd_secs__">${fmtTime(seconds)}</span></strong></div>
        <div class="dc-progress-wrap">
            <div class="dc-progress-bar amber" id="__cd_bar__" style="width:100%"></div>
        </div>`;
    overlay.appendChild(card);

    const total = seconds;
    // localDeadline tracks the wall-clock finish time for THIS card.
    // It is extended by the paused duration each time the process resumes,
    // keeping the visual countdown in sync with pauseAwareWait.
    let localDeadline = Date.now() + seconds * 1000;
    let frozenRemaining = null;  // non-null only while paused

    _countdownTimer = setInterval(() => {
        // If pauseAwareWait extended its shared deadline (on resume), sync ours.
        if (_pauseAwareDeadline !== null) {
            localDeadline = _pauseAwareDeadline;
        }

        let remaining;
        if (_processState === 'paused') {
            // Freeze the display: capture once, then keep showing it.
            if (frozenRemaining === null) {
                frozenRemaining = Math.max(0, Math.ceil((localDeadline - Date.now()) / 1000));
            }
            remaining = frozenRemaining;
        } else {
            frozenRemaining = null;  // reset when running
            remaining = Math.max(0, Math.ceil((localDeadline - Date.now()) / 1000));
        }

        const secsEl = document.getElementById('__cd_secs__');
        const barEl  = document.getElementById('__cd_bar__');
        if (secsEl) secsEl.textContent = fmtTime(remaining);
        if (barEl)  barEl.style.width  = ((remaining / total) * 100) + '%';

        if (remaining <= 0 && _processState !== 'paused') {
            clearInterval(_countdownTimer);
            _countdownTimer = null;
            card.classList.add('fade-out');
            setTimeout(() => card.remove(), 380);
        }
    }, 1000);
}

function removeCountdownCard() {
    if (_countdownTimer) { clearInterval(_countdownTimer); _countdownTimer = null; }
    const card = document.getElementById('__deploy_countdown__');
    if (card) { card.classList.add('fade-out'); setTimeout(() => card.remove(), 380); }
}

function showFinalCard(allIps, ipState, ipServerMap = {}) {
    ensureOverlay(); removeMainCard(); removeCountdownCard();
    const overlay = getOverlay();
    const old = document.getElementById('__deploy_final__');
    if (old) old.remove();

    const rows = allIps.map(ip => {
        const state  = ipState[ip];
        const server = ipServerMap[ip] ? `<span style="color:#6b7280;font-size:10px;">[${ipServerMap[ip]}]</span> ` : '';
        return `<div style="display:flex;align-items:center;gap:6px;background:rgba(255,255,255,0.04);border-radius:7px;padding:6px 9px;font-size:12px;">
            <span style="color:#93c5fd;font-family:monospace;font-weight:600;flex:1">${server}${ip}</span>
            <span style="color:#4ade80;font-weight:700">${state.totalSent.toLocaleString()}</span>
            <span style="color:#64748b;font-size:11px">target:${state.target.toLocaleString()}</span>
        </div>`;
    }).join('');

    const card = document.createElement('div');
    card.className = 'deploy-card';
    card.id = '__deploy_final__';
    card.innerHTML = `
        <div class="dc-header">
            <div class="dc-icon green">🏁</div>
            <div class="dc-title">All Drops Complete</div>
            <div class="dc-badge">DONE</div>
        </div>
        <div class="dc-body" style="margin-bottom:8px;">Total emails sent per IP:</div>
        <div style="display:flex;flex-direction:column;gap:5px;">${rows}</div>
        <div style="height:1px;background:rgba(255,255,255,0.07);margin:9px 0 8px;"></div>
        <div class="dc-body" style="font-size:11px;color:#64748b;">Click to dismiss</div>`;
    card.style.cursor = 'pointer';
    card.addEventListener('click', () => { card.classList.add('fade-out'); setTimeout(() => card.remove(), 380); });
    overlay.appendChild(card);
}

// ===============================
// LIVE STATUS PANEL (bottom-left)
// ===============================

let _livePanel = null;

function ensureLivePanel() {
    if (document.getElementById('__deploy_live_panel__')) {
        _livePanel = document.getElementById('__deploy_live_panel__');
        return;
    }
    const style = document.createElement('style');
    style.id = '__deploy_live_styles__';
    style.textContent = `
        #__deploy_live_panel__ {
            position:fixed;bottom:20px;left:20px;z-index:999998;width:360px;
            background:linear-gradient(160deg,#0a0f1e 0%,#111827 100%);
            border:1px solid rgba(99,102,241,0.3);border-radius:16px;
            font-family:'Consolas','Courier New',monospace;
            box-shadow:0 12px 40px rgba(0,0,0,0.65),0 0 0 1px rgba(255,255,255,0.04) inset;
            overflow:hidden;
        }
        #__deploy_live_panel__ .lp-header{
            display:flex;align-items:center;gap:8px;padding:11px 15px;
            background:rgba(99,102,241,0.08);border-bottom:1px solid rgba(99,102,241,0.18);
        }
        #__deploy_live_panel__ .lp-dot{
            width:8px;height:8px;border-radius:50%;
            background:#6366f1;box-shadow:0 0 6px #6366f1;
            animation:lp-pulse 2s infinite;flex-shrink:0;
        }
        #__deploy_live_panel__ .lp-dot.done{background:#4ade80;box-shadow:0 0 6px #4ade80;animation:none;}
        @keyframes lp-pulse{0%,100%{opacity:1}50%{opacity:0.35}}
        #__deploy_live_panel__ .lp-title{
            font-size:10px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#818cf8;
        }
        #__deploy_live_panel__ .lp-drop{
            margin-left:auto;font-size:10px;font-weight:700;color:#fbbf24;
            background:rgba(251,191,36,0.1);border:1px solid rgba(251,191,36,0.2);
            padding:2px 9px;border-radius:20px;letter-spacing:0.04em;
        }
        #__deploy_live_panel__ .lp-offset-row{
            display:flex;align-items:center;gap:6px;padding:7px 15px;
            background:rgba(255,255,255,0.02);border-bottom:1px solid rgba(255,255,255,0.05);
        }
        #__deploy_live_panel__ .lp-tag{font-size:9px;color:#374151;text-transform:uppercase;letter-spacing:0.06em;}
        #__deploy_live_panel__ .lp-val{color:#38bdf8;font-weight:700;font-size:13px;}
        #__deploy_live_panel__ .lp-ip-list{
            padding:8px 10px;display:flex;flex-direction:column;gap:5px;max-height:280px;overflow-y:auto;
        }
        #__deploy_live_panel__ .lp-ip-list::-webkit-scrollbar{width:4px;}
        #__deploy_live_panel__ .lp-ip-list::-webkit-scrollbar-thumb{background:rgba(99,102,241,0.3);border-radius:4px;}
        #__deploy_live_panel__ .lp-ip-row{
            display:flex;align-items:center;gap:8px;padding:8px 11px;
            background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.05);border-radius:9px;
        }
        #__deploy_live_panel__ .lp-ip{color:#7dd3fc;font-size:12px;flex:1;}
        #__deploy_live_panel__ .lp-rcpt-badge{
            font-size:10px;padding:2px 7px;border-radius:20px;white-space:nowrap;font-weight:600;
        }
        #__deploy_live_panel__ .lp-rcpt-badge.queue{background:rgba(251,191,36,0.1);color:#fbbf24;border:1px solid rgba(251,191,36,0.2);}
        #__deploy_live_panel__ .lp-rcpt-badge.done {background:rgba(74,222,128,0.1);color:#4ade80;border:1px solid rgba(74,222,128,0.2);}
        #__deploy_live_panel__ .lp-rcpt-badge.na   {background:rgba(248,113,113,0.1);color:#f87171;border:1px solid rgba(248,113,113,0.2);}
        #__deploy_live_panel__ .lp-sent{color:#a5f3fc;font-weight:700;font-size:13px;white-space:nowrap;min-width:64px;text-align:right;}
        #__deploy_live_panel__ .lp-footer{
            padding:10px 12px;border-top:1px solid rgba(255,255,255,0.05);display:flex;flex-direction:column;gap:7px;
        }
        #__deploy_live_panel__ .lp-done-label{
            text-align:center;font-size:11px;font-weight:700;color:#4ade80;letter-spacing:0.07em;text-transform:uppercase;
        }
        #__deploy_live_panel__ .lp-copy-btn{
            width:100%;padding:9px;
            background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%);
            color:white;border:none;border-radius:9px;font-size:12px;font-weight:700;
            cursor:pointer;letter-spacing:0.04em;transition:opacity 0.15s,transform 0.1s;
            box-shadow:0 4px 12px rgba(99,102,241,0.35);font-family:'Segoe UI',sans-serif;
        }
        #__deploy_live_panel__ .lp-copy-btn:hover{opacity:0.88;transform:translateY(-1px);}
        #__deploy_live_panel__ .lp-copy-btn.copied{background:linear-gradient(135deg,#059669,#10b981);}
    `;
    if (!document.getElementById('__deploy_live_styles__')) document.head.appendChild(style);
    const panel = document.createElement('div');
    panel.id = '__deploy_live_panel__';
    document.body.appendChild(panel);
    _livePanel = panel;
}

function updateLivePanel(ipState, allIps, drop, displayTotal, currentOffset, queueResults, isDone = false, ipServerMap = {}, downServers = []) {
    ensureLivePanel();

    const ipRows = allIps.map(ip => {
        const state      = ipState[ip];
        const serverName = ipServerMap[ip] || '';
        const isDown     = queueResults !== null && queueResults[ip] === -2;
        let badge = '';
        if (queueResults !== null) {
            const rcpt = queueResults[ip];
            if (isDown)                              badge = '<span class="lp-rcpt-badge na">⛔️ DOWN</span>';
            else if (rcpt === undefined || rcpt === -1) badge = '<span class="lp-rcpt-badge na">N/A</span>';
            else if (rcpt === 0)                     badge = '<span class="lp-rcpt-badge done">✓ 0</span>';
            else                                     badge = `<span class="lp-rcpt-badge queue">q:${rcpt.toLocaleString()}</span>`;
        }
        const serverLabel = serverName
            ? `<span style="font-size:10px;color:#6b7280;margin-right:3px;">[${serverName}]</span>`
            : '';
        return `<div class="lp-ip-row${isDown ? ' lp-ip-row-down' : ''}">
            <span class="lp-ip">${serverLabel}${ip}</span>${badge}
            <span class="lp-sent">${state.totalSent.toLocaleString()}</span>
        </div>`;
    }).join('');

    const dotClass  = isDone ? 'lp-dot done' : 'lp-dot';
    const dropLabel = isDone ? 'DONE' : `DROP ${drop}/${displayTotal}`;
    const footerHtml = isDone ? `
        <div class="lp-footer">
            <div class="lp-done-label">✅ All Drops Complete</div>
            <button class="lp-copy-btn" id="__lp_copy_btn__">📋 Copy Results</button>
        </div>` : '';

    _livePanel.innerHTML = `
        <div class="lp-header">
            <div class="${dotClass}"></div>
            <span class="lp-title">📊 Live Warmup Status</span>
            <span class="lp-drop">${dropLabel}</span>
        </div>
        <div class="lp-offset-row">
            <span class="lp-tag">offset</span>
            <span class="lp-val">${currentOffset.toLocaleString()}</span>
        </div>
        <div class="lp-ip-list">${ipRows}</div>
        ${footerHtml}`;

    if (isDone) {
        const copyBtn = document.getElementById('__lp_copy_btn__');
        if (copyBtn) {
            copyBtn.addEventListener('click', () => {
                let text = 'WARMUP RESULTS\n' + '─'.repeat(32) + '\n';
                text += 'Drop ' + drop + '/' + displayTotal + ' | Offset: ' + currentOffset.toLocaleString() + '\n';
                text += '─'.repeat(32) + '\n';
                allIps.forEach(ip => {
                    const s   = ipState[ip];
                    const srv = ipServerMap[ip] ? `[${ipServerMap[ip]}] ` : '';
                    text += srv + ip + '\n  Total Sent   : ' + s.totalSent.toLocaleString() + '\n  Final Target : ' + s.target.toLocaleString() + '\n';
                });
                text += '─'.repeat(32);

                const el = document.createElement('textarea');
                el.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
                el.value = text;
                document.body.appendChild(el);
                el.focus(); el.select();
                try {
                    document.execCommand('copy');
                    copyBtn.textContent = '✅ Copied!';
                    copyBtn.classList.add('copied');
                    setTimeout(() => { copyBtn.textContent = '📋 Copy Results'; copyBtn.classList.remove('copied'); }, 2500);
                } catch(e) { copyBtn.textContent = '❌ Failed'; }
                document.body.removeChild(el);
            });
        }
    }
}

// ===============================
// PRE-FLIGHT VERIFICATION
// ===============================
// Checks that all required page fields are correctly set before the
// warmup process is allowed to start.  Returns an array of error
// strings (empty = all checks passed).
// processType: "passive" | "datalists"
// -------------------------------------------------------
function runPreflightChecks(processType, ispKeyword, ispMode) {
    const errors = [];

    // ── Helper: read the title attribute of a Select2 container span ──
    // Returns null  if the element doesn't exist.
    // Returns ''    if Select2 is showing a placeholder (nothing actually selected).
    // Returns the trimmed title string when a real value is selected.
    function getTitle(spanId) {
        const el = document.getElementById(spanId);
        if (!el) return null;
        // If a .select2-selection__placeholder child exists, the field is empty —
        // ignore the title attribute, which Select2 may still populate even in
        // placeholder state.
        if (el.querySelector('.select2-selection__placeholder')) return '';
        return (el.getAttribute('title') || '').trim();
    }

    // ── Helper: read the value of an <input> by name ─────────────────
    function getInputValue(name) {
        const el = document.querySelector(`input[name="${name}"]`);
        return el ? el.value.trim() : null;
    }

    // ── 1. Sponsors: must be "Sphere Digital" ────────────────────────
    const sponsor = getTitle('select2-sponsors-container');
    if (sponsor === null) {
        errors.push('Sponsors selector not found on this page.');
    } else if (sponsor !== 'Sphere Digital') {
        errors.push(`Sponsor must be "Sphere Digital" (found: "${sponsor}").`);
    }

    // ── 2. Offer: must contain "test offer [REPORTING]" ────────────────────────────
    const offer = getTitle('select2-offers-container');
    if (offer === null) {
        errors.push('Offers selector not found on this page.');
    } else if (!offer.includes('test offer [REPORTING]')) {
        errors.push(`Offer must contain "test offer [REPORTING]" (found: "${offer}").`);
    }

    // ── 3. system_speed[batch] = 0 ───────────────────────────────────
    const batch = getInputValue('system_speed[batch]');
    if (batch === null) {
        errors.push('Input system_speed[batch] not found on this page.');
    } else if (parseInt(batch) !== 0) {
        errors.push(`system_speed[batch] must be 0 (found: "${batch}").`);
    }

    // ── 4. system_speed[delay] = 0 ───────────────────────────────────
    const delay = getInputValue('system_speed[delay]');
    if (delay === null) {
        errors.push('Input system_speed[delay] not found on this page.');
    } else if (parseInt(delay) !== 0) {
        errors.push(`system_speed[delay] must be 0 (found: "${delay}").`);
    }

    // ── 5. Mode-specific checks ───────────────────────────────────────
    if (processType === 'passive') {
        // Lists Passive mode
        const provider = getTitle('select2-data_providers-container');
        if (provider === null) {
            errors.push('Data Provider selector not found on this page.');
        } else if (!provider.includes('data_TSS')) {
            errors.push(`Data Provider must contain "data_TSS" (found: "${provider}").`);
        }

        const profile = getTitle('select2-data_profiles-container');
        if (profile === null) {
            errors.push('Data Profile selector not found on this page.');
        } else if (profile !== 'Seeds') {
            errors.push(`Data Profile must be "Seeds" (found: "${profile}").`);
        }

        const ispProfile = getTitle('select2-data_profile_isps-container');
        if (ispProfile === null) {
            errors.push('ISP Profile selector not found on this page.');
        } else if (ispProfile.toLowerCase() !== ispKeyword.toLowerCase()) {
            errors.push(`ISP Profile must be exactly "${ispKeyword}" (found: "${ispProfile}").`);
        }

    } else if (processType === 'datalists') {
        // Data Lists mode — rules depend on the mode of the first ISP entry
        const firstEntryMode = ispMode || 'warmup';

        const provider = getTitle('select2-data_providers-container');
        if (provider === null) {
            errors.push('Data Provider selector not found on this page.');
        } else if (firstEntryMode === 'passive') {
            if (!provider.includes('data_TSS')) {
                errors.push(`Data Provider must contain "data_TSS" (found: "${provider}").`);
            }
        } else {
            // warmup mode
            if (!provider.includes('Seeds')) {
                errors.push(`Data Provider must contain "Seeds" (found: "${provider}").`);
            }
        }

        const profile = getTitle('select2-data_profiles-container');
        if (profile === null) {
            errors.push('Data Profile selector not found on this page.');
        } else if (firstEntryMode === 'passive') {
            if (!profile.includes('Seeds')) {
                errors.push(`Data Profile must contain "Seeds" (found: "${profile}").`);
            }
        } else {
            // warmup mode
            if (!profile.toLowerCase().includes('seeds_tss')) {
                errors.push(`Data Profile must contain "seeds_TSS" (found: "${profile}").`);
            }
        }

        const ispProfile = getTitle('select2-data_profile_isps-container');
        if (ispProfile === null) {
            errors.push('ISP Profile selector not found on this page.');
        } else if (ispProfile.toLowerCase() !== ispKeyword.toLowerCase()) {
            errors.push(`ISP Profile must be exactly "${ispKeyword}" (found: "${ispProfile}").`);
        }
    }

    return errors;
}

// ── Show a blocking error card in the overlay and notify popup ──
function showPreflightErrorCard(errors) {
    ensureOverlay();
    const overlay = getOverlay();

    // Remove any previous preflight card
    const old = document.getElementById('__deploy_preflight_error__');
    if (old) old.remove();

    const rows = errors.map(e =>
        `<div style="display:flex;align-items:flex-start;gap:7px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.05);">
            <span style="color:#f87171;flex-shrink:0;margin-top:1px;">✗</span>
            <span style="font-size:12px;color:#fca5a5;line-height:1.5;">${e}</span>
        </div>`
    ).join('');

    const card = document.createElement('div');
    card.className = 'deploy-card';
    card.id = '__deploy_preflight_error__';
    card.style.cursor = 'pointer';
    card.innerHTML = `
        <div class="dc-header">
            <div class="dc-icon red">🚫</div>
            <div class="dc-title">Pre-flight Check Failed</div>
            <div class="dc-badge">BLOCKED</div>
        </div>
        <div class="dc-body" style="margin-bottom:8px;color:#fca5a5;">
            Fix the following before starting:
        </div>
        <div style="display:flex;flex-direction:column;">${rows}</div>
        <div style="height:1px;background:rgba(255,255,255,0.07);margin:9px 0 6px;"></div>
        <div class="dc-body" style="font-size:11px;color:#64748b;">Click to dismiss</div>`;
    card.addEventListener('click', () => {
        card.classList.add('fade-out');
        setTimeout(() => card.remove(), 380);
    });
    overlay.appendChild(card);
}

// ===============================
// Message Listener
// ===============================

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "PING") sendResponse({ ok: true });
    if (message.type === "START_DEPLOY_PROCESS") {
        if (message.deployTabId) _deployTabId = message.deployTabId;

        const processType = (message.config && message.config.processType) || 'passive';

        // Determine the ISP keyword and mode to use for preflight
        // For datalists: use the first entry's value + mode for the check
        let ispPreflightKeyword = '';
        let ispPreflightMode    = 'warmup'; // default for datalists
        if (processType === 'passive') {
            ispPreflightKeyword = (message.config && message.config.ispPassiveValue) || '';
            ispPreflightMode    = 'passive';
        } else if (processType === 'datalists') {
            const entries = (message.config && message.config.ispDatalistsEntries) || [];
            ispPreflightKeyword = entries.length > 0 ? (entries[0].value || '') : '';
            ispPreflightMode    = entries.length > 0 ? (entries[0].mode || 'warmup') : 'warmup';
        }

        const preflightErrors = runPreflightChecks(processType, ispPreflightKeyword, ispPreflightMode);

        if (preflightErrors.length > 0) {
            // Block the process — notify popup and show error card on page
            sendResponse({ started: false, preflightErrors });
            ensureOverlay();
            showPreflightErrorCard(preflightErrors);
            return;
        }

        sendResponse({ started: true });
        startFullProcess(message.groups, message.config, message.orderedIps, message.ipServerMap || {});
    }
});

// -------------------------------------------------------
// pauseAwareWait
// -------------------------------------------------------
// Counts down the requested duration, but FREEZES while paused.
// When the process is paused, we record how much time was remaining
// and extend the deadline by the full paused duration on resume.
// Example: 10 min left at 12:00, paused until 12:20 → resumes with
// 10 min still left, so the next task fires at 12:30.
async function pauseAwareWait(totalMs, drop, displayTotal, label) {
    // _pauseAwareDeadline is a shared reference so showCountdownCard
    // can sync to the same deadline after it gets extended.
    let deadline = Date.now() + totalMs;
    _pauseAwareDeadline = deadline;

    while (true) {
        if (_processState === "stopped") throw new ProcessStoppedError();

        const remaining = _pauseAwareDeadline - Date.now();
        if (remaining <= 0) {
            _pauseAwareDeadline = null;
            return;
        }

        if (_processState === "paused") {
            // Snapshot how much time was left the moment we paused.
            const frozenRemaining = Math.ceil(Math.max(0, _pauseAwareDeadline - Date.now()) / 1000);
            _pausedCountdownSecs  = frozenRemaining;  // frozen — not ticking
            _pausedCountdownLabel = label;
            _pausedCountdownDrop  = drop;
            _pausedCountdownTotal = displayTotal;

            // Record pause start if _handlePause hasn't already (covers rapid-pause edge cases)
            if (_pauseStartedAt === null) _pauseStartedAt = Date.now();

            // Block here until resumed (or stopped).
            // _handleResume already extended _pauseAwareDeadline before waking us —
            // so we do NOT extend it again here to avoid double-counting.
            await checkPauseOrStop();

            // Reset the frozen secs so the countdown card picks up the new deadline.
            _pausedCountdownSecs = null;
            continue;
        }

        const slice = Math.min(500, _pauseAwareDeadline - Date.now());
        if (slice > 0) await wait(slice);
    }
}

// Shared deadline reference so showCountdownCard can stay in sync.
let _pauseAwareDeadline = null;

// ===============================
// MAIN ORCHESTRATOR
// ===============================

async function startFullProcess(groups, config, orderedIps, ipServerMap = {}) {
    const {
        totalDrops, successThreshold, sentIncrement,
        timeBeforeResume,
        timeAfterResume,
        timeBetweenDrops,
        telegramChatId,
        toleranceRate,
        sheetsSpreadsheetId,
        dropStart: _dropStart,
        startAfterDelay: _startAfterDelay,
        emailCountEnabled,
        gmailEmail,
        gmailPassword,
        emailCountDelay,
        prepBufferTime,
        spamStopMode,
        spamStopValue,
        ispDatalistsEntries,
        dropNote = '',
    } = config;


    // ── Drop offset setup ──────────────────────────────────────────────────
    // dropStart  : the real first drop number (1 = normal, >=2 = resume offset)
    // displayTotal: the last drop number shown in UI (= dropEnd)
    //   Example: dropStart=4, totalDrops=10 -> drops 4..13 shown as 4/13...13/13
    const dropStart    = (_dropStart && _dropStart >= 2) ? _dropStart : 1;
    const dropEnd      = dropStart + totalDrops - 1;   // last real drop number (e.g. 13)
    const displayTotal = dropEnd;                       // badge denominator   (e.g. 13)

    // tgDropCounter counts 1,2,3… for Telegram regardless of offset
    let tgDropCounter = 0;

    _telegramChatId = telegramChatId;
    _ipServerMap    = ipServerMap || {};
    startKeepAlive();
    
    if (config.enableRemoteStop && _telegramChatId) {
        startTelegramListener(_telegramChatId);
    }
    
    _startBodyGuardian();

    _processState        = "running";
    _resumeResolvers     = [];
    _pausedCountdownSecs = null;
    // Reset Data Lists entry index so every new session starts from entry 1
    runDropSendDataLists._entryIndex = 0;

    browser.runtime.sendMessage({
        type: "PROCESS_STARTED",
        tabId: _deployTabId,
        totalDrops
    });

    ensureOverlay();
    ensureLivePanel();
    ensureControlBar();

    const ipState = {};
    groups.forEach(g => g.ips.forEach(ip => {
        ipState[ip] = { target: g.value, consecutiveSuccesses: 0, totalSent: 0 };
    }));
    const allIps = (orderedIps && orderedIps.length > 0)
        ? orderedIps
        : groups.flatMap(g => g.ips);

    let persistentOffset = 0;

    let lastResumeTime              = null;
    let targetResumeTimeForNextDrop = null;

    // ── Start-after delay ────────────────────────────────────────────────────
    const startAfterDelay = (_startAfterDelay && _startAfterDelay > 0) ? _startAfterDelay : 0;
    if (startAfterDelay > 0) {
        const deadline = Date.now() + startAfterDelay * 1000;
        // Live countdown — tick every second and push status to popup
        while (true) {
            if (_processState === "stopped") throw new ProcessStoppedError();
            const remainingMs = deadline - Date.now();
            if (remainingMs <= 0) break;

            if (_processState === "paused") {
                // While paused just wait without ticking down
                await checkPauseOrStop();
                continue;
            }

            const remSec = Math.ceil(remainingMs / 1000);
            const label  = fmtTime(remSec);
            sendStatus(`⏳ First drop starts in ${label}…`);
            updateMainCard(0, displayTotal,
                `⏳ Starting in <strong>${label}</strong> — first drop preparing soon`,
                'blue', '⏳');

            // Sleep until next second boundary (or end)
            const slice = Math.min(1000, remainingMs);
            await wait(slice);
        }
        sendStatus(`⏳ Start delay done — preparing first drop…`);
    }

    try {
        for (let drop = dropStart; drop <= dropEnd; drop++) {
            tgDropCounter++;
            const tgDrop  = tgDropCounter;   // Telegram: always 1-based
            const tgTotal = totalDrops;      // Telegram: always the configured count

            await checkPauseOrStop();
            sendStatus(`DROP ${drop}/${displayTotal} starting...`);

            updateMainCard(drop, displayTotal,
                `DROP ${drop}/${displayTotal} — <strong>PAUSE · DELETE · RESET · SCHEDULE</strong>`,
                'blue', '🔧');
            sendStatus(`Drop ${drop}: PAUSE / DELETE / RESET / SCHEDULE all IPs…`);
            await selectIps(allIps);
            await wait(1000);
            await openRunCommandModal();
            await executePauseAndVerify(drop, displayTotal, allIps, tgDrop, tgTotal, telegramChatId);

            updateMainCard(drop, displayTotal, `Building send groups from current targets…`, 'blue', '📋');
            const currentGroups = buildCurrentGroups(ipState);

            updateLivePanel(ipState, allIps, drop, displayTotal, persistentOffset, null);

            updateMainCard(drop, displayTotal, `Applying <strong>ISP Profile</strong> selection…`, 'purple', '🔄');
            sendStatus(`Drop ${drop}: Applying ISP Profile for current entry…`);

            persistentOffset = await runDropSendDataLists(
                currentGroups, drop, displayTotal, persistentOffset,
                ispDatalistsEntries || [],
                tgDrop, tgTotal, telegramChatId
            );
            // Capture the mode that was actually used this drop — must be read
            // immediately after runDropSendDataLists returns, before any next drop
            // overwrites _lastMode.
            _effectiveProcessType = runDropSendDataLists._lastMode === 'passive' ? 'passive' : 'warmup';
            updateLivePanel(ipState, allIps, drop, displayTotal, persistentOffset, null);

            await checkPauseOrStop();

            // ── Wait before RESUME ────────────────────────────────────────────
            if (drop === dropStart || targetResumeTimeForNextDrop === null) {
                if (timeBeforeResume > 0) {
                    showCountdownCard(timeBeforeResume, drop, displayTotal, 'Before Resume & Schedule');
                    sendStatus(`Drop ${drop}: Waiting ${fmtTime(timeBeforeResume)} before RESUME+SCHEDULE...`);
                    await pauseAwareWait(timeBeforeResume * 1000, drop, displayTotal, 'Before Resume & Schedule');
                    removeCountdownCard();
                }
            } else {
                const nowMs = Date.now();
                if (nowMs < targetResumeTimeForNextDrop) {
                    const waitMs   = targetResumeTimeForNextDrop - nowMs;
                    const waitSecs = Math.ceil(waitMs / 1000);
                    showCountdownCard(waitSecs, drop, displayTotal, 'Waiting for resume window');
                    sendStatus(`Drop ${drop}: Waiting ${fmtTime(waitSecs)} for scheduled resume window…`);
                    await pauseAwareWait(waitMs, drop, displayTotal, 'Waiting for resume window');
                    removeCountdownCard();
                } else {
                    if (timeBeforeResume > 0) {
                        showCountdownCard(timeBeforeResume, drop, displayTotal, 'Before Resume & Schedule');
                        sendStatus(`Drop ${drop}: Waiting ${fmtTime(timeBeforeResume)} before RESUME+SCHEDULE...`);
                        await pauseAwareWait(timeBeforeResume * 1000, drop, displayTotal, 'Before Resume & Schedule');
                        removeCountdownCard();
                    }
                }
            }

            await checkPauseOrStop();

            lastResumeTime = Date.now();

            updateMainCard(drop, displayTotal, `Running <strong>RESUME + SCHEDULE</strong> for all IPs…`, 'purple', '▶️');
            sendStatus(`Drop ${drop}: RESUME + SCHEDULE...`);
            await selectIps(allIps);
            await wait(1000);
            await openRunCommandModalss();
            await executeResumeAndVerify(drop, displayTotal, allIps, tgDrop, tgTotal, telegramChatId);

            if (timeAfterResume > 0) {
                await repeatScheduleForDuration(allIps, drop, displayTotal, timeAfterResume);
            }

            updateMainCard(drop, displayTotal, `Opening monitor &amp; reading <strong>#Rcpt</strong>…`, 'amber', '🖥️');
            sendStatus(`Drop ${drop}: Opening monitor and reading queues...`);
            const monitorBtn = await waitForElementVisible("#ips_by_classes_ms-multi-monitors");
            monitorBtn.click();

            sendStatus(`Drop ${drop}: Waiting 9s for MultiMonitor page to load…`);
            await wait(9000);

            sendStatus(`Drop ${drop}: Navigating iframes to Queues…`);
            await bgMessage({ type: "NAVIGATE_QUEUES" });

            sendStatus(`Drop ${drop}: Waiting 15s for Queues data to load…`);
            await wait(15000);

            const { queueResults, downServers } = await readQueueData(allIps, ipServerMap);
            updateLivePanel(ipState, allIps, drop, displayTotal, persistentOffset, queueResults, false, ipServerMap, downServers);

            const targetSnapshot = {};
            for (const ip of allIps) targetSnapshot[ip] = ipState[ip].target;

            for (const ip of allIps) {
                const state = ipState[ip];
                let rcpt = queueResults[ip];
                if (rcpt === undefined) { state.consecutiveSuccesses = 0; continue; }
                // rcpt === -2 means server was down → treat as 0 sent (no increment)
                if (rcpt === -2) { state.consecutiveSuccesses = 0; continue; }
                if (rcpt === -1) rcpt = 0;

                const delivered = Math.max(0, state.target - rcpt);
                state.totalSent += delivered;

                // A drop counts as successful if the remaining queue (rcpt) is within
                // the tolerance window: rcpt <= target * (toleranceRate / 100)
                const toleranceAllowed = Math.floor(state.target * ((toleranceRate || 0) / 100));
                const isSuccess = rcpt <= toleranceAllowed;

                if (isSuccess) {
                    state.consecutiveSuccesses += 1;
                    if (state.consecutiveSuccesses >= successThreshold) {
                        state.target += sentIncrement;
                        state.consecutiveSuccesses = 0;
                        sendStatus(`Drop ${drop}: 🚀 ${ip} target → ${state.target} (rcpt ${rcpt} ≤ tolerance ${toleranceAllowed})`);
                    }
                } else {
                    state.consecutiveSuccesses = 0;
                }
            }
            updateLivePanel(ipState, allIps, drop, displayTotal, persistentOffset, queueResults, false, ipServerMap, downServers);

            // ── Save to Google Sheets ──
            // Uses real `drop` number so columns land correctly even when starting from drop 3+
            try {
                browser.runtime.sendMessage({ type: "SHEETS_SAVING", drop });
                sendStatus(`Drop ${drop}: Saving results to Google Sheets…`);

                const ipResults = allIps.map(ip => {
                    const state      = ipState[ip];
                    const target     = targetSnapshot[ip];
                    const rcpt       = queueResults[ip];
                    const serverDown = rcpt === -2;
                    const reallySent = serverDown
                        ? 0
                        : (rcpt === undefined || rcpt === -1)
                            ? target
                            : Math.max(0, target - rcpt);
                    return {
                        ip,
                        target,
                        reallySent,
                        rcpt       : rcpt === undefined ? -1 : rcpt,
                        server     : ipServerMap[ip] || '',
                        serverDown
                    };
                });

                const saveResult = await bgMessage({
                    type         : "SHEETS_SAVE",
                    drop,
                    ipResults,
                    toleranceRate,
                    ipServerMap,
                    downServers,
                    spreadsheetId: sheetsSpreadsheetId
                });

                browser.runtime.sendMessage({
                    type: "SHEETS_SAVED", drop,
                    success:   saveResult.success,
                    sheetName: saveResult.sheetName || '',
                    error:     saveResult.error     || ''
                });

                sendStatus(`Drop ${drop}: ${saveResult.success
                    ? '✅ Saved to Google Sheets → ' + saveResult.sheetName
                    : '⚠️ Sheets save failed: '       + saveResult.error}`);
            } catch (sheetsErr) {
                console.error('[Sheets] Unexpected error:', sheetsErr);
                browser.runtime.sendMessage({
                    type: "SHEETS_SAVED", drop, success: false,
                    sheetName: '', error: sheetsErr.message
                });
            }

            await checkPauseOrStop();

            // ── Build tgResults snapshot (used for merged Telegram report) ────
            const tgResults = allIps.map(ip => {
                const rcpt       = queueResults[ip];
                const serverDown = rcpt === -2;
                return {
                    ip,
                    server     : ipServerMap[ip] || '',
                    serverDown,
                    target     : targetSnapshot[ip],
                    reallySent : serverDown
                        ? 0
                        : (rcpt === undefined || rcpt === -1)
                            ? targetSnapshot[ip]
                            : Math.max(0, targetSnapshot[ip] - rcpt)
                };
            });

            // ── DELETE ──
            updateMainCard(drop, displayTotal, `Running <strong>DELETE</strong> on all IPs…`, 'red', '🗑️');
            sendStatus(`Drop ${drop}: Running DELETE...`);
            await selectIps(allIps);
            await wait(1000);
            await openRunCommandModalDelete();
            await executeRunCommandModal(`Drop ${drop}: DELETE`, 5);

            // ── Merged Telegram report (warmup + optional email count) ────────
            // Sent after DELETE, respecting the email count wait delay.
            // Uses tgDrop/tgTotal so Telegram always shows 1/10, 2/10 … regardless of offset.
            await runMergedTelegramReport(
                drop, displayTotal,
                tgDrop, tgTotal,
                tgResults,
                lastResumeTime,
                telegramChatId,
                toleranceRate,
                downServers,
                _effectiveProcessType,
                emailCountEnabled && gmailEmail && gmailPassword
                    ? { gmailEmail, gmailPassword, emailCountDelay: emailCountDelay || 0 }
                    : null,
                spamStopMode  || 'none',
                spamStopValue || 0,
                dropNote
            );

            // ── Schedule next drop preparation ────────────────────────────────
            if (drop < dropEnd) {
                await checkPauseOrStop();

                targetResumeTimeForNextDrop = lastResumeTime + timeBetweenDrops * 1000;
                const PREP_BUFFER_MS        = (prepBufferTime || 15 * 60) * 1000;
                const prepStartTime         = targetResumeTimeForNextDrop - PREP_BUFFER_MS;
                const nowMs                 = Date.now();

                if (nowMs < prepStartTime) {
                    const waitMs   = prepStartTime - nowMs;
                    const waitSecs = Math.ceil(waitMs / 1000);
                    showCountdownCard(waitSecs, drop, displayTotal, 'Between drops');
                    sendStatus(`Drop ${drop}: Next preparation starts in ${fmtTime(waitSecs)}…`);
                    await pauseAwareWait(waitMs, drop, displayTotal, 'Between drops');
                    removeCountdownCard();
                } else {
                    sendStatus(`Drop ${drop}: Prep window (${fmtTime(prepBufferTime || 900)}) already reached — starting next preparation immediately.`);
                }
            }
        }

        // ── ALL DONE ──
        showFinalCard(allIps, ipState, ipServerMap);
        updateLivePanel(ipState, allIps, dropEnd, displayTotal, persistentOffset, null, true, ipServerMap, []);
        removeControlBar();

        let report = "📊 FINAL REPORT\n━━━━━━━━━━━━━━━━━━━━━━━━\n";
        for (const ip of allIps) {
            const s = ipState[ip];
            report += `${ip}\n  Total Sent: ${s.totalSent.toLocaleString()}\n  Final Target: ${s.target.toLocaleString()}\n`;
        }
        report += "━━━━━━━━━━━━━━━━━━━━━━━━";

        stopKeepAlive();
        stopTelegramListener();
        _stopBodyGuardian();
        browser.runtime.sendMessage({ type: "PROCESS_COMPLETED" });
        browser.runtime.sendMessage({ type: "FINAL_REPORT", report });
        console.log(report);

    } catch (error) {
        stopKeepAlive();
        stopTelegramListener();
        removeControlBar();
        _stopBodyGuardian();

        if (error instanceof ProcessStoppedError) {
            console.log('[Process] Stopped by user.');
            removeMainCard();
            removeCountdownCard();
            const overlay = getOverlay();
            const card = document.createElement('div');
            card.className = 'deploy-card';
            card.style.cursor = 'pointer';
            card.innerHTML = `
                <div class="dc-header">
                    <div class="dc-icon red">🛑</div>
                    <div class="dc-title">Process Stopped</div>
                    <div class="dc-badge">BY USER</div>
                </div>
                <div class="dc-body">The warmup process was <strong>stopped manually</strong>. Click to dismiss.</div>`;
            card.addEventListener('click', () => { card.classList.add('fade-out'); setTimeout(() => card.remove(), 380); });
            overlay.appendChild(card);
            browser.runtime.sendMessage({ type: "PROCESS_FAILED", error: "Stopped by user." });
            return;
        }

        console.error('[Process] Fatal error:', error);
        sendStatus('❌ Process failed: ' + error.message);
        browser.runtime.sendMessage({ type: "PROCESS_FAILED", error: error.message });
        throw error;
    }
}

// -------------------------------------------------------
// PAUSE-AND-VERIFY
// -------------------------------------------------------
// Replaces the old `executeRunCommandModal(..., 5)` for the
// PAUSE+DELETE+RESET+SCHEDULE step.
//
// Flow (up to MAX_ATTEMPTS times):
//   1. Click Execute 2 times (5 s apart)
//   2. Dismiss the modal
//   3. Open MultiMonitor → wait 7 s for iframes to load
//   4. Ask background to check if at least one iframe shows
//      the 3 target queues as paused
//   5a. Paused confirmed → close monitor tab → return
//   5b. Not confirmed   → close monitor tab → retry from step 1
//      (re-select IPs and re-open the modal each time)
//   6. After MAX_ATTEMPTS failures → send Telegram alert → throw
//      ProcessStoppedError so the entire session is halted
// -------------------------------------------------------
async function executePauseAndVerify(drop, displayTotal, allIps, tgDrop, tgTotal, telegramChatId) {
    const MAX_ATTEMPTS = 3;

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {

        // ── 1. Click Execute × 2 ────────────────────────────
        const form = await waitForElement('#run-cmd-form', 30000);

        const chk = await waitForElementVisible('#check-cmd-by-server', 15000);
        if (!chk.checked) { chk.click(); await wait(600); }

        const submitBtn = await waitForChildElement(form, "button[type='submit']", 15000);
        await wait(800);

        submitBtn.click();
        sendStatus(`Drop ${drop}: PAUSE/DELETE/RESET/SCHEDULE — attempt ${attempt}/${MAX_ATTEMPTS} (click 1/2)…`);
        updateMainCard(drop, displayTotal,
            `Attempt <strong>${attempt}/${MAX_ATTEMPTS}</strong> — PAUSE click <strong>1/2</strong>…`,
            'blue', '🔧');

        await wait(5000);
        submitBtn.click();
        sendStatus(`Drop ${drop}: PAUSE/DELETE/RESET/SCHEDULE — attempt ${attempt}/${MAX_ATTEMPTS} (click 2/2)…`);
        updateMainCard(drop, displayTotal,
            `Attempt <strong>${attempt}/${MAX_ATTEMPTS}</strong> — PAUSE click <strong>2/2</strong>…`,
            'blue', '🔧');

        // ── 2. Wait for dismiss button and close modal ───────
        const dismissBtn = await new Promise(resolve => {
            const TIMEOUT  = 90000;
            const INTERVAL = 500;
            let elapsed = 0;
            const timer = setInterval(() => {
                const btn =
                    form.querySelector("button[data-dismiss='modal']") ||
                    document.querySelector(".modal.in button[data-dismiss='modal']") ||
                    document.querySelector(".modal.show button[data-dismiss='modal']");
                if (btn) { clearInterval(timer); resolve(btn); return; }
                elapsed += INTERVAL;
                if (elapsed >= TIMEOUT) { clearInterval(timer); resolve(null); }
            }, INTERVAL);
        });

        await wait(6000);

        await _closeModalAndWait(dismissBtn, 10000);
        await wait(800);

        // ── 3. Open MultiMonitor tab ─────────────────────────
        sendStatus(`Drop ${drop}: Opening MultiMonitor to verify pause (attempt ${attempt}/${MAX_ATTEMPTS})…`);
        updateMainCard(drop, displayTotal,
            `Attempt <strong>${attempt}/${MAX_ATTEMPTS}</strong> — Opening monitor to verify pause…`,
            'amber', '🖥️');

        const monitorBtn = await waitForElementVisible("#ips_by_classes_ms-multi-monitors");
        monitorBtn.click();

        // Wait 9s for the MultiMonitor tab to open and its DOM to render
        // (the background CHECK_PAUSE_STATUS handler will then navigate
        //  the iframes to Queues and wait another 7s before reading)
        sendStatus(`Drop ${drop}: Waiting for MultiMonitor tab to open…`);
        await wait(9000);

        // ── 4. Check pause status via background ────────────
        // Background navigates iframes → waits 7s → reads Paused column
        sendStatus(`Drop ${drop}: Navigating iframes to Queues & checking pause status…`);
        const checkResult = await bgMessage({ type: "CHECK_PAUSE_STATUS", allIps });

        const monitorTabId = checkResult ? checkResult.tabId : null;

        // ── 5a. Paused confirmed ─────────────────────────────
        if (checkResult && checkResult.paused) {
            sendStatus(`Drop ${drop}: ✅ Pause confirmed — closing monitor tab…`);
            updateMainCard(drop, displayTotal,
                `✅ Pause confirmed on attempt <strong>${attempt}</strong> — continuing…`,
                'green', '✅');

            if (monitorTabId) {
                await bgMessage({ type: "CLOSE_TAB", tabId: monitorTabId });
            }
            if (_deployTabId) {
                await bgMessage({ type: "FOCUS_TAB", tabId: _deployTabId });
                await wait(600);
            }
            return; // ✅ success — back to main loop
        }

        // ── 5b. Not confirmed — close tab and maybe retry ───
        sendStatus(`Drop ${drop}: ⚠️ Queues not paused yet (attempt ${attempt}/${MAX_ATTEMPTS}) — closing monitor tab…`);
        updateMainCard(drop, displayTotal,
            `⚠️ Not paused (attempt <strong>${attempt}/${MAX_ATTEMPTS}</strong>)${attempt < MAX_ATTEMPTS ? ' — retrying…' : ' — STOPPING'}`,
            'amber', '⚠️');

        if (monitorTabId) {
            await bgMessage({ type: "CLOSE_TAB", tabId: monitorTabId });
        }
        if (_deployTabId) {
            await bgMessage({ type: "FOCUS_TAB", tabId: _deployTabId });
            await wait(600);
        }

        if (attempt < MAX_ATTEMPTS) {
            // Re-select IPs and re-open the modal for the next attempt
            await wait(2000);
            await selectIps(allIps);
            await wait(1000);
            await openRunCommandModal();
        }
    }

    // ── 6. All attempts exhausted — run emergency RESUME+SCHEDULE, send Telegram alert and stop ──
    sendStatus(`Drop ${drop}: ❌ Servers did NOT pause after ${MAX_ATTEMPTS} attempts — running emergency RESUME+SCHEDULE…`);
    updateMainCard(drop, displayTotal,
        `❌ Servers did not pause after <strong>${MAX_ATTEMPTS} attempts</strong>.<br>Running emergency <strong>RESUME+SCHEDULE</strong>…`,
        'red', '🚨');

    try {
        _forceCloseAllModals();
        await wait(800);
        await selectIps(allIps);
        await wait(1000);
        await openRunCommandModalss();
        await executeRunCommandModal(`Emergency RESUME+SCHEDULE (pause failure)`, 2);
        sendStatus(`Drop ${drop}: Emergency RESUME+SCHEDULE completed — sending Telegram alert…`);
    } catch (resumeErr) {
        console.warn('[executePauseAndVerify] Emergency RESUME+SCHEDULE failed:', resumeErr);
    }

    updateMainCard(drop, displayTotal,
        `❌ Pause failure — sending <strong>Telegram alert</strong>…`,
        'red', '🚨');

    const now   = new Date();
    const pad   = n => String(n).padStart(2, '0');
    const dt    = `${pad(now.getDate())}-${pad(now.getMonth()+1)}-${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    const div   = '='.repeat(42);
    // Pick a random server name from the IPs list to include in the alert
    const _pauseServers = [...new Set(allIps.map(ip => (typeof _ipServerMap !== 'undefined' && _ipServerMap[ip]) || '').filter(Boolean))];
    const _pauseRandSrv = _pauseServers.length > 0 ? _pauseServers[Math.floor(Math.random() * _pauseServers.length)] : '';
    const alertLines = [
        `🚨  WARMUP CONTROLLER — PAUSE FAILURE`,
        div,
        `Date / Time  :  ${dt}`,
        ...(_pauseRandSrv ? [`Server       :  ${_pauseRandSrv}`] : []),
        div,
        `Drop         :  ${tgDrop} / ${tgTotal}`,
        `Attempts     :  ${MAX_ATTEMPTS} × 2 clicks`,
        ``,
        `The queues gmail.com/*, gmail.queue/*, googlemail.com/*`,
        `did NOT show Paused = yes in any iframe after ${MAX_ATTEMPTS} attempts.`,
        ``,
        `An emergency RESUME+SCHEDULE was executed before stopping.`,
        `The warmup process has been STOPPED automatically.`,
        div,
        `This message was sent automatically by the Warmup Extension.`,
    ];
    const alertText = '```\n' + alertLines.join('\n') + '\n```';

    try {
        await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
            method  : 'POST',
            headers : { 'Content-Type': 'application/json' },
            body    : JSON.stringify({ chat_id: telegramChatId, text: alertText, parse_mode: 'Markdown' })
        });
    } catch (tgErr) {
        console.warn('[executePauseAndVerify] Telegram alert failed:', tgErr);
    }

    // Stop the entire session
    _processState = "stopped";
    throw new ProcessStoppedError();
}

// -------------------------------------------------------
// RESUME-AND-VERIFY
// -------------------------------------------------------
// Same structure as executePauseAndVerify but for RESUME+SCHEDULE.
// After 2 Execute clicks it opens MultiMonitor and checks that at
// least one iframe shows a gmail.com/gmail-<ip> (or gmail.queue/…
// or googlemail.com/…) row with Paused = "no".
// Retries up to MAX_ATTEMPTS times, then stops session + Telegram.
// -------------------------------------------------------
async function executeResumeAndVerify(drop, displayTotal, allIps, tgDrop, tgTotal, telegramChatId) {
    const MAX_ATTEMPTS = 3;

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {

        // ── 1. Click Execute × 2 ────────────────────────────
        const form = await waitForElement('#run-cmd-form', 30000);

        const chk = await waitForElementVisible('#check-cmd-by-server', 15000);
        if (!chk.checked) { chk.click(); await wait(600); }

        const submitBtn = await waitForChildElement(form, "button[type='submit']", 15000);
        await wait(800);

        submitBtn.click();
        sendStatus(`Drop ${drop}: RESUME+SCHEDULE — attempt ${attempt}/${MAX_ATTEMPTS} (click 1/2)…`);
        updateMainCard(drop, displayTotal,
            `Attempt <strong>${attempt}/${MAX_ATTEMPTS}</strong> — RESUME click <strong>1/2</strong>…`,
            'purple', '▶️');

        await wait(5000);
        submitBtn.click();
        sendStatus(`Drop ${drop}: RESUME+SCHEDULE — attempt ${attempt}/${MAX_ATTEMPTS} (click 2/2)…`);
        updateMainCard(drop, displayTotal,
            `Attempt <strong>${attempt}/${MAX_ATTEMPTS}</strong> — RESUME click <strong>2/2</strong>…`,
            'purple', '▶️');

        // ── 2. Wait for dismiss button and close modal ───────
        const dismissBtn = await new Promise(resolve => {
            const TIMEOUT  = 90000;
            const INTERVAL = 500;
            let elapsed = 0;
            const timer = setInterval(() => {
                const btn =
                    form.querySelector("button[data-dismiss='modal']") ||
                    document.querySelector(".modal.in button[data-dismiss='modal']") ||
                    document.querySelector(".modal.show button[data-dismiss='modal']");
                if (btn) { clearInterval(timer); resolve(btn); return; }
                elapsed += INTERVAL;
                if (elapsed >= TIMEOUT) { clearInterval(timer); resolve(null); }
            }, INTERVAL);
        });

        await wait(6000);

        await _closeModalAndWait(dismissBtn, 10000);
        await wait(800);

        // ── 3. Open MultiMonitor tab ─────────────────────────
        sendStatus(`Drop ${drop}: Opening MultiMonitor to verify resume (attempt ${attempt}/${MAX_ATTEMPTS})…`);
        updateMainCard(drop, displayTotal,
            `Attempt <strong>${attempt}/${MAX_ATTEMPTS}</strong> — Opening monitor to verify resume…`,
            'green', '🖥️');

        const monitorBtn = await waitForElementVisible("#ips_by_classes_ms-multi-monitors");
        monitorBtn.click();

        // Wait for the tab to open; background handles iframe nav + 7 s wait
        sendStatus(`Drop ${drop}: Waiting for MultiMonitor tab to open…`);
        await wait(9000);

        // ── 4. Check resume status via background ────────────
        // Background navigates iframes → waits 7 s → reads Paused column
        // and returns resumed=true if any gmail.com/gmail-<ip> row shows paused=no
        sendStatus(`Drop ${drop}: Navigating iframes to Queues & checking resume status…`);
        const checkResult = await bgMessage({ type: "CHECK_RESUME_STATUS", allIps });

        const monitorTabId = checkResult ? checkResult.tabId : null;

        // ── 5a. Resumed confirmed ────────────────────────────
        if (checkResult && checkResult.resumed) {
            sendStatus(`Drop ${drop}: ✅ Resume confirmed — closing monitor tab…`);
            updateMainCard(drop, displayTotal,
                `✅ Resume confirmed on attempt <strong>${attempt}</strong> — continuing…`,
                'green', '✅');

            if (monitorTabId) await bgMessage({ type: "CLOSE_TAB", tabId: monitorTabId });
            if (_deployTabId) {
                await bgMessage({ type: "FOCUS_TAB", tabId: _deployTabId });
                await wait(600);
            }
            return; // ✅ success — back to main loop
        }

        // ── 5b. Not confirmed — close tab and maybe retry ───
        sendStatus(`Drop ${drop}: ⚠️ Queues not resumed yet (attempt ${attempt}/${MAX_ATTEMPTS}) — closing monitor tab…`);
        updateMainCard(drop, displayTotal,
            `⚠️ Not resumed (attempt <strong>${attempt}/${MAX_ATTEMPTS}</strong>)${attempt < MAX_ATTEMPTS ? ' — retrying…' : ' — STOPPING'}`,
            'amber', '⚠️');

        if (monitorTabId) await bgMessage({ type: "CLOSE_TAB", tabId: monitorTabId });
        if (_deployTabId) {
            await bgMessage({ type: "FOCUS_TAB", tabId: _deployTabId });
            await wait(600);
        }

        if (attempt < MAX_ATTEMPTS) {
            // Re-select IPs and re-open the modal for the next attempt
            await wait(2000);
            await selectIps(allIps);
            await wait(1000);
            await openRunCommandModalss();
        }
    }

    // ── 6. All attempts exhausted — run emergency RESUME+SCHEDULE, send Telegram alert and stop ──
    sendStatus(`Drop ${drop}: ❌ Servers did NOT resume after ${MAX_ATTEMPTS} attempts — running emergency RESUME+SCHEDULE…`);
    updateMainCard(drop, displayTotal,
        `❌ Servers did not resume after <strong>${MAX_ATTEMPTS} attempts</strong>.<br>Running emergency <strong>RESUME+SCHEDULE</strong>…`,
        'red', '🚨');

    try {
        _forceCloseAllModals();
        await wait(800);
        await selectIps(allIps);
        await wait(1000);
        await openRunCommandModalss();
        await executeRunCommandModal(`Emergency RESUME+SCHEDULE (resume failure)`, 2);
        sendStatus(`Drop ${drop}: Emergency RESUME+SCHEDULE completed — sending Telegram alert…`);
    } catch (resumeErr) {
        console.warn('[executeResumeAndVerify] Emergency RESUME+SCHEDULE failed:', resumeErr);
    }

    updateMainCard(drop, displayTotal,
        `❌ Resume failure — sending <strong>Telegram alert</strong>…`,
        'red', '🚨');

    const now  = new Date();
    const pad  = n => String(n).padStart(2, '0');
    const dt   = `${pad(now.getDate())}-${pad(now.getMonth()+1)}-${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    const div  = '='.repeat(42);
    // Pick a random server name from the IPs list to include in the alert
    const _resumeServers = [...new Set(allIps.map(ip => (typeof _ipServerMap !== 'undefined' && _ipServerMap[ip]) || '').filter(Boolean))];
    const _resumeRandSrv = _resumeServers.length > 0 ? _resumeServers[Math.floor(Math.random() * _resumeServers.length)] : '';
    const alertLines = [
        `🚨  WARMUP CONTROLLER — RESUME FAILURE`,
        div,
        `Date / Time  :  ${dt}`,
        ...(_resumeRandSrv ? [`Server       :  ${_resumeRandSrv}`] : []),
        div,
        `Drop         :  ${tgDrop} / ${tgTotal}`,
        `Attempts     :  ${MAX_ATTEMPTS} × 2 clicks`,
        ``,
        `The queues gmail.com/gmail-*, gmail.queue/gmail-*, googlemail.com/gmail-*`,
        `did NOT show Paused = no in any iframe after ${MAX_ATTEMPTS} attempts.`,
        ``,
        `An emergency RESUME+SCHEDULE was executed before stopping.`,
        `The warmup process has been STOPPED automatically.`,
        div,
        `This message was sent automatically by the Warmup Extension.`,
    ];
    const alertText = '```\n' + alertLines.join('\n') + '\n```';

    try {
        await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
            method  : 'POST',
            headers : { 'Content-Type': 'application/json' },
            body    : JSON.stringify({ chat_id: telegramChatId, text: alertText, parse_mode: 'Markdown' })
        });
    } catch (tgErr) {
        console.warn('[executeResumeAndVerify] Telegram alert failed:', tgErr);
    }

    // Stop the entire session
    _processState = "stopped";
    throw new ProcessStoppedError();
}

// -------------------------------------------------------
// SCHEDULE-repeat loop
// -------------------------------------------------------
async function repeatScheduleForDuration(allIps, drop, displayTotal, durationSecs) {
    const deadline  = Date.now() + durationSecs * 1000;
    let   clickCount = 0;

    updateMainCard(drop, displayTotal,
        `Repeating <strong>SCHEDULE</strong> every 3s<br>for <strong>${fmtTime(durationSecs)}</strong>…`,
        'purple', '🔁');

    showCountdownCard(durationSecs, drop, displayTotal, 'SCHEDULE loop — before monitor');

    await selectIps(allIps);
    await wait(1000);
    await openRunCommandModalScheduleOnly();

    const form    = await waitForElement("#run-cmd-form");
    const chk     = await waitForElementVisible("#check-cmd-by-server");
    if (!chk.checked) { chk.click(); await wait(500); }

    const execBtn = await waitForChildElement(form, "button[type='submit']");
    await wait(400);

    while (Date.now() < deadline) {
        execBtn.click();
        clickCount++;
        const remaining = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
        sendStatus(`Drop ${drop}: SCHEDULE click #${clickCount} — ${fmtTime(remaining)} left`);
        await wait(6000);
    }

    removeCountdownCard();
    const schedDismissBtn = await waitForChildElement(form, "button[data-dismiss='modal']");
    await _closeModalAndWait(schedDismissBtn, 10000);
    await wait(800);
}

// -------------------------------------------------------
// Build groups from current ipState targets
// -------------------------------------------------------
function buildCurrentGroups(ipState) {
    const grouped = {};
    for (const [ip, state] of Object.entries(ipState)) {
        const t = state.target;
        if (!grouped[t]) grouped[t] = [];
        grouped[t].push(ip);
    }
    return Object.entries(grouped)
        .map(([value, ips]) => ({ value: parseInt(value), ips }))
        .sort((a, b) => a.value - b.value);
}

// -------------------------------------------------------
// Run send groups for one drop
// -------------------------------------------------------
async function runDropSend(currentGroups, drop, displayTotal, startOffset = 0) {
    let cumulativeOffset = startOffset;

    for (let gi = 0; gi < currentGroups.length; gi++) {
        const { value, ips } = currentGroups[gi];

        updateMainCard(drop, displayTotal,
            `Sending group <strong>${gi + 1} / ${currentGroups.length}</strong><br>
             <strong>${ips.length}</strong> IP${ips.length > 1 ? 's' : ''} · <strong>${value.toLocaleString()}</strong> each`,
            'blue', '📤');

        _forceCloseAllModals();
        await wait(800);

        sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Selecting ${ips.length} IPs…`);
        await selectIps(ips);

        const limitValue = ips.length * value;

        sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Filling offset=${cumulativeOffset} limit=${limitValue}…`);
        const offsetInput = await waitForElement("#offset");
        const limitInput  = await waitForElement("#limit");

        offsetInput.value = 0;
        offsetInput.dispatchEvent(new Event("input",  { bubbles: true }));
        offsetInput.dispatchEvent(new Event("change", { bubbles: true }));

        limitInput.value  = limitValue;
        limitInput.dispatchEvent(new Event("input",  { bubbles: true }));
        limitInput.dispatchEvent(new Event("change", { bubbles: true }));

        await wait(800);
        cumulativeOffset += limitValue;

        sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Clicking send…`);
        const sendBtn = await waitForElement("#send-button");
        await wait(600);

        const MODAL_WAIT_MS  = 2 * 60 * 1000;
        const MODAL_POLL_MS  = 400;
        const TOTAL_LIMIT_MS = 60 * 60 * 1000;

        const overallDeadline = Date.now() + TOTAL_LIMIT_MS;

        sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Waiting for modal or toast…`);

        let sendResult = null;
        let attempt    = 0;

        while (!sendResult) {
            attempt++;

            sendBtn.click();
            sendBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));

            sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: ${attempt === 1 ? 'Waiting' : `Re-click #${attempt} — waiting`} up to 2 min for modal or toast…`);

            sendResult = await new Promise(resolve => {
                const deadline = Date.now() + MODAL_WAIT_MS;
                const timer    = setInterval(() => {
                    const toastMsg  = document.querySelector('.toast-message');
                    const toastSeen = !!(toastMsg && toastMsg.textContent.includes('Deploy has been successfully sent'));

                    const modal = document.querySelector('.modal.in, .modal.show');
                    if (modal) {
                        const hasContent =
                            modal.querySelector('.modal-content') ||
                            modal.querySelector('.modal-body');
                        if (hasContent) {
                            clearInterval(timer);
                            resolve({ modal, toast: toastSeen });
                            return;
                        }
                    }

                    if (toastSeen) {
                        clearInterval(timer);
                        resolve({ modal: null, toast: true });
                        return;
                    }

                    if (Date.now() >= deadline) {
                        clearInterval(timer);
                        resolve(null);
                    }
                }, MODAL_POLL_MS);
            });

            if (!sendResult) {
                if (Date.now() >= overallDeadline) {
                    sendStatus(`❌ No modal or toast after 1 hour — sending Telegram alert…`);
                    updateMainCard(drop, displayTotal,
                        `❌ No modal or toast after <strong>1 hour</strong> of retrying.<br>Sending Telegram alert…`,
                        'red', '🚨');

                    // Pick a random server name to include in the alert
                    const _modalFailServers = [...new Set(ips.map(ip => (typeof _ipServerMap !== 'undefined' && _ipServerMap && _ipServerMap[ip]) || '').filter(Boolean))];
                    const _modalFailRandSrv = _modalFailServers.length > 0 ? _modalFailServers[Math.floor(Math.random() * _modalFailServers.length)] : '';

                    try {
                        await sendTelegramAlert(
                            drop, displayTotal, gi + 1, currentGroups.length,
                            ips, _telegramChatId, attempt, _modalFailRandSrv
                        );
                    } catch (tgErr) {
                        console.error('[SendRetry] Telegram alert failed:', tgErr);
                    }

                    // Attempt emergency RESUME before stopping so servers are not left paused
                    try {
                        sendStatus(`❌ Send modal failure — attempting emergency RESUME before stopping…`);
                        updateMainCard(drop, displayTotal,
                            `❌ Send modal failure — running emergency <strong>RESUME</strong>…`,
                            'red', '🚨');
                        _forceCloseAllModals();
                        await wait(800);
                        // allIps is accessible via closure in runDropSend
                        const _resumeAllIps = (typeof allIps !== 'undefined' && allIps.length > 0) ? allIps : ips;
                        await selectIps(_resumeAllIps);
                        await wait(1000);
                        await openRunCommandModalss();
                        await executeRunCommandModal(`Emergency RESUME (send modal failure)`, 2);
                        sendStatus(`Emergency RESUME completed — stopping process.`);
                    } catch (resumeErr) {
                        console.warn('[SendRetry] Emergency RESUME failed:', resumeErr);
                    }

                    throw new Error(
                        `No modal or toast after 1 hour of retrying (2 min per attempt, ${attempt} attempts). ` +
                        `Group ${gi+1}/${currentGroups.length}, IPs: ${ips.join(', ')}`
                    );
                }

                const elapsedMin = Math.floor((Date.now() - (overallDeadline - TOTAL_LIMIT_MS)) / 60000);
                sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Nothing seen — retrying (attempt ${attempt}, ${elapsedMin}m / 60m elapsed)…`);
                await wait(1500);
            }
        }

        if (sendResult.modal) {
            sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Closing report modal…`);
            const closeBtn = await waitForChildElement(sendResult.modal, ".modal-header button.close[data-dismiss='modal']", 15000);
            await wait(600);
            await _closeModalAndWait(closeBtn, 8000);
            await wait(400);
        } else {
            sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: ✅ Toast detected — waiting up to 5s for modal…`);
            const lateModal = await new Promise(resolve => {
                const deadline = Date.now() + 5000;
                const t = setInterval(() => {
                    const m = document.querySelector('.modal.in, .modal.show');
                    if (m && (m.querySelector('.modal-content') || m.querySelector('.modal-body'))) {
                        clearInterval(t);
                        resolve(m);
                        return;
                    }
                    if (Date.now() >= deadline) { clearInterval(t); resolve(null); }
                }, 300);
            });

            if (lateModal) {
                sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Modal appeared — closing it…`);
                const closeBtn = await waitForChildElement(lateModal, ".modal-header button.close[data-dismiss='modal']", 10000);
                await wait(600);
                await _closeModalAndWait(closeBtn, 8000);
            } else {
                sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: ✅ No modal after 5s — moving on…`);
                _forceCloseAllModals();
            }

            await wait(400);
        }

        await wait(randomDelay());
        await checkPauseOrStop();
    }

    return cumulativeOffset;
}

// -------------------------------------------------------
// Apply all three selects for a given ISP entry { mode, value }
//
// mode = 'warmup':
//   data_providers  → option containing "Seeds"
//   data_profiles   → option containing "Seeds_Tss" (case-insensitive)
//   data_profile_isps → exact match on entry.value
//
// mode = 'passive':
//   data_providers  → option containing "data_TSS"
//   data_profiles   → option containing "Seeds"
//   data_profile_isps → exact match on entry.value
// -------------------------------------------------------
async function _applyIspEntry(drop, entry) {
    const { mode, value } = entry;

    if (mode === 'warmup') {
        // ── Data Provider: option containing "Seeds" ──────────
        const providerSel = document.getElementById('data_providers');
        if (providerSel) {
            const opt = Array.from(providerSel.options).find(o => o.text.trim().includes('Seeds'));
            if (opt) {
                providerSel.value = opt.value;
                providerSel.dispatchEvent(new Event('change', { bubbles: true }));
                sendStatus(`Drop ${drop}: [Warmup] Data Provider → "${opt.text}"…`);
            } else {
                sendStatus(`Drop ${drop}: ⚠️ [Warmup] No option containing "Seeds" in #data_providers`);
            }
        }
        await _waitForPageLoad(30000);
        await wait(3000);
        await checkPauseOrStop();

        // ── Data Profile: option containing "Seeds_Tss" ───────
        const profileSel = document.getElementById('data_profiles');
        if (profileSel) {
            const opt = Array.from(profileSel.options).find(
                o => o.text.trim().toLowerCase().includes('seeds_tss')
            );
            if (opt) {
                profileSel.value = opt.value;
                profileSel.dispatchEvent(new Event('change', { bubbles: true }));
                sendStatus(`Drop ${drop}: [Warmup] Data Profile → "${opt.text}"…`);
            } else {
                sendStatus(`Drop ${drop}: ⚠️ [Warmup] No option containing "Seeds_Tss" in #data_profiles`);
            }
        }
        await _waitForPageLoad(30000);
        await wait(3000);
        await checkPauseOrStop();

    } else {
        // ── mode === 'passive' ─────────────────────────────────

        // Data Provider: option containing "data_TSS"
        const providerSel = document.getElementById('data_providers');
        if (providerSel) {
            const opt = Array.from(providerSel.options).find(
                o => o.text.trim().includes('data_TSS')
            );
            if (opt) {
                providerSel.value = opt.value;
                providerSel.dispatchEvent(new Event('change', { bubbles: true }));
                sendStatus(`Drop ${drop}: [Passive] Data Provider → "${opt.text}"…`);
            } else {
                sendStatus(`Drop ${drop}: ⚠️ [Passive] No option containing "data_TSS" in #data_providers`);
            }
        }
        await _waitForPageLoad(30000);
        await wait(3000);
        await checkPauseOrStop();

        // Data Profile: option containing "Seeds"
        const profileSel = document.getElementById('data_profiles');
        if (profileSel) {
            const opt = Array.from(profileSel.options).find(o => o.text.trim().includes('Seeds'));
            if (opt) {
                profileSel.value = opt.value;
                profileSel.dispatchEvent(new Event('change', { bubbles: true }));
                sendStatus(`Drop ${drop}: [Passive] Data Profile → "${opt.text}"…`);
            } else {
                sendStatus(`Drop ${drop}: ⚠️ [Passive] No option containing "Seeds" in #data_profiles`);
            }
        }
        await _waitForPageLoad(30000);
        await wait(3000);
        await checkPauseOrStop();
    }

    // ── ISP Profile: exact match on entry.value ────────────────
    const ispSel = document.getElementById('data_profile_isps');
    if (ispSel) {
        const kw  = (value || '').trim();
        const opt = kw
            ? Array.from(ispSel.options).find(o => o.text.trim() === kw)
            : null;
        if (opt) {
            ispSel.value = opt.value;
            ispSel.dispatchEvent(new Event('change', { bubbles: true }));
            sendStatus(`Drop ${drop}: ISP Profile → "${opt.text}"…`);
        } else {
            sendStatus(`Drop ${drop}: ⚠️ No ISP Profile option with exact value "${kw}"`);
        }
    }
    await _waitForPageLoad(30000);
    await checkPauseOrStop();
}

// -------------------------------------------------------
// ISP Profile reset (mid-drop, between groups)
// Re-applies the three selects for the currently active entry.
// -------------------------------------------------------
async function resetIspProfile(drop, displayTotal, entry) {
    if (!entry) return;
    const modeLabel = entry.mode === 'passive' ? 'Passive' : 'Warmup';
    sendStatus(`Drop ${drop}: Resetting ISP Profile [${modeLabel}] "${entry.value}"…`);
    updateMainCard(drop, displayTotal,
        `Resetting <strong>ISP Profile</strong> [${modeLabel}] — "${entry.value}"…`,
        'purple', '🔄');

    await _applyIspEntry(drop, entry);
    sendStatus(`Drop ${drop}: ISP Profile reset complete.`);
}

// -------------------------------------------------------
// Helper: read the current lists count from #data_lists_counts
// Returns 0 if the element is absent or the value cannot be parsed.
// -------------------------------------------------------
function _readListsCount() {
    const sel = document.getElementById('data_lists_counts');
    if (!sel) return 0;
    const text = (sel.options[sel.selectedIndex] || sel.options[0] || {}).text || '';
    const m = text.match(/\((\d+)\)/);
    if (m) return parseInt(m[1]);
    return parseInt(sel.value) || 0;
}

// -------------------------------------------------------
// Helper: wait for the page-loading spinner to disappear
// -------------------------------------------------------
async function _waitForPageLoad(maxWaitMs = 60000) {
    await new Promise(resolve => {
        const POLL_MS  = 300;
        const deadline = Date.now() + maxWaitMs;
        setTimeout(function poll() {
            const spinner = document.querySelector('.page-loading');
            if (!spinner || getComputedStyle(spinner).display === 'none') { resolve(); return; }
            if (Date.now() >= deadline) { resolve(); return; }
            setTimeout(poll, POLL_MS);
        }, 800);
    });
}

// -------------------------------------------------------
// Run send groups for one drop — Data Lists mode
// -------------------------------------------------------
// ispEntries: ordered array of { mode, value } from the popup.
//
// State machine:
//   _currentEntryIndex tracks which entry is active across drops
//   (stored on the function object so it persists across calls).
//   The process stays on the current entry while listsCount > 0.
//   When listsCount = 0, it advances to the next entry.
//   The last entry (typically passive) is never advanced past —
//   it is used for all remaining drops once reached.
//
// On each drop:
//   1. Apply the current entry's three selects.
//   2. Read listsCount.
//   3. If listsCount = 0 AND not already on last entry → advance entry, re-apply, re-read.
//   4. Run send groups using that listsCount.
//   5. Between groups: resetIspProfile(currentEntry) to refresh mid-drop.
// -------------------------------------------------------
async function runDropSendDataLists(currentGroups, drop, displayTotal, startOffset = 0, ispEntries = [], tgDrop = drop, tgTotal = displayTotal, telegramChatId = _telegramChatId) {

    // Persistent entry index across drops (stored on function object)
    if (runDropSendDataLists._entryIndex === undefined) {
        runDropSendDataLists._entryIndex = 0;
    }

    const entries    = ispEntries && ispEntries.length > 0 ? ispEntries : [{ mode: 'warmup', value: '' }];
    const lastIndex  = entries.length - 1;

    // ── 1. Apply current entry & read listsCount ──────────────
    let entryIndex  = runDropSendDataLists._entryIndex;
    // Clamp in case entries were reduced
    if (entryIndex > lastIndex) entryIndex = lastIndex;

    let currentEntry = entries[entryIndex];
	runDropSendDataLists._lastMode = currentEntry.mode;
    updateMainCard(drop, displayTotal,
        `Applying ISP entry <strong>${entryIndex + 1}/${entries.length}</strong> [${currentEntry.mode}] "${currentEntry.value}"…`,
        'purple', '🔄');
    sendStatus(`Drop ${drop}: Applying ISP entry ${entryIndex + 1}/${entries.length} [${currentEntry.mode}] "${currentEntry.value}"…`);

    await _applyIspEntry(drop, currentEntry);
    await wait(3000);
    await checkPauseOrStop();

    // ── 2. Handle Passive Lists immediately ──
    if (currentEntry.mode === 'passive') {
		runDropSendDataLists._lastMode = 'passive';
        sendStatus(`Drop ${drop}: Passive Lists mode reached. Reverting to simple offset 0...`);
        return runDropSend(currentGroups, drop, displayTotal, 0);
    }

    // ── 3. Handle Warmup Lists logic (listsCount) ──
    let listsCount = _readListsCount();
    sendStatus(`Drop ${drop}: Lists count = ${listsCount.toLocaleString()} (entry ${entryIndex + 1}/${entries.length})`);

    while (listsCount <= 0 && entryIndex < lastIndex) {
        entryIndex++;
        currentEntry = entries[entryIndex];

        sendStatus(`Drop ${drop}: Lists count = 0 → advancing to entry ${entryIndex + 1}/${entries.length} [${currentEntry.mode}] "${currentEntry.value}"…`);
        updateMainCard(drop, displayTotal,
            `Lists count = 0 → entry <strong>${entryIndex + 1}/${entries.length}</strong> [${currentEntry.mode}] "${currentEntry.value}"…`,
            'amber', '🔄');

        await _applyIspEntry(drop, currentEntry);
        await wait(3000);
        await checkPauseOrStop();

        if (currentEntry.mode === 'passive') {
            runDropSendDataLists._entryIndex = entryIndex;
			runDropSendDataLists._lastMode = 'passive';
            sendStatus(`Drop ${drop}: Passive Lists mode reached. Reverting to simple offset 0...`);
            return runDropSend(currentGroups, drop, displayTotal, 0);
        }

        listsCount = _readListsCount();
        sendStatus(`Drop ${drop}: Lists count = ${listsCount.toLocaleString()} (entry ${entryIndex + 1}/${entries.length})`);
    }

    // ── 4. Save the active index so the next drop starts here ──
    runDropSendDataLists._entryIndex = entryIndex;
runDropSendDataLists._lastMode = 'warmup';
    // Handle still-zero on last entry (safety fallback)
    if (listsCount <= 0) {
        sendStatus(`Drop ${drop}: ⚠️ Lists count still 0 on last entry — falling back to simple offset 0.`);
        return runDropSend(currentGroups, drop, displayTotal, 0);
    }

    sendStatus(`Drop ${drop}: Warmup Lists — entry ${entryIndex + 1}/${entries.length}, lists count = ${listsCount.toLocaleString()}, offset = ${startOffset.toLocaleString()}`);

    let cumulativeOffset = startOffset;

    for (let gi = 0; gi < currentGroups.length; gi++) {
        const { value, ips } = currentGroups[gi];

        updateMainCard(drop, displayTotal,
            `Sending group <strong>${gi + 1} / ${currentGroups.length}</strong><br>
             <strong>${ips.length}</strong> IP${ips.length > 1 ? 's' : ''} · <strong>${value.toLocaleString()}</strong> each · 
             offset <strong>${cumulativeOffset.toLocaleString()}</strong> / ${listsCount.toLocaleString()}`,
            'blue', '📤');

        _forceCloseAllModals();
        await wait(800);

        await selectIps(ips);

        const totalLimit = ips.length * value;
        const spaceLeft  = listsCount - cumulativeOffset;

        if (totalLimit <= spaceLeft) {
            // ── No wrap needed ────────────────────────────────
            sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: offset=${cumulativeOffset} limit=${totalLimit} (no wrap)`);
            await _doSingleGroupSend(drop, displayTotal, gi, currentGroups.length, ips, cumulativeOffset, totalLimit);
            cumulativeOffset += totalLimit;

        } else {
            // ── Wrap needed — Part A + Part B (+ extra full passes) ──
            const limitA = spaceLeft;
            let   limitB = totalLimit - limitA;

            // Part A: cumulativeOffset → listsCount
            if (limitA > 0) {
                sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Part A offset=${cumulativeOffset} limit=${limitA}`);
                updateMainCard(drop, displayTotal,
                    `Group <strong>${gi + 1}/${currentGroups.length}</strong> Part A — offset <strong>${cumulativeOffset.toLocaleString()}</strong> → <strong>${listsCount.toLocaleString()}</strong>`,
                    'blue', '📤');
                await _doSingleGroupSend(drop, displayTotal, gi, currentGroups.length, ips, cumulativeOffset, limitA, 'A');
            }

            // ISP Profile reset + fresh listsCount after Part A
            updateMainCard(drop, displayTotal,
                `Group <strong>${gi + 1}/${currentGroups.length}</strong> — Resetting <strong>ISP Profile</strong> after Part A…`,
                'purple', '🔄');
            await resetIspProfile(drop, displayTotal, currentEntry);
            listsCount = _readListsCount();
            sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Fresh lists count after Part A = ${listsCount.toLocaleString()}`);

            // Safety: limitB may exceed listsCount — send full-list passes until it fits
            let partBIndex = 0;
            while (limitB > listsCount) {
                partBIndex++;
                const passLabel = `B${partBIndex}`;
                sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Part ${passLabel} offset=0 limit=${listsCount} (full-list pass)`);
                updateMainCard(drop, displayTotal,
                    `Group <strong>${gi + 1}/${currentGroups.length}</strong> Part ${passLabel} — full-list pass`,
                    'blue', '🔄');

                _forceCloseAllModals();
                await wait(600);
                await selectIps(ips);

                await _doSingleGroupSend(drop, displayTotal, gi, currentGroups.length, ips, 0, listsCount, passLabel);
                limitB -= listsCount;

                updateMainCard(drop, displayTotal,
                    `Group <strong>${gi + 1}/${currentGroups.length}</strong> — Resetting <strong>ISP Profile</strong> after Part ${passLabel}…`,
                    'purple', '🔄');
                await resetIspProfile(drop, displayTotal, currentEntry);
                listsCount = _readListsCount();
                sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Fresh lists count after Part ${passLabel} = ${listsCount.toLocaleString()}`);
            }

            // Final Part B (remainder)
            const finalBLabel = partBIndex > 0 ? `B${partBIndex + 1}` : 'B';
            sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Part ${finalBLabel} offset=0 limit=${limitB} (wrap remainder)`);
            updateMainCard(drop, displayTotal,
                `Group <strong>${gi + 1}/${currentGroups.length}</strong> Part ${finalBLabel} — wrap-around <strong>0</strong> → <strong>${limitB.toLocaleString()}</strong>`,
                'blue', '🔄');

            _forceCloseAllModals();
            await wait(600);
            await selectIps(ips);

            await _doSingleGroupSend(drop, displayTotal, gi, currentGroups.length, ips, 0, limitB, finalBLabel);
            cumulativeOffset = limitB;
        }

        // ISP Profile reset after every group except the last
        if (gi < currentGroups.length - 1) {
            updateMainCard(drop, displayTotal,
                `Group <strong>${gi + 1}/${currentGroups.length}</strong> done — Resetting <strong>ISP Profile</strong>…`,
                'purple', '🔄');
            await resetIspProfile(drop, displayTotal, currentEntry);
            listsCount = _readListsCount();
            if (listsCount > 0) {
                sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: Fresh lists count = ${listsCount.toLocaleString()}`);
            } else {
                sendStatus(`Drop ${drop} · Group ${gi+1}/${currentGroups.length}: ⚠️ Lists count = 0 after group reset — keeping previous value`);
            }
        }

        await wait(randomDelay());
        await checkPauseOrStop();
    }

    return cumulativeOffset;
}

// -------------------------------------------------------
// Internal helper: fill offset+limit fields and click send
// Extracted so both runDropSend and runDropSendDataLists share it.
// -------------------------------------------------------
async function _doSingleGroupSend(drop, displayTotal, gi, totalGroups, ips, offsetVal, limitVal, partLabel = '') {
    const partTag = partLabel ? ` (Part ${partLabel})` : '';

    const offsetInput = await waitForElement("#offset");
    const limitInput  = await waitForElement("#limit");

    offsetInput.value = offsetVal;
    offsetInput.dispatchEvent(new Event("input",  { bubbles: true }));
    offsetInput.dispatchEvent(new Event("change", { bubbles: true }));

    limitInput.value  = limitVal;
    limitInput.dispatchEvent(new Event("input",  { bubbles: true }));
    limitInput.dispatchEvent(new Event("change", { bubbles: true }));

    await wait(800);

    sendStatus(`Drop ${drop} · Group ${gi+1}/${totalGroups}${partTag}: Clicking send…`);
    const sendBtn = await waitForElement("#send-button");
    await wait(600);

    const MODAL_WAIT_MS  = 2 * 60 * 1000;
    const MODAL_POLL_MS  = 400;
    const TOTAL_LIMIT_MS = 60 * 60 * 1000;
    const overallDeadline = Date.now() + TOTAL_LIMIT_MS;

    let sendResult = null;
    let attempt    = 0;

    while (!sendResult) {
        attempt++;
        sendBtn.click();
        sendBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        sendStatus(`Drop ${drop} · Group ${gi+1}/${totalGroups}${partTag}: ${attempt === 1 ? 'Waiting' : `Re-click #${attempt} — waiting`} up to 2 min…`);

        sendResult = await new Promise(resolve => {
            const deadline = Date.now() + MODAL_WAIT_MS;
            const timer    = setInterval(() => {
                const toastMsg  = document.querySelector('.toast-message');
                const toastSeen = !!(toastMsg && toastMsg.textContent.includes('Deploy has been successfully sent'));
                const modal = document.querySelector('.modal.in, .modal.show');
                if (modal) {
                    const hasContent = modal.querySelector('.modal-content') || modal.querySelector('.modal-body');
                    if (hasContent) { clearInterval(timer); resolve({ modal, toast: toastSeen }); return; }
                }
                if (toastSeen) { clearInterval(timer); resolve({ modal: null, toast: true }); return; }
                if (Date.now() >= deadline) { clearInterval(timer); resolve(null); }
            }, MODAL_POLL_MS);
        });

        if (!sendResult) {
            if (Date.now() >= overallDeadline) {
                sendStatus(`❌ No modal or toast after 1 hour${partTag} — sending Telegram alert…`);
                updateMainCard(drop, displayTotal,
                    `❌ No modal or toast after <strong>1 hour</strong>${partTag ? ' (Part ' + partLabel + ')' : ''}.<br>Sending Telegram alert…`,
                    'red', '🚨');
                // Pick a random server name to include in the alert
                const _dsgFailServers = [...new Set(ips.map(ip => (typeof _ipServerMap !== 'undefined' && _ipServerMap && _ipServerMap[ip]) || '').filter(Boolean))];
                const _dsgFailRandSrv = _dsgFailServers.length > 0 ? _dsgFailServers[Math.floor(Math.random() * _dsgFailServers.length)] : '';
                try { await sendTelegramAlert(drop, displayTotal, gi + 1, totalGroups, ips, _telegramChatId, attempt, _dsgFailRandSrv); }
                catch (tgErr) { console.error('[SendRetry] Telegram alert failed:', tgErr); }

                // Attempt emergency RESUME before stopping so servers are not left paused
                try {
                    sendStatus(`❌ Send modal failure${partTag} — attempting emergency RESUME before stopping…`);
                    updateMainCard(drop, displayTotal,
                        `❌ Send modal failure — running emergency <strong>RESUME</strong>…`,
                        'red', '🚨');
                    _forceCloseAllModals();
                    await wait(800);
                    await selectIps(ips);
                    await wait(1000);
                    await openRunCommandModalss();
                    await executeRunCommandModal(`Emergency RESUME (send modal failure${partTag})`, 2);
                    sendStatus(`Emergency RESUME completed — stopping process.`);
                } catch (resumeErr) {
                    console.warn('[SendRetry] Emergency RESUME failed:', resumeErr);
                }

                throw new Error(`No modal or toast after 1 hour${partTag}. Group ${gi+1}/${totalGroups}, IPs: ${ips.join(', ')}`);
            }
            const elapsedMin = Math.floor((Date.now() - (overallDeadline - TOTAL_LIMIT_MS)) / 60000);
            sendStatus(`Drop ${drop} · Group ${gi+1}/${totalGroups}${partTag}: Nothing seen — retrying (attempt ${attempt}, ${elapsedMin}m/60m)…`);
            await wait(1500);
        }
    }

    if (sendResult.modal) {
        sendStatus(`Drop ${drop} · Group ${gi+1}/${totalGroups}${partTag}: Closing report modal…`);
        const closeBtn = await waitForChildElement(sendResult.modal, ".modal-header button.close[data-dismiss='modal']", 15000);
        await wait(600);
        await _closeModalAndWait(closeBtn, 8000);
        await wait(400);
    } else {
        sendStatus(`Drop ${drop} · Group ${gi+1}/${totalGroups}${partTag}: ✅ Toast detected — waiting up to 5s for modal…`);
        const lateModal = await new Promise(resolve => {
            const deadline = Date.now() + 5000;
            const t = setInterval(() => {
                const m = document.querySelector('.modal.in, .modal.show');
                if (m && (m.querySelector('.modal-content') || m.querySelector('.modal-body'))) { clearInterval(t); resolve(m); return; }
                if (Date.now() >= deadline) { clearInterval(t); resolve(null); }
            }, 300);
        });
        if (lateModal) {
            const closeBtn = await waitForChildElement(lateModal, ".modal-header button.close[data-dismiss='modal']", 10000);
            await wait(600);
            await _closeModalAndWait(closeBtn, 8000);
        } else {
            _forceCloseAllModals();
        }
        await wait(400);
    }
}

// -------------------------------------------------------
// Read queue data from multi_monitor iframes
// -------------------------------------------------------
async function readQueueData(allIps, ipServerMap = {}) {
    const results = {};
    allIps.forEach(ip => { results[ip] = -1; });

    const { urls, tabId, iframeServerMap } = await bgMessage({ type: "GET_MONITOR_IFRAME_URLS" });

    if (!urls || urls.length === 0) {
        console.warn("No monitor iframe URLs found.");
        return { queueResults: results, downServers: [] };
    }

    const iframeUrls = [];
    for (const ip of allIps) {
        const matchedUrl = urls.find(u => u.includes(ip));
        if (matchedUrl) {
            iframeUrls.push({ ip, url: matchedUrl });
        } else {
            urls.forEach(u => iframeUrls.push({ ip, url: u }));
        }
    }

    const fetchResults = await bgMessage({
        type           : "FETCH_QUEUE_DATA",
        iframeUrls,
        iframeServerMap: iframeServerMap || {}
    });

    // downServerNames come from FETCH_QUEUE_DATA frame content detection
    const downServers = (fetchResults && fetchResults.downServerNames) ? fetchResults.downServerNames : [];

    if (fetchResults && fetchResults.results) {
        fetchResults.results.forEach(({ ip, rcpt, _serverDown }) => {
            if (_serverDown || rcpt === -2) {
                results[ip] = -2; // server down marker
            } else if (rcpt >= 0) {
                results[ip] = (results[ip] === -1 ? 0 : results[ip]) + rcpt;
            }
        });
    }

    // Also propagate down status to all IPs sharing the same server name
    if (downServers.length > 0 && ipServerMap) {
        allIps.forEach(ip => {
            const srv = ipServerMap[ip];
            if (srv && downServers.includes(srv) && results[ip] !== -2) {
                results[ip] = -2;
            }
        });
    }

    if (tabId) await bgMessage({ type: "CLOSE_TAB", tabId });
    if (_deployTabId) { await bgMessage({ type: "FOCUS_TAB", tabId: _deployTabId }); await wait(600); }

    return { queueResults: results, downServers };
}

// ===============================
// Select IPs
// ===============================

async function selectIps(ips) {
    _forceCloseAllModals();
    await wait(300);

    const textarea  = await waitForElement("#servers_by_providers_ms-select-search-option");
    const selectBtn = await waitForElement("#servers_by_providers_ms-select");

    textarea.value = '';
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
    await wait(300);
    textarea.value = ips.join("\n");
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
    await wait(1500);

    selectBtn.click();
    await wait(2000);
}

// ===============================
// Modal helpers
// ===============================

async function openRunCommandModal() {
    const runCmdBtn = await waitForElementVisible("#ips_by_classes_ms-run-cmd");
    runCmdBtn.click(); await wait(randomDelay());
    const selAll = await waitForElementVisible("#servermulti-select-all");
    selAll.click(); await wait(randomDelay());
    for (const cmd of ["PAUSE","DELETE","RESET","SCHEDULE"]) {
        const item = await waitForCommandItem(cmd);
        item.click(); await wait(300);
    }
    await wait(500);
    const qAll = await waitForElementVisible("#queue-multi-select-all");
    qAll.click(); await wait(randomDelay());
}

async function openRunCommandModalss() {
    const runCmdBtn = await waitForElementVisible("#ips_by_classes_ms-run-cmd");
    runCmdBtn.click(); await wait(randomDelay());
    const selAll = await waitForElementVisible("#servermulti-select-all");
    selAll.click(); await wait(randomDelay());
    for (const cmd of ["RESUME","SCHEDULE"]) {
        const item = await waitForCommandItem(cmd);
        item.click(); await wait(300);
    }
    await wait(500);
    const qAll = await waitForElementVisible("#queue-multi-select-all");
    qAll.click(); await wait(randomDelay());
}

async function openRunCommandModalScheduleOnly() {
    const runCmdBtn = await waitForElementVisible("#ips_by_classes_ms-run-cmd");
    runCmdBtn.click(); await wait(randomDelay());
    const selAll = await waitForElementVisible("#servermulti-select-all");
    selAll.click(); await wait(randomDelay());
    const item = await waitForCommandItem("SCHEDULE");
    item.click(); await wait(500);
    const qAll = await waitForElementVisible("#queue-multi-select-all");
    qAll.click(); await wait(randomDelay());
}

async function openRunCommandModalDelete() {
    const runCmdBtn = await waitForElementVisible("#ips_by_classes_ms-run-cmd");
    runCmdBtn.click(); await wait(randomDelay());
    const selAll = await waitForElementVisible("#servermulti-select-all");
    selAll.click(); await wait(randomDelay());
    const item = await waitForCommandItem("DELETE");
    item.click(); await wait(500);
    const qAll = await waitForElementVisible("#queue-multi-select-all");
    qAll.click(); await wait(randomDelay());
}

// ===============================
// EMAIL COUNT FEATURE
// ===============================

// ── Extract Subject and From from the headers[] textarea ─────
function extractSubjectAndFrom() {
    const textarea = document.querySelector('textarea[name="headers[]"]');
    if (!textarea) return { subject: '', from: '' };

    const text    = textarea.value;
    let subject   = '';
    let fromEmail = '';

    // Extract Subject line
    const subjectMatch = text.match(/^Subject:\s*(.+)$/m);
    if (subjectMatch) subject = subjectMatch[1].trim();

    // Extract From line — take only the display name/address part
    const fromMatch = text.match(/^From:\s*(.+)$/m);
    if (fromMatch) {
        // Strip angle-bracket address if present, keep display name
        const raw = fromMatch[1].trim();
        // e.g. "A U T O Ins. <dguefen_xxx@yyy>" → "A U T O Ins."
        const nameOnly = raw.replace(/<[^>]+>/, '').trim();
        fromEmail = nameOnly || raw;
    }

    return { subject, from: fromEmail };
}

// ── countEmailsCore (inline copy for content script) ─────────
async function countEmailsCore(params) {
    const { email, password, subject = '', from = '', receivedAfter = '' } = params;

    if (!email || !email.trim()) return { success: false, error: 'Email is required', type: 'validation_error' };
    if (!password || !password.trim()) return { success: false, error: 'Password is required', type: 'validation_error' };

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) return { success: false, error: 'Invalid email format', type: 'validation_error' };

    const formattedPassword = password.replace(/\s/g, '');
    const API_URL = 'http://tsstools.online:5000/count_emails';

    try {
        const requestBody = {
            email      : email.trim(),
            app_password: formattedPassword,
            subject    : subject.trim() || null,
            from       : from.trim()    || null
        };
        if (receivedAfter) requestBody.received_after = receivedAfter;

        const response = await fetch(API_URL, {
            method : 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body   : JSON.stringify(requestBody)
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Server error: ${response.status} - ${errorText}`);
        }

        const data = await response.json();

        if (data.success) {
            return {
                success    : true,
                inbox_count: data.inbox_count || 0,
                spam_count : data.spam_count  || 0,
                total_count: data.total_count || 0
            };
        } else {
            return { success: false, error: data.error || 'Unknown error', type: 'server_error' };
        }
    } catch (error) {
        let errorMessage = error.message;
        let errorType    = 'network_error';
        if (error.name === 'TypeError' && error.message.includes('fetch')) {
            errorMessage = 'Network error: Cannot connect to server';
        } else if (error.message.includes('Failed to fetch')) {
            errorMessage = 'Connection failed: Server might be down';
            errorType    = 'connection_error';
        }
        return { success: false, error: errorMessage, type: errorType };
    }
}

// ── Save drop results to database ────────────────────────────
async function saveToDatabase(drop, tgResults, toleranceRate, downServers, processType, emailCountData) {
    const API_URL      = 'http://tsstools.online:5000/save_db';
    const API_PASSWORD = 'PAsswOrdCheckker';

    // Extract entity from server name: "s_tss1_4876" → "tss1"
    function extractEntity(serverName) {
        if (!serverName) return '';
        const parts = serverName.split('_');
        // ["s", "tss1", "4876"] → parts[1] = "tss1"
        return parts.length >= 3 ? parts[1] : (parts.length >= 2 ? parts[1] : serverName);
    }

    const now     = new Date();
    const pad     = n => String(n).padStart(2, '0');
    const dropDate = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
    const dropTime = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;

    const totalSend    = tgResults.reduce((s, r) => s + r.target,     0);
    const totalOut     = tgResults.reduce((s, r) => s + r.reallySent, 0);
    const deliveryRate = totalSend > 0
        ? parseFloat(((totalOut / totalSend) * 100).toFixed(2))
        : 0;

    // Extract entity from the first server name found
    const serverNames = [...new Set(tgResults.map(r => r.server).filter(Boolean))];
    const entity      = serverNames.length > 0 ? extractEntity(serverNames[0]) : '';
    const listType = processType === 'passive' ? 'Passive Lists' : 'Warmup Lists';

    // Build serveurs — one entry per unique server
    const seenSrv = new Set();
    const serverOrder = [];
    tgResults.forEach(r => {
        if (r.server && !seenSrv.has(r.server)) {
            seenSrv.add(r.server);
            serverOrder.push(r.server);
        }
    });

    const serveurs = serverOrder.map(srv => {
        const srvIps  = tgResults.filter(r => r.server === srv);
        const isDown  = downServers.includes(srv) || srvIps.every(r => r.serverDown);
        const srvIn   = srvIps.reduce((s, r) => s + r.target,     0);
        const srvOut  = srvIps.reduce((s, r) => s + r.reallySent, 0);
        const srvRate = (!isDown && srvIn > 0)
            ? parseFloat(((srvOut / srvIn) * 100).toFixed(2))
            : 0;

        return {
            serveur_name  : srv,
            total_in      : isDown ? 0 : srvIn,
            total_out     : isDown ? 0 : srvOut,
            delivery_rate : isDown ? 0 : srvRate,
            ips: srvIps.map(r => {
                const ipRate = (!r.serverDown && r.target > 0)
                    ? parseFloat(((r.reallySent / r.target) * 100).toFixed(2))
                    : 0;
                return {
                    ip            : r.ip,
                    total_in      : r.serverDown ? 0 : r.target,
                    total_out     : r.serverDown ? 0 : r.reallySent,
                    delivery_rate : r.serverDown ? 0 : ipRate
                };
            })
        };
    });

    // Build emails section — empty array when email count is disabled
    const emails = [];
    if (emailCountData) {
        emails.push({
            gmail_account : emailCountData.gmailAccount || '',
            From_email    : emailCountData.fromEmail    || '',
            subject_email : emailCountData.subject      || '',
            total_inbox   : emailCountData.inboxCount   || 0,
            total_spam    : emailCountData.spamCount    || 0
        });
    }

    const payload = {
        password: API_PASSWORD,
        drop_details: {
            entity,
            drop_date    : dropDate,
            drop_time    : dropTime,
            total_in     : totalSend,
            total_out    : totalOut,
            list_type    : listType,
            tolerance    : toleranceRate,
            delivery_rate: deliveryRate
        },
        serveurs,
        emails
    };

    try {
        console.log(`[DB] Saving Drop ${drop} to database…`);
        const response = await fetch(API_URL, {
            method  : 'POST',
            headers : { 'Content-Type': 'application/json' },
            body    : JSON.stringify(payload)
        });
        const result = await response.json();
        if (result.success) {
            console.log(`[DB] ✅ Drop ${drop} saved — ID: ${result.drop_id}`);
        } else {
            console.error(`[DB] ❌ Drop ${drop} save failed:`, result.error);
        }
        return result;
    } catch (err) {
        console.error('[DB] Save error:', err);
        return { success: false, error: err.message };
    }
}

// ── Merged Telegram report: warmup results + optional email count ─
// Called after DELETE, once per drop.
//
// tgResults    : array of { ip, server, serverDown, target, reallySent }
// resumeTime   : timestamp (ms) of when RESUME was executed this drop
// emailCfg     : null → no email count; or { gmailEmail, gmailPassword, emailCountDelay }
//
// Flow:
//   1. If emailCfg is set: wait emailCountDelay, then count emails.
//   2. Build the merged message (warmup section always present,
//      email count section appended only when emailCfg is set).
//   3. Send once to Telegram.
async function runMergedTelegramReport(drop, displayTotal, tgDrop, tgTotal, tgResults, resumeTime, telegramChatId, toleranceRate, downServers, processType, emailCfg, spamStopMode, spamStopValue, dropNote = '') {

    let emailCountData = null;

    if (emailCfg) {
        const { gmailEmail, gmailPassword, emailCountDelay } = emailCfg;

        // ── Wait the configured delay ────────────────────────
        if (emailCountDelay > 0) {
            showCountdownCard(emailCountDelay, drop, displayTotal, 'Waiting before email count');
            sendStatus(`Drop ${drop}: Waiting ${fmtTime(emailCountDelay)} before counting emails…`);
            await pauseAwareWait(emailCountDelay * 1000, drop, displayTotal, 'Waiting before email count');
            removeCountdownCard();
        }

        await checkPauseOrStop();

        // ── Extract subject / from from the headers textarea ─
        const { subject, from } = extractSubjectAndFrom();

        // ── Build receivedAfter: resumeTime minus 1 hour ─────
        const searchFromMs   = resumeTime - 60 * 60 * 1000;
        const searchFromDate = new Date(searchFromMs);
        const pad = n => String(n).padStart(2, '0');
        const receivedAfter =
            `${searchFromDate.getFullYear()}-${pad(searchFromDate.getMonth()+1)}-${pad(searchFromDate.getDate())}` +
            `T${pad(searchFromDate.getHours())}:${pad(searchFromDate.getMinutes())}`;

        updateMainCard(drop, displayTotal,
            `Counting emails in <strong>${gmailEmail}</strong>…`,
            'blue', '📧');
        sendStatus(`Drop ${drop}: Counting emails (received after ${receivedAfter})…`);

        const countResult = await countEmailsCore({
            email        : gmailEmail,
            password     : gmailPassword,
            subject      : subject || '',
            from         : from    || '',
            receivedAfter: receivedAfter
        });

        const countTime = Date.now();

        if (countResult.success) {
            sendStatus(`Drop ${drop}: Email count done — Total=${countResult.total_count} Inbox=${countResult.inbox_count} Spam=${countResult.spam_count}`);
            updateMainCard(drop, displayTotal,
                `Email count done — Total: <strong>${countResult.total_count.toLocaleString()}</strong> · Inbox: <strong>${countResult.inbox_count.toLocaleString()}</strong> · Spam: <strong>${countResult.spam_count.toLocaleString()}</strong>`,
                'green', '📧');
        } else {
            sendStatus(`Drop ${drop}: Email count failed — ${countResult.error}`);
            updateMainCard(drop, displayTotal,
                `Email count failed: <strong>${countResult.error}</strong>`,
                'amber', '⚠️');
        }

        emailCountData = {
            inboxCount  : countResult.success ? countResult.inbox_count : 0,
            spamCount   : countResult.success ? countResult.spam_count  : 0,
            totalCount  : countResult.success ? countResult.total_count : 0,
            subject     : subject || '',
            fromEmail   : from    || '',
            resumeTime,
            countTime,
            gmailAccount: gmailEmail
        };

        browser.runtime.sendMessage({ type: 'EMAIL_COUNT_SENDING', drop });

        // ── Spam stop threshold check ────────────────────────
        if (countResult.success && spamStopMode && spamStopMode !== 'none' && spamStopValue > 0) {
            const { inbox_count, spam_count, total_count } = countResult;
            let thresholdBreached = false;
            let stopReason        = '';

            if (spamStopMode === 'number') {
                if (spam_count >= spamStopValue) {
                    thresholdBreached = true;
                    stopReason = `Spam count (${spam_count.toLocaleString()}) reached the limit of ${spamStopValue.toLocaleString()} messages.`;
                }
            } else if (spamStopMode === 'percentage') {
                const inboxRate = total_count > 0 ? (inbox_count / total_count) * 100 : 100;
                if (inboxRate <= spamStopValue) {
                    thresholdBreached = true;
                    stopReason = `Inbox rate (${inboxRate.toFixed(1)}%) dropped to or below the ${spamStopValue}% threshold.`;
                }
            }

            if (thresholdBreached) {
                // ── Send Telegram alert before stopping ──────
                const now = new Date();
                const _p  = n => String(n).padStart(2, '0');
                const dt  = `${_p(now.getDate())}-${_p(now.getMonth()+1)}-${now.getFullYear()}  ${_p(now.getHours())}:${_p(now.getMinutes())}:${_p(now.getSeconds())}`;
                const div = '='.repeat(42);
                const alertLines = [
                    `🛑  WARMUP CONTROLLER — SPAM THRESHOLD EXCEEDED`,
                    div,
                    `Date / Time  :  ${dt}`,
                    div,
                    `Drop         :  ${tgDrop} / ${tgTotal}`,
                    ``,
                    `REASON`,
                    stopReason,
                    ``,
                    `Email Count Results:`,
                    `  Inbox  : ${inbox_count.toLocaleString()}`,
                    `  Spam   : ${spam_count.toLocaleString()}`,
                    `  Total  : ${total_count.toLocaleString()}`,
                    `  Inbox% : ${total_count > 0 ? ((inbox_count / total_count) * 100).toFixed(1) : 0}%`,
                    ``,
                    `The warmup process has been STOPPED automatically.`,
                    div,
                    `This message was sent automatically by the Warmup Extension.`,
                ];
                const alertText = '```\n' + alertLines.join('\n') + '\n```';

                sendStatus(`Drop ${drop}: 🛑 Spam threshold exceeded — ${stopReason} Sending alert…`);
                updateMainCard(drop, displayTotal,
                    `🛑 Spam threshold exceeded!<br><strong>${stopReason}</strong><br>Sending Telegram alert & stopping…`,
                    'red', '🛑');

                try {
                    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
                        method  : 'POST',
                        headers : { 'Content-Type': 'application/json' },
                        body    : JSON.stringify({ chat_id: telegramChatId, text: alertText, parse_mode: 'Markdown' })
                    });
                } catch (tgErr) {
                    console.warn('[SpamThreshold] Telegram alert failed:', tgErr);
                }

                // Mark process as stopped — the throw below will propagate up
                // through the main loop catch block and trigger the full cleanup.
                _processState = "stopped";
                throw new ProcessStoppedError();
            }
        }
    }

    // ── Send merged Telegram message ─────────────────────────
    updateMainCard(drop, displayTotal,
        `Sending drop report to <strong>Telegram</strong>…`,
        'purple', '✈️');
    sendStatus(`Drop ${drop}: Sending Telegram report…`);
    browser.runtime.sendMessage({ type: "TG_SENDING", drop });

    try {
        const tgResult = await sendMergedReport(
            tgDrop, tgTotal, tgResults,
            telegramChatId,
            toleranceRate,
            downServers,
            processType,
            emailCountData,
            dropNote
        );

        if (tgResult.success) {
            updateMainCard(drop, displayTotal,
                `Telegram report sent for Drop ${drop}`,
                'green', '✅');
            sendStatus(`Drop ${drop}: Telegram report sent successfully`);
            browser.runtime.sendMessage({ type: "TG_SENT", drop, success: true, error: '' });
            if (emailCfg) {
                browser.runtime.sendMessage({ type: 'EMAIL_COUNT_SENT', drop, success: true, error: '' });
            }
        } else {
            updateMainCard(drop, displayTotal,
                `Telegram failed: <strong>${tgResult.error}</strong>`,
                'amber', '⚠️');
            sendStatus(`Drop ${drop}: Telegram failed — ${tgResult.error}`);
            browser.runtime.sendMessage({ type: "TG_SENT", drop, success: false, error: tgResult.error });
            if (emailCfg) {
                browser.runtime.sendMessage({ type: 'EMAIL_COUNT_SENT', drop, success: false, error: tgResult.error });
            }
        }
    } catch (tgErr) {
        updateMainCard(drop, displayTotal,
            `Telegram error: <strong>${tgErr.message}</strong>`,
            'amber', '⚠️');
        sendStatus(`Drop ${drop}: Telegram error — ${tgErr.message}`);
        browser.runtime.sendMessage({ type: "TG_SENT", drop, success: false, error: tgErr.message });
        if (emailCfg) {
            browser.runtime.sendMessage({ type: 'EMAIL_COUNT_SENT', drop, success: false, error: tgErr.message });
        }
    }

    // ── Save to database (always runs after Telegram, regardless of TG success) ──
    try {
        updateMainCard(drop, displayTotal,
            `Saving Drop ${drop} to <strong>database</strong>…`,
            'blue', '💾');
        sendStatus(`Drop ${drop}: Saving to database…`);

        const dbResult = await saveToDatabase(
            drop, tgResults, toleranceRate, downServers, processType, emailCountData
        );

        if (dbResult.success) {
            sendStatus(`Drop ${drop}: ✅ Database saved (ID: ${dbResult.drop_id})`);
            updateMainCard(drop, displayTotal,
                `Drop ${drop} saved to database — ID: <strong>${dbResult.drop_id}</strong>`,
                'green', '💾');
        } else {
            sendStatus(`Drop ${drop}: ⚠️ Database save failed: ${dbResult.error}`);
            updateMainCard(drop, displayTotal,
                `⚠️ Database save failed: <strong>${dbResult.error}</strong>`,
                'amber', '⚠️');
        }
    } catch (dbErr) {
        console.error('[DB] Unexpected error:', dbErr);
        sendStatus(`Drop ${drop}: ⚠️ Database error: ${dbErr.message}`);
    }
}