const GOOGLE_SHEETS_CONFIG = {
  spreadsheetId: "1GHQMEQ73FYG_FAm6oghEVcYZpWHhnhzCNooKn5mvvf8",
  credentialsFile: "queues-monitor.json"
};


const GOOGLE_SHEETS_CREDENTIALS = {
  "type": "service_account",
  "project_id": "omega-moonlight-468714-t6",
  "private_key_id": "97ceba5d07c47d4253cb2e51c5cd2d5156ac8e4e",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC5TsPkGRE56+wn\nwd/xSxb25Xgk1OHOsXzNoSV5/U6Q5vM2tlwKwqcjYm+VaCYuVQENUpUKq0RfQGzI\nnHsBdEgSbPDfK6eFnCvABAJc1jWVyWRDkOw56aaLRy2R8Go41GyPZ+9X8hKe2t/K\nL07bJ/5FsbrOmZY5QgmohKywWJv1Y2oRpTAI0nkdXqXn9tB0jRZAuHl4UOoIRrRB\nNJ8pmhvPxgqo6xxMymdH21XKbLFppliwU/ghYvxnNN4/tuIZ6D6aJrZa/zvlEDtw\nXb7K2b3p0JFdVKiKv5OWxHeq5X8eU0ZvAuyzYv5bMTloM9ISGwLYwLptk13VHUUl\n1PBuoKqZAgMBAAECggEAFneCARL393OO4YAcQGNIAL2wDBkiWn7C4KR3yHtJbgCO\nPtUrwiM5A+2AlVb4ABiOxNh9GPrMUpcbSVRNho7cWR2Ls6cVi7m0RTbHOY3AF+2/\nogB9X4UgS9UgpYfGPScmFVn21w0SrF9hkCAduaz242jJuxg8cis7RAr36/aGTCEh\nR2njELwf6XYjQe+S/xDVQb3r8Si7i7aLn/TlIAFvVQa1odgx8GYYyBvoY/X6Gd3x\nreP3qeMh18v5Alub6ZSJHizw1wTDs9VafFQv9qqk5s6I1cCUIMArm6wpZxUF/n4y\n5Yro0mtGp8N2DpxqxgVVP9OXbYd/bBHEeMkO7zBUbQKBgQDrTzMXIbtK3YUg1xzz\nQ5m03K+d4Wwj8pVqQQTpQOeKZhU1ES9xrRe+dK7I+KryyAqYBHDkFpYUmkxI/hzE\n8s2MefAfcKWZa7jty4JeCsOWQDK8ToRC0w16S4ekN2LBOxFx3jLjm/P6IUm1dV/u\nUD+DNH6ek9I2kdeeI0jxoJY0LQKBgQDJmgfCx12GZXqxmPKDav9vlKFj5zmM04E5\nbJvlyfFsZzNWmAEi8uKFszs5wZyQAhO/tdBLDUeeRac53a494XEI8qV4Cxrbnk1H\n97ehUiVDYU3gpbQ786kpqGu94ZJI4sJ1R6BllIjtAvGlVzaYP0fRBTeCPr7oXsGi\nxYIKcaE3nQKBgQDkTemCDgZMMvWR0WSTWgluA5iYlDh6AEmb2A3Nyl1cWINHA6+G\nmayp60gSUcJ64D/3Eof9pTRkNPjC8Vo0dGeeXkjuGDtzyaKZhZStbcAqrYsMTRni\nRCeVembWm65DUO4yDqZNU+i5zUZYutMiw9V7lZksfru8mnAbTJzfYzGY2QKBgFXo\nXDxFJnZ50eHSMi2ML9NFe8yNoLmA+4UT4g72kflGtNrGpV1WMO8WZDuFZIj9SZsd\nB+ijfQxV1B/VdkWKRtewRpCz8rr5ZycuyUJmNdjToxMCqZ4Og9xrl5XvhJ2oe4Ls\nhc4jkIGnCoARfQM9nAXW+kN3J3TvxAXvsi1vJGsFAoGAJ+vpvRvGMs881PdAAxuS\n9lU2Z4z8NzkQ0o0BXOjH2NCsfu5fsXNsakm3SE6/K7OWPfDRaBwzkb6IeKNz7/Xs\njtG+OG39qRLC0++vn4qYKzpHTjuD+h/Q7jt2pnY2YfTiO+00X7Ev6V+yzD3k15bv\nKhbGSAIo4u+kvabS8zf/tes=\n-----END PRIVATE KEY-----\n",
  "client_email": "tsssavingsheets@omega-moonlight-468714-t6.iam.gserviceaccount.com",
  "client_id": "104225876534828898456",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/tsssavingsheets%40omega-moonlight-468714-t6.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};