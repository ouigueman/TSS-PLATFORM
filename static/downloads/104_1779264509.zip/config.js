const GOOGLE_SHEETS_CONFIG = {
  spreadsheetId: "1GHQMEQ73FYG_FAm6oghEVcYZpWHhnhzCNooKn5mvvf8",
  credentialsFile: "queues-monitor.json"
};


const GOOGLE_SHEETS_CREDENTIALS = {
  "type": "service_account",
  "project_id": "omega-moonlight-468714-t6",
  "private_key_id": "b5dcd7e8c5a37a3ae7f0554f13ac240d0d891f84",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC9Hg9v6zSAH4Yx\n/9kizPcEY7mV9oZvSljer0nDQTkrbnGujD1+T5ErG//B0JtkDPrxPMaKBD7BPknc\nj4iJiD6cKS7xu6iK3lriySV90qCVBvoBXCf8HxrYjp7qtH7DUG91GA8ulMJjoMsV\nwQOrtKxpP/PPv3CkPrqZsXpgNCUS7Jzk04IhhjE83+tgqaNcIN6mP6jZ5J3WP09w\nda+UlOocOXS47VHc9PmT+INjTPxkbi6eqmcLorF1SQQdYuO6DHWTQpJZfsI1yBnP\ngmRgoX0fIGWriKN3wvBqwP3wohraQInqG1fO9N+UpeXwIb69iPB7p8Rak4lR4WrO\nyqGliIh3AgMBAAECggEAAsTYZ3IFqHPQwVizp+mSGxGoJuP31WaYMr+eakQKX4Gu\nDwuLUniew8RFiZRtBK6K7G24EBIpCAMNMrQcJmbIA1L7Is91pfegFxVuhtVM9NY0\nMa8L267wDDwWV1T1onaXYmo/yeT5jB4GW/Jk33vW13IKSWraT52y1wI9AYau4JBv\nWUn6iluvwDHxDCct63hcEvQZW6qTsB1fw7/pQELItMDOtc256KHunQtcAyrGrqst\nDEB7B3CMY5gqxqkM90iRSARvogVBwvSJzkbXCknIrNs8XBLBkzTlCu+/zlQA85pm\nsKCOrnx8GGHlAW/xqK8/VpfVuKaI4umo1yOI3MrhMQKBgQDdZgL7+bW+Puf35JjP\nIsh2BovG6y5JSynxKy5PnLzFozzi7gBrT31ZiyILDylxI0Qs2ldHRvffpswB9eew\nhlRL1EEmwQrr2WQwSmnK/uaCwYdEMxDZjDqvn1VHplZG3LpI9jsnTp/8x2iBuTr8\n0iknKWSfiTXnVH7OqMWT752zkQKBgQDarIHqpxpDsyOfDSWJazFWVBp588+zoqpT\n5w+AMQE34ADCUBqA6R8FxXK7UXhd8KMPZ78bPch1zSVOcHnlV8jbwa9zFWkdpVdu\nK+KQu+Ven4HF8r4GCNSPH8hblEe9JqzXY/1XBAgmD/9vw15K/bMox8A3ow9OgQ92\nRfkPbWfnhwKBgB3JKKOfv7y9l9W48noDkvaWAN4dK9f+fcENbyiUzKzGPl3FaVcG\nlbWjS0wzmP64oOZr5YwYVybGuPGWlLoiCFs/ThiZpg9+6sS4bi06R+bVhI4/VIgA\nHrEb/YwrK7ZS4dkJD4JFSK7oYP363p2+5Hx5TClOe2sI6hqBiDtT5GKRAoGBALsr\nUtwlgY6W45N87jcsIAOzYyIlNQ+d2MqOCK+Bwngv7JZld/oFD7+h3G1G8478rKU/\n+Mx5Wn6yRA9aqItMUyj+JI2NsvZkEmzDdV7K5S3Tu4FSH6IMptuGqbjxN2JIm0KV\nXD/BvLPPl6TzBV+MvW/XYch9clmQkEp85Ax3aas7AoGAdVy0gYStt86OSVtC5VSE\nNcIuGG08JZsDCcGz9VVjJPT53Twt40Cd7Uu/fClmaWQnpGcjAi0WO9XWcKMzGZ18\nvud0L2AdipUHWoROIP7CuRl8Gh6YgmOFs48gh0vWoEUNScNcq2RlB7wPgrEQjIn6\nIU14dq6yVlUOUi5oPR24++8=\n-----END PRIVATE KEY-----\n",
  "client_email": "tsssavingsheets@omega-moonlight-468714-t6.iam.gserviceaccount.com",
  "client_id": "104225876534828898456",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/tsssavingsheets%40omega-moonlight-468714-t6.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};