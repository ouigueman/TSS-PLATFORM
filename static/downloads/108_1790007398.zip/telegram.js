const TELEGRAM_BOT_TOKEN = '8716536042:AAGZsFb-QF_5BQD5Bvfmc908_BXPxcasyCM';

// ── Format number with thousand separators ───────────────────
function tgFmt(n) {
    return Number(n).toLocaleString('en-US');
}

// _tgFetch: routes through background.js's fetchWithTimeout when this file
// is loaded in that shared global scope (background.js); content.js loads
// telegram.js too, so fall back to a plain fetch there rather than error.
function _tgFetch(url, opts, timeoutMs = 20000) {
    if (typeof fetchWithTimeout === 'function') return fetchWithTimeout(url, opts, timeoutMs);
    return fetch(url, opts);
}

// ── Send a pre-built text message to Telegram (shared by several senders) ─
async function sendTelegramText(text, chatId) {
    try {
        const response = await _tgFetch(
            `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
            {
                method  : 'POST',
                headers : { 'Content-Type': 'application/json' },
                body    : JSON.stringify({
                    chat_id    : chatId,
                    text       : text,
                    parse_mode : 'Markdown'
                })
            }
        );
        const data = await response.json();
        if (response.ok && data.ok) return { success: true };
        return { success: false, error: data.description || `HTTP ${response.status}` };
    } catch (err) {
        return { success: false, error: err.message };
    }
}

// ── Send a plain-text blob to Telegram as a .txt document ────
async function sendTelegramTextFile(plainText, fileName, caption, chatId) {
    const blob     = new Blob([plainText], { type: 'text/plain' });
    const formData = new FormData();
    formData.append('chat_id', chatId);
    formData.append('caption', caption);
    formData.append('document', blob, fileName);

    try {
        const response = await _tgFetch(
            `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument`,
            { method: 'POST', body: formData },
            45000 // file upload — give it more room than plain text messages
        );
        const data = await response.json();
        if (response.ok && data.ok) return { success: true };
        return { success: false, error: data.description || `HTTP ${response.status}` };
    } catch (err) {
        return { success: false, error: err.message };
    }
}

// ── Build alert message for send-modal failure ───────────────
function buildTelegramAlertMessage(drop, totalDrops, groupIndex, totalGroups, ips, attemptCount, randomServer = '') {
    const now     = new Date();
    const pad     = n => String(n).padStart(2, '0');
    const dateStr = `${pad(now.getDate())}-${pad(now.getMonth()+1)}-${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}`;
    const ipList  = ips.map(ip => `  - ${ip}`).join('\n');
    const divider = '='.repeat(40);

    const lines = [
        `[!!] SEND MODAL FAILURE ALERT`,
        divider,
        `Date     :  ${dateStr}`,
        ...(randomServer ? [`Server   :  ${randomServer}`] : []),
        divider,
        `Drop     :  ${drop} / ${totalDrops}`,
        `Group    :  ${groupIndex} / ${totalGroups}`,
        `Attempts :  ${attemptCount} clicks x 2 min = ~${Math.round(attemptCount * 2)} min`,
        ``,
        `IPs in failed group:`,
        ipList,
        divider,
        `The send button was clicked repeatedly (every 2 min).`,
        `The report modal never appeared after 1 hour.`,
        `The warmup process has been STOPPED.`,
    ];

    return '```\n' + lines.join('\n') + '\n```';
}

// ── Send a plain alert (error notification) to Telegram ──────
async function sendTelegramAlert(drop, totalDrops, groupIndex, totalGroups, ips, chatId, attemptCount, randomServer = '') {
    const message = buildTelegramAlertMessage(drop, totalDrops, groupIndex, totalGroups, ips, attemptCount, randomServer);
    return sendTelegramText(message, chatId);
}

// ── Format the per-IP inbox/spam breakdown (from count_emails' ip_breakdown) ─
// Returns an array of lines, or [] if there's nothing to show.
function buildEmailIpBreakdownLines(ipBreakdown, thin) {
    if (!ipBreakdown || ipBreakdown.length === 0) return [];

    const sorted = [...ipBreakdown].sort((a, b) => b.total_count - a.total_count);
    const ipColW = Math.max(...sorted.map(r => (r.ip || '').length), 15);
    const head   = `${'IP'.padEnd(ipColW)}  ${'INBOX'.padStart(8)}  ${'SPAM'.padStart(8)}  ${'TOTAL'.padStart(8)}`;

    const rows = sorted.map(r =>
        `${(r.ip || 'Unknown').padEnd(ipColW)}  ${tgFmt(r.inbox_count).padStart(8)}  ${tgFmt(r.spam_count).padStart(8)}  ${tgFmt(r.total_count).padStart(8)}`
    );

    return [
        ``,
        `EMAIL COUNT — PER IP`,
        thin,
        head,
        thin,
        ...rows,
    ];
}

// ── Build a standalone plain-text file with just the per-IP breakdown ──
// Used when adding it inline would push the Telegram message over the
// 4096-character limit.
function buildIpBreakdownPlainText(drop, totalDrops, gmailAccount, ipBreakdown) {
    const now     = new Date();
    const pad     = n => String(n).padStart(2, '0');
    const dateStr = `${pad(now.getDate())}-${pad(now.getMonth()+1)}-${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}`;
    const thin    = '-'.repeat(50);

    const lines = [
        `EMAIL COUNT — PER IP BREAKDOWN`,
        `Drop          :  ${drop} / ${totalDrops}`,
        `Date          :  ${dateStr}`,
        `Gmail Account :  ${gmailAccount || 'N/A'}`,
        ...buildEmailIpBreakdownLines(ipBreakdown, thin),
    ];

    return lines.join('\n');
}

// ── Send the per-IP inbox/spam breakdown as its own .txt attachment ──
async function sendIpBreakdownFile(drop, totalDrops, gmailAccount, ipBreakdown, chatId) {
    const plainText = buildIpBreakdownPlainText(drop, totalDrops, gmailAccount, ipBreakdown);

    const now      = new Date();
    const pad      = n => String(n).padStart(2, '0');
    const stamp    = `${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}`;
    const fileName = `email_ip_breakdown_drop${drop}_${stamp}.txt`;
    const caption  = `Drop ${drop}/${totalDrops} — Inbox/Spam per IP (attached, too long for a Telegram message)`;

    return sendTelegramTextFile(plainText, fileName, caption, chatId);
}

// ── Build the merged drop report (warmup + optional email count) ─
// emailCountData: null  → email count section omitted
//                { inboxCount, spamCount, totalCount, subject, fromEmail,
//                  resumeTime, countTime, gmailAccount, ipBreakdown }  → section included
// includeIpBreakdown: whether to render the per-IP inbox/spam table inline
//                     (set to false when it needs to be shipped as a
//                     separate .txt file instead — see sendMergedReport)
function buildMergedMessage(drop, totalDrops, ipResults, toleranceRate = 0, downServers = [], processType = 'passive', emailCountData = null, dropNote = '', listInfo = null, includeIpBreakdown = true) {
    const totalIn  = ipResults.reduce((s, r) => s + r.target,     0);
    const totalOut = ipResults.reduce((s, r) => s + r.reallySent, 0);
    const rate     = totalIn > 0 ? ((totalOut / totalIn) * 100).toFixed(1) : '0.0';

    const now     = new Date();
    const pad     = n => String(n).padStart(2, '0');
    const dateStr = `${pad(now.getDate())}-${pad(now.getMonth()+1)}-${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}`;

    // Collect unique servers (in order of first appearance)
    const serverOrder = [];
    const seenSrv = new Set();
    ipResults.forEach(r => {
        if (r.server && !seenSrv.has(r.server)) {
            seenSrv.add(r.server);
            serverOrder.push(r.server);
        }
    });
    const hasServers = serverOrder.length > 0;

    // Column widths — wide enough to fit all data cleanly
    const ipColW  = Math.max(...ipResults.map(r => r.ip.length), 15);
    const srvColW = hasServers ? Math.max(...serverOrder.map(s => s.length), 10) : 0;
    const totalW  = hasServers ? (ipColW + srvColW + 38) : (ipColW + 34);
    const divider = '='.repeat(totalW);
    const thin    = '-'.repeat(totalW);

    // ── Per-IP detail rows ─────────────────────────────────────
    const colHead = hasServers
        ? `${'ST'.padEnd(6)}  ${'SERVER'.padEnd(srvColW)}  ${'IP'.padEnd(ipColW)}  ${'IN'.padStart(9)}  ${'OUT'.padStart(9)}  ${'RATE'.padStart(6)}`
        : `${'ST'.padEnd(6)}  ${'IP'.padEnd(ipColW)}  ${'IN'.padStart(9)}  ${'OUT'.padStart(9)}  ${'RATE'.padStart(6)}`;

    const ipRows = ipResults.map(r => {
        if (r.serverDown) {
            const srvPart = hasServers ? `${(r.server || '').padEnd(srvColW)}  ` : '';
            return `[DOWN]  ${srvPart}${r.ip.padEnd(ipColW)}  ${'---'.padStart(9)}  ${'---'.padStart(9)}  ${'DOWN'.padStart(6)}`;
        }
        const pctIp     = r.target > 0 ? ((r.reallySent / r.target) * 100).toFixed(1) : '0.0';
        const threshold = 100 - toleranceRate;
        const tag       = parseFloat(pctIp) >= threshold ? '✅' : '⚠️';
        const srvPart   = hasServers ? `${(r.server || '').padEnd(srvColW)}  ` : '';
        return `${tag}  ${srvPart}${r.ip.padEnd(ipColW)}  ${tgFmt(r.target).padStart(9)}  ${tgFmt(r.reallySent).padStart(9)}  ${(pctIp + '%').padStart(6)}`;
    }).join('\n');

    // ── Per-server subtotals ───────────────────────────────────
    let serverSection = [];
    if (hasServers) {
        const srvHead = `${'ST'.padEnd(6)}  ${'SERVER'.padEnd(srvColW)}  ${'TOTAL IN'.padStart(9)}  ${'TOTAL OUT'.padStart(10)}  ${'RATE'.padStart(6)}`;
        serverSection = [``, `SERVER TOTALS`, thin, srvHead, thin];

        serverOrder.forEach(srv => {
            const srvIps    = ipResults.filter(r => r.server === srv);
            const isDown    = downServers.includes(srv) || srvIps.every(r => r.serverDown);
            const srvIn     = srvIps.reduce((s, r) => s + r.target,     0);
            const srvOut    = srvIps.reduce((s, r) => s + r.reallySent, 0);
            const srvRate   = srvIn > 0 ? ((srvOut / srvIn) * 100).toFixed(1) : '0.0';
            const threshold = 100 - toleranceRate;

            if (isDown) {
                serverSection.push(
                    `[DOWN]  ${srv.padEnd(srvColW)}  ${'---'.padStart(9)}  ${'---'.padStart(10)}  ${'DOWN'.padStart(6)}`
                );
            } else {
                const tag = parseFloat(srvRate) >= threshold ? '✅' : '⚠️';
                serverSection.push(
                    `${tag}  ${srv.padEnd(srvColW)}  ${tgFmt(srvIn).padStart(9)}  ${tgFmt(srvOut).padStart(10)}  ${(srvRate + '%').padStart(6)}`
                );
            }
        });
        serverSection.push(thin);
    }

    const processLabel = processType === 'passive' ? 'Passive Lists' : 'Warmup Lists';
    const fmtCount = n => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

    // ── Email count section (optional) ────────────────────────
    let emailSection = [];
    if (emailCountData) {
        const fmtDate = d => `${pad(d.getDate())}-${pad(d.getMonth()+1)}-${d.getFullYear()}  ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
        const {
            inboxCount, spamCount, totalCount,
            subject, fromEmail, resumeTime, countTime, gmailAccount
        } = emailCountData;

        const countStr    = fmtDate(new Date(countTime));
        const searchAfter = resumeTime ? fmtDate(new Date(resumeTime - 60 * 60 * 1000)) : 'N/A';
        const inboxRate   = totalCount > 0 ? Math.round((inboxCount / totalCount) * 100) : 0;

        emailSection = [
            ``,
            `EMAIL COUNT`,
            thin,
            `Counted At    :  ${countStr}`,
            `Gmail Account :  ${gmailAccount || 'N/A'}`,
            thin,
            `From          :  ${fromEmail || 'N/A'}`,
            `Subject       :  ${subject   || 'N/A'}`,
            `Received After:  ${searchAfter}`,
            thin,
            `Inbox         :  ${tgFmt(inboxCount)}`,
            `Spam          :  ${tgFmt(spamCount)}`,
            `Total         :  ${tgFmt(totalCount)}`,
            `Inbox Rate    :  ${inboxRate}%`,
            thin,
            `NOTE: The portal sends with GMT timing.`,
            `      Search starts from ${searchAfter}.`,
            thin,
            ...(includeIpBreakdown ? buildEmailIpBreakdownLines(emailCountData.ipBreakdown, thin) : []),
        ];
    }

    const lines = [
        `WARMUP REPORT`,
        divider,
        `Drop     :  ${drop} / ${totalDrops}`,
        `Date     :  ${dateStr}`,
        `Mode     :  ${processLabel}`,
        ...(listInfo && listInfo.name ? [`List     :  ${listInfo.name}${listInfo.count != null ? ' (' + fmtCount(listInfo.count) + ' unique)' : ''}`] : []),
        ...(dropNote ? [`Note     :  ${dropNote}`] : []),
        divider,
        ``,
        `SUMMARY`,
        thin,
        `Total IPs    :  ${ipResults.length}`,
        `Total IN     :  ${tgFmt(totalIn)}`,
        `Total OUT    :  ${tgFmt(totalOut)}`,
        `Delivery     :  ${rate}%`,
        `Tolerance    :  ${toleranceRate}%`,
        ...(downServers.length > 0 ? [`Down Servers :  ${downServers.join(', ')}`] : []),
        thin,
        ...serverSection,
        ``,
        `DETAIL PER IP`,
        thin,
        colHead,
        thin,
        ipRows,
        thin,
        ...emailSection,
    ];

    return '```\n' + lines.join('\n') + '\n```';
}

// ── Build plain-text version of the merged report (for .txt file fallback) ──
function buildMergedPlainText(drop, totalDrops, ipResults, toleranceRate = 0, downServers = [], processType = 'passive', emailCountData = null, dropNote = '', listInfo = null, includeIpBreakdown = true) {
    // Same as buildMergedMessage but without the backtick fences
    const full = buildMergedMessage(drop, totalDrops, ipResults, toleranceRate, downServers, processType, emailCountData, dropNote, listInfo, includeIpBreakdown);
    return full.replace(/^```\n/, '').replace(/\n```$/, '');
}

// ── Send merged report as a .txt document to Telegram ────────
async function sendMergedReportAsFile(drop, totalDrops, ipResults, chatId, toleranceRate = 0, downServers = [], processType = 'passive', emailCountData = null, dropNote = '', listInfo = null) {
    // Files have no length limit, so always include the full per-IP
    // inbox/spam breakdown here.
    const plainText = buildMergedPlainText(drop, totalDrops, ipResults, toleranceRate, downServers, processType, emailCountData, dropNote, listInfo, true);

    const now      = new Date();
    const pad      = n => String(n).padStart(2, '0');
    const stamp    = `${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}`;
    const fileName = `warmup_report_drop${drop}_${stamp}.txt`;
    const caption  = `Warmup Report - Drop ${drop}/${totalDrops} (attached as file)`;

    return sendTelegramTextFile(plainText, fileName, caption, chatId);
}

// ── Send the merged report (inline if fits, file fallback otherwise) ─
// emailCountData: null = no email count section; object = include it.
//
// Three possible outcomes:
//   1. Everything (warmup detail + per-server totals + per-IP email
//      inbox/spam breakdown) fits in one Telegram message → send as text.
//   2. The per-IP email inbox/spam breakdown alone is what pushes the
//      message over Telegram's 4096-char limit, but the rest fits fine →
//      send the report as text without that section, and ship the
//      per-IP breakdown separately as its own .txt attachment.
//   3. Even without the per-IP breakdown, the report itself is too big
//      (e.g. a huge warmup detail table) → fall back to sending the
//      whole report as a single .txt file, as before.
async function sendMergedReport(drop, totalDrops, ipResults, chatId, toleranceRate = 0, downServers = [], processType = 'passive', emailCountData = null, dropNote = '', listInfo = null) {
    const messageWithBreakdown = buildMergedMessage(
        drop, totalDrops, ipResults, toleranceRate, downServers, processType, emailCountData, dropNote, listInfo, true
    );

    // Case 1 — everything fits together.
    if (messageWithBreakdown.length <= 4090) {
        return sendTelegramText(messageWithBreakdown, chatId);
    }

    const hasIpBreakdown = emailCountData && emailCountData.ipBreakdown && emailCountData.ipBreakdown.length > 0;

    if (hasIpBreakdown) {
        const messageWithoutBreakdown = buildMergedMessage(
            drop, totalDrops, ipResults, toleranceRate, downServers, processType, emailCountData, dropNote, listInfo, false
        );

        // Case 2 — the per-IP breakdown was the culprit; send the rest as
        // text and the breakdown as its own file.
        if (messageWithoutBreakdown.length <= 4090) {
            const textResult = await sendTelegramText(messageWithoutBreakdown, chatId);
            if (!textResult.success) return textResult;

            return sendIpBreakdownFile(drop, totalDrops, emailCountData.gmailAccount, emailCountData.ipBreakdown, chatId);
        }
    }

    // Case 3 — still too big even without the per-IP breakdown (or there
    // was no breakdown to drop in the first place) → whole report as file.
    return sendMergedReportAsFile(drop, totalDrops, ipResults, chatId, toleranceRate, downServers, processType, emailCountData, dropNote, listInfo);
}

// ── Legacy aliases kept so nothing in content.js breaks ──────
// sendTelegramReport is still called nowhere after the refactor,
// but kept in case old code paths reference it.
async function sendTelegramReport(drop, totalDrops, ipResults, chatId, toleranceRate = 0, downServers = [], processType = 'passive') {
    return sendMergedReport(drop, totalDrops, ipResults, chatId, toleranceRate, downServers, processType, null);
}