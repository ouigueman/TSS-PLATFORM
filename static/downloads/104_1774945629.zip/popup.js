// ── Firefox MV2 compatibility shim ──────────────────────────
var browser = (typeof browser !== "undefined") ? browser : chrome;

const statusEl  = document.getElementById("status");
const reportEl  = document.getElementById("final-report");
const startBtn  = document.getElementById("start-deploy-process");
const sheetsDot = document.getElementById("sheets-dot");
const sheetsMsg = document.getElementById("sheets-status-text");
const tgDot     = document.getElementById("tg-dot");
const tgMsg     = document.getElementById("tg-status-text");
const chatIdEl   = document.getElementById("telegram-chat-id");
const sheetsIdEl = document.getElementById("sheets-spreadsheet-id");

// ── Process type selector ────────────────────────────────────
const ptPassiveRad    = document.getElementById("pt-passive");
const ptDatalistsRad  = document.getElementById("pt-datalists");

ptPassiveRad.addEventListener("change",   () => saveAllSettings());
ptDatalistsRad.addEventListener("change", () => saveAllSettings());

// ── Drop offset UI ───────────────────────────────────────────
const useOffsetChk    = document.getElementById("use-drop-offset");
const dropOffsetRow   = document.getElementById("drop-offset-row");
const dropStartInput  = document.getElementById("drop-start-number");
const dropOffsetPrev  = document.getElementById("drop-offset-preview");
const totalDropsInput = document.getElementById("total-drops");

function updateOffsetPreview() {
    const start = parseInt(dropStartInput.value) || 2;
    const total = parseInt(totalDropsInput.value) || 10;
    const displayTotal = start + total - 1;
    dropOffsetPrev.textContent = `${start}/${displayTotal} → ${displayTotal}/${displayTotal}`;
}

useOffsetChk.addEventListener("change", () => {
    if (useOffsetChk.checked) {
        dropOffsetRow.classList.add("visible");
        updateOffsetPreview();
    } else {
        dropOffsetRow.classList.remove("visible");
    }
    saveAllSettings();
});

dropStartInput.addEventListener("input", () => {
    if (useOffsetChk.checked) updateOffsetPreview();
    saveAllSettings();
});

totalDropsInput.addEventListener("input", () => {
    if (useOffsetChk.checked) updateOffsetPreview();
    saveAllSettings();
});

// ── Start-After toggle ───────────────────────────────────────
const startAfterInputs  = document.getElementById("start-after-inputs");
const startImmediateRad = document.getElementById("start-immediate");
const startCustomRad    = document.getElementById("start-custom");

function applyStartMode(mode) {
    if (mode === "custom") {
        startAfterInputs.style.opacity = "1";
        startAfterInputs.style.pointerEvents = "auto";
    } else {
        startAfterInputs.style.opacity = "0.3";
        startAfterInputs.style.pointerEvents = "none";
    }
}

startImmediateRad.addEventListener("change", () => { applyStartMode("immediate"); saveAllSettings(); });
startCustomRad.addEventListener("change",    () => { applyStartMode("custom");    saveAllSettings(); });

// ── Persist ALL settings across popup opens ──────────────────
const PERSIST_KEYS = [
    'customIps',
    'totalDrops', 'successThreshold', 'sentIncrement', 'toleranceRate',
    'dropOffsetEnabled', 'dropStartNumber',
    't0h','t0m','t0s',
    't1h','t1m','t1s',
    't2h','t2m','t2s',
    't3h','t3m','t3s',
    't4h','t4m','t4s',
    'startMode',
    'tgChatId',
    'sheetsSpreadsheetId',
    'processType'
];

function saveAllSettings() {
    const startMode   = startCustomRad.checked ? "custom" : "immediate";
    const processType = ptDatalistsRad.checked ? "datalists" : "passive";
    browser.storage.local.set({
        customIps:          document.getElementById("custom-ip-input").value,
        totalDrops:         document.getElementById("total-drops").value,
        successThreshold:   document.getElementById("success-threshold").value,
        sentIncrement:      document.getElementById("sent-increment").value,
        toleranceRate:      document.getElementById("tolerance-rate").value,
        dropOffsetEnabled:  useOffsetChk.checked,
        dropStartNumber:    dropStartInput.value,
        t0h: document.getElementById("t0-h").value,
        t0m: document.getElementById("t0-m").value,
        t0s: document.getElementById("t0-s").value,
        t1h: document.getElementById("t1-h").value,
        t1m: document.getElementById("t1-m").value,
        t1s: document.getElementById("t1-s").value,
        t2h: document.getElementById("t2-h").value,
        t2m: document.getElementById("t2-m").value,
        t2s: document.getElementById("t2-s").value,
        t3h: document.getElementById("t3-h").value,
        t3m: document.getElementById("t3-m").value,
        t3s: document.getElementById("t3-s").value,
        t4h: document.getElementById("t4-h").value,
        t4m: document.getElementById("t4-m").value,
        t4s: document.getElementById("t4-s").value,
        startMode,
        tgChatId: chatIdEl.value.trim(),
        sheetsSpreadsheetId: sheetsIdEl.value.trim(),
        processType
    });
}

// Attach saveAllSettings to all relevant inputs
["custom-ip-input","total-drops","success-threshold","sent-increment","tolerance-rate",
 "t0-h","t0-m","t0-s","t1-h","t1-m","t1-s","t2-h","t2-m","t2-s","t3-h","t3-m","t3-s",
 "t4-h","t4-m","t4-s"
].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("input", saveAllSettings);
});

chatIdEl.addEventListener('input', () => {
    chatIdEl.classList.remove('input-error');
    saveAllSettings();
});

sheetsIdEl.addEventListener('input', () => {
    sheetsIdEl.classList.remove('input-error');
    saveAllSettings();
});

// ── Restore saved settings on popup open ────────────────────
browser.storage.local.get(PERSIST_KEYS, data => {
    if (data.customIps        != null) document.getElementById("custom-ip-input").value    = data.customIps;
    if (data.totalDrops       != null) document.getElementById("total-drops").value        = data.totalDrops;
    if (data.successThreshold != null) document.getElementById("success-threshold").value  = data.successThreshold;
    if (data.sentIncrement    != null) document.getElementById("sent-increment").value      = data.sentIncrement;
    if (data.toleranceRate    != null) document.getElementById("tolerance-rate").value      = data.toleranceRate;
    if (data.tgChatId)             chatIdEl.value   = data.tgChatId;
    if (data.sheetsSpreadsheetId)  sheetsIdEl.value = data.sheetsSpreadsheetId;

    if (data.dropStartNumber)  dropStartInput.value = data.dropStartNumber;
    if (data.dropOffsetEnabled) {
        useOffsetChk.checked = true;
        dropOffsetRow.classList.add("visible");
        updateOffsetPreview();
    }

    // Time fields
    const timeFields = [
        ['t0h','t0-h'],['t0m','t0-m'],['t0s','t0-s'],
        ['t1h','t1-h'],['t1m','t1-m'],['t1s','t1-s'],
        ['t2h','t2-h'],['t2m','t2-m'],['t2s','t2-s'],
        ['t3h','t3-h'],['t3m','t3-m'],['t3s','t3-s'],
        ['t4h','t4-h'],['t4m','t4-m'],['t4s','t4-s'],
    ];
    timeFields.forEach(([key, id]) => {
        if (data[key] != null) document.getElementById(id).value = data[key];
    });

    // Start mode
    const mode = data.startMode || "immediate";
    if (mode === "custom") {
        startCustomRad.checked = true;
        startImmediateRad.checked = false;
    } else {
        startImmediateRad.checked = true;
        startCustomRad.checked = false;
    }
    applyStartMode(mode);

    // Process type
    const ptype = data.processType || "passive";
    if (ptype === "datalists") {
        ptDatalistsRad.checked = true;
        ptPassiveRad.checked   = false;
    } else {
        ptPassiveRad.checked   = true;
        ptDatalistsRad.checked = false;
    }
});

function setStatus(msg) { statusEl.textContent = msg; }

function setSheetsStatus(state, msg) {
    sheetsDot.className = 'sheets-dot ' + (state === 'idle' ? '' : state);
    sheetsMsg.textContent = msg;
}

function setTgStatus(state, msg) {
    tgDot.className = 'sheets-dot ' + (state === 'idle' ? '' : state);
    tgMsg.textContent = msg;
}

function toSeconds(h, m, s) {
    return (parseInt(h) || 0) * 3600 + (parseInt(m) || 0) * 60 + (parseInt(s) || 0);
}

// ── MV2 script injection helper ──────────────────────────────
function injectFile(tabId, file) {
    return new Promise((resolve) => {
        browser.tabs.executeScript(tabId, { file }, () => {
            if (browser.runtime.lastError) {
                console.warn(`[popup] inject ${file}:`, browser.runtime.lastError.message);
            }
            resolve();
        });
    });
}

startBtn.addEventListener("click", async () => {
    const ips              = document.getElementById("custom-ip-input").value.trim();
    const totalDrops       = parseInt(document.getElementById("total-drops").value);
    const successThreshold = parseInt(document.getElementById("success-threshold").value);
    const sentIncrement    = parseInt(document.getElementById("sent-increment").value);
    const toleranceRate    = parseFloat(document.getElementById("tolerance-rate").value) || 0;
    const telegramChatId   = chatIdEl.value.trim();
    const sheetsSpreadsheetId = sheetsIdEl.value.trim();
    const processType      = ptDatalistsRad.checked ? "datalists" : "passive";

    // Drop offset
    const useOffset = useOffsetChk.checked;
    const dropStart = useOffset ? (parseInt(dropStartInput.value) || 2) : 1;

    // Start-after delay
    const startMode = startCustomRad.checked ? "custom" : "immediate";
    const startAfterDelay = startMode === "custom"
        ? toSeconds(
            document.getElementById("t0-h").value,
            document.getElementById("t0-m").value,
            document.getElementById("t0-s").value
          )
        : 0;

    const timeBeforeResume = toSeconds(
        document.getElementById("t1-h").value,
        document.getElementById("t1-m").value,
        document.getElementById("t1-s").value
    );
    const timeAfterResume = toSeconds(
        document.getElementById("t2-h").value,
        document.getElementById("t2-m").value,
        document.getElementById("t2-s").value
    );
    const timeBetweenDrops = toSeconds(
        document.getElementById("t3-h").value,
        document.getElementById("t3-m").value,
        document.getElementById("t3-s").value
    );
    const timeAfterPauseVerified = toSeconds(
        document.getElementById("t4-h").value,
        document.getElementById("t4-m").value,
        document.getElementById("t4-s").value
    );

    // Validations
    if (!ips)                                             { setStatus("Please enter IPs.");          return; }
    if (isNaN(totalDrops)       || totalDrops < 1)       { setStatus("Invalid total drops.");        return; }
    if (isNaN(successThreshold) || successThreshold < 1) { setStatus("Invalid success threshold.");  return; }
    if (isNaN(sentIncrement)    || sentIncrement < 1)    { setStatus("Invalid increment.");           return; }
    if (isNaN(toleranceRate) || toleranceRate < 0 || toleranceRate > 100) { setStatus("Invalid tolerance rate (0-100)."); return; }
    if (!telegramChatId) {
        chatIdEl.classList.add('input-error');
        chatIdEl.focus();
        setStatus("Telegram Chat ID is required.");
        return;
    }
    if (!sheetsSpreadsheetId) {
        sheetsIdEl.classList.add('input-error');
        sheetsIdEl.focus();
        setStatus("Google Sheets Spreadsheet ID is required.");
        return;
    }
    if (useOffset && (isNaN(dropStart) || dropStart < 2)) {
        dropStartInput.style.borderColor = 'rgba(239,68,68,0.6)';
        dropStartInput.focus();
        setStatus("Start drop must be 2 or greater.");
        return;
    }
    if (startMode === "custom" && startAfterDelay === 0) {
        setStatus("Custom start delay is 0 — set a time or switch to Immediate.");
        return;
    }

    setStatus("Parsing...");
    reportEl.style.display = "none";
    setSheetsStatus('idle', 'Waiting for first drop…');
    setTgStatus('idle', 'Report will be sent after each drop');

    browser.runtime.sendMessage(
        { type: "PROCESS_DEPLOY_DATA", payload: { ips } },
        async (response) => {
            if (!response || !response.success) { setStatus("Parsing failed."); return; }

            setStatus("Starting process on active tab...");

            browser.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
                const tab = tabs && tabs[0];
                if (!tab) { setStatus("No active tab found."); return; }

                startBtn.disabled = true;

                const config = {
                    totalDrops, successThreshold, sentIncrement,
                    timeBeforeResume, timeAfterResume, timeBetweenDrops,
                    timeAfterPauseVerified,
                    telegramChatId, toleranceRate,
                    sheetsSpreadsheetId,
                    dropStart,
                    startAfterDelay,
                    processType
                };

                // ── Ping the content script; inject if not yet present ──
                const sendMessage = (tabId, msg) => new Promise(resolve => {
                    browser.tabs.sendMessage(tabId, msg, res => {
                        if (browser.runtime.lastError) resolve(null);
                        else resolve(res);
                    });
                });

                let res = await sendMessage(tab.id, { type: "PING" });
                if (!res) {
                    for (const file of ["config.js", "googleSheets.js", "telegram.js", "content.js"]) {
                        await injectFile(tab.id, file);
                    }
                    await new Promise(resolve => setTimeout(resolve, 800));
                }

                // ── Listen for messages from content script ──
                browser.runtime.onMessage.addListener(function listener(msg) {
                    if (msg.type === "STATUS_UPDATE") {
                        setStatus(msg.text);
                    }

                    if (msg.type === "SHEETS_SAVING") {
                        setSheetsStatus('busy', `Saving Drop ${msg.drop} to Google Sheets…`);
                    }
                    if (msg.type === "SHEETS_SAVED") {
                        setSheetsStatus(
                            msg.success ? 'ok' : 'error',
                            msg.success
                                ? `Drop ${msg.drop} saved to ${msg.sheetName}`
                                : `Drop ${msg.drop} save failed: ${msg.error}`
                        );
                    }

                    if (msg.type === "TG_SENDING") {
                        setTgStatus('busy', `Sending Drop ${msg.drop} report to Telegram…`);
                    }
                    if (msg.type === "TG_SENT") {
                        setTgStatus(
                            msg.success ? 'ok' : 'error',
                            msg.success
                                ? `Drop ${msg.drop} report sent successfully`
                                : `Drop ${msg.drop} failed: ${msg.error}`
                        );
                    }

                    if (msg.type === "FINAL_REPORT") {
                        browser.runtime.onMessage.removeListener(listener);
                        startBtn.disabled = false;
                        reportEl.style.display = "block";
                        reportEl.textContent = msg.report;
                        setStatus("All drops completed!");
                    }
                });

                browser.tabs.sendMessage(tab.id, {
                    type: "START_DEPLOY_PROCESS",
                    groups: response.groups,
                    orderedIps: response.orderedIps,
                    ipServerMap: response.ipServerMap || {},
                    config,
                    deployTabId: tab.id
                }, (startResp) => {
                    if (browser.runtime.lastError) return;
                    if (startResp && startResp.preflightErrors && startResp.preflightErrors.length > 0) {
                        // Pre-flight failed — re-enable button and show errors in popup
                        startBtn.disabled = false;
                        const errList = startResp.preflightErrors.map(e => `• ${e}`).join('\n');
                        setStatus('🚫 Pre-flight check failed:\n' + errList);
                    }
                });
            });
        }
    );
});
