const TELEGRAM_BOT_TOKEN = '8716536042:AAGZsFb-QF_5BQD5Bvfmc908_BXPxcasyCM';

// ── Format number with thousand separators ───────────────────
function tgFmt(n) {
    return Number(n).toLocaleString('en-US');
}

// ── Build the drop report message ───────────────────────────
// ipResults: array of { ip, server, serverDown, target, reallySent }
// downServers: array of server names detected as down this drop
function buildTelegramMessage(drop, totalDrops, ipResults, toleranceRate = 0, downServers = [], processType = 'passive') {
    const totalIn  = ipResults.reduce((s, r) => s + r.target,     0);
    const totalOut = ipResults.reduce((s, r) => s + r.reallySent, 0);
    const rate     = totalIn > 0 ? ((totalOut / totalIn) * 100).toFixed(1) : '0.0';

    const now     = new Date();
    const pad     = n => String(n).padStart(2, '0');
    const dateStr = `${pad(now.getDate())}-${pad(now.getMonth()+1)}-${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}`;

    // Collect unique servers (in order of first appearance)
    const serverOrder = [];
    const seenSrv = new Set();
    ipResults.forEach(r => {
        if (r.server && !seenSrv.has(r.server)) {
            seenSrv.add(r.server);
            serverOrder.push(r.server);
        }
    });
    const hasServers = serverOrder.length > 0;

    // Column widths
    const ipColW  = Math.max(...ipResults.map(r => r.ip.length), 15);
    const srvColW = hasServers ? Math.max(...serverOrder.map(s => s.length), 10) : 0;
    const totalW  = hasServers ? (ipColW + srvColW + 36) : (ipColW + 32);
    const divider = '='.repeat(totalW);
    const thin    = '-'.repeat(totalW);

    // Per-IP detail rows
    const colHead = hasServers
        ? `${'ST'.padStart(2)}  ${'SERVER'.padEnd(srvColW)}  ${'IP'.padEnd(ipColW)}  ${'IN'.padStart(9)}  ${'OUT'.padStart(9)}  ${'RATE'.padStart(6)}`
        : `${'ST'.padStart(2)}  ${'IP'.padEnd(ipColW)}  ${'IN'.padStart(9)}  ${'OUT'.padStart(9)}  ${'RATE'.padStart(6)}`;

    const ipRows = ipResults.map(r => {
        if (r.serverDown) {
            const srvPart = hasServers ? `${(r.server || '').padEnd(srvColW)}  ` : '';
            return `⛔️  ${srvPart}${r.ip.padEnd(ipColW)}  ${'---'.padStart(9)}  ${'---'.padStart(9)}  ${'DOWN'.padStart(6)}`;
        }
        const pctIp     = r.target > 0 ? ((r.reallySent / r.target) * 100).toFixed(1) : '0.0';
        const threshold = 100 - toleranceRate;
        const icon      = parseFloat(pctIp) >= threshold ? '✅' : '⚠️';
        const srvPart   = hasServers ? `${(r.server || '').padEnd(srvColW)}  ` : '';
        return `${icon}  ${srvPart}${r.ip.padEnd(ipColW)}  ${tgFmt(r.target).padStart(9)}  ${tgFmt(r.reallySent).padStart(9)}  ${(pctIp + '%').padStart(6)}`;
    }).join('\n');

    // Per-server subtotal section
    let serverSection = [];
    if (hasServers) {
        serverSection = [
            ``,
            `SERVER TOTALS`,
            thin,
            `${'ST'.padStart(2)}  ${'SERVER'.padEnd(srvColW)}  ${'TOTAL IN'.padStart(9)}  ${'TOTAL OUT'.padStart(10)}  ${'RATE'.padStart(6)}`,
            thin,
        ];

        serverOrder.forEach(srv => {
            const srvIps    = ipResults.filter(r => r.server === srv);
            const isDown    = downServers.includes(srv) || srvIps.every(r => r.serverDown);
            const srvIn     = srvIps.reduce((s, r) => s + r.target,     0);
            const srvOut    = srvIps.reduce((s, r) => s + r.reallySent, 0);
            const srvRate   = srvIn > 0 ? ((srvOut / srvIn) * 100).toFixed(1) : '0.0';
            const threshold = 100 - toleranceRate;

            if (isDown) {
                serverSection.push(
                    `⛔️  ${srv.padEnd(srvColW)}  ${'---'.padStart(9)}  ${'---'.padStart(10)}  ${'DOWN'.padStart(6)}`
                );
            } else {
                const icon = parseFloat(srvRate) >= threshold ? '✅' : '⚠️';
                serverSection.push(
                    `${icon}  ${srv.padEnd(srvColW)}  ${tgFmt(srvIn).padStart(9)}  ${tgFmt(srvOut).padStart(10)}  ${(srvRate + '%').padStart(6)}`
                );
            }
        });
        serverSection.push(thin);
    }

    const processLabel = processType === 'datalists' ? 'Data Lists' : 'Lists Passive';

    const lines = [
        `WARMUP REPORT`,
        divider,
        `Drop     :  ${drop} / ${totalDrops}`,
        `Date     :  ${dateStr}`,
        `Mode     :  ${processLabel}`,
        divider,
        ``,
        `SUMMARY`,
        thin,
        `Total IPs    :  ${ipResults.length}`,
        `Total IN     :  ${tgFmt(totalIn)}`,
        `Total OUT    :  ${tgFmt(totalOut)}`,
        `Delivery     :  ${rate}%`,
        `Tolerance    :  ${toleranceRate}%`,
        ...(downServers.length > 0 ? [`Down Servers :  ${downServers.join(', ')}`] : []),
        thin,
        ...serverSection,
        ``,
        `DETAIL PER IP`,
        thin,
        colHead,
        thin,
        ipRows,
        thin,
    ];

    return '```\n' + lines.join('\n') + '\n```';
}

// ── Build alert message for send-modal failure ───────────────
function buildTelegramAlertMessage(drop, totalDrops, groupIndex, totalGroups, ips, attemptCount, randomServer = '') {
    const now     = new Date();
    const pad     = n => String(n).padStart(2, '0');
    const dateStr = `${pad(now.getDate())}-${pad(now.getMonth()+1)}-${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}`;
    const ipList  = ips.map(ip => `  • ${ip}`).join('\n');
    const divider = '='.repeat(40);

    const lines = [
        `🚨 SEND MODAL FAILURE ALERT`,
        divider,
        `Date     :  ${dateStr}`,
        ...(randomServer ? [`Server   :  ${randomServer}`] : []),
        divider,
        `Drop     :  ${drop} / ${totalDrops}`,
        `Group    :  ${groupIndex} / ${totalGroups}`,
        `Attempts :  ${attemptCount} clicks × 2 min = ~${Math.round(attemptCount * 2)} min`,
        ``,
        `IPs in failed group:`,
        ipList,
        divider,
        `The send button was clicked repeatedly (every 2 min).`,
        `The report modal never appeared after 1 hour.`,
        `The warmup process has been STOPPED.`,
    ];

    return '```\n' + lines.join('\n') + '\n```';
}

// ── Send a plain alert (error notification) to Telegram ──────
async function sendTelegramAlert(drop, totalDrops, groupIndex, totalGroups, ips, chatId, attemptCount, randomServer = '') {
    const message = buildTelegramAlertMessage(drop, totalDrops, groupIndex, totalGroups, ips, attemptCount, randomServer);

    try {
        const response = await fetch(
            `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
            {
                method  : 'POST',
                headers : { 'Content-Type': 'application/json' },
                body    : JSON.stringify({
                    chat_id    : chatId,
                    text       : message,
                    parse_mode : 'Markdown'
                })
            }
        );
        const data = await response.json();
        if (response.ok && data.ok) return { success: true };
        return { success: false, error: data.description || `HTTP ${response.status}` };
    } catch (err) {
        return { success: false, error: err.message };
    }
}

// ── Build plain-text content for .txt file (no markdown fences) ──
function buildPlainTextReport(drop, totalDrops, ipResults, toleranceRate = 0, downServers = [], processType = 'passive') {
    const totalIn  = ipResults.reduce((s, r) => s + r.target,     0);
    const totalOut = ipResults.reduce((s, r) => s + r.reallySent, 0);
    const rate     = totalIn > 0 ? ((totalOut / totalIn) * 100).toFixed(1) : '0.0';

    const now     = new Date();
    const pad     = n => String(n).padStart(2, '0');
    const dateStr = `${pad(now.getDate())}-${pad(now.getMonth()+1)}-${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}`;

    // Collect unique servers
    const serverOrder = [];
    const seenSrv = new Set();
    ipResults.forEach(r => {
        if (r.server && !seenSrv.has(r.server)) {
            seenSrv.add(r.server);
            serverOrder.push(r.server);
        }
    });
    const hasServers = serverOrder.length > 0;

    // Column widths
    const ipColW  = Math.max(...ipResults.map(r => r.ip.length), 15);
    const srvColW = hasServers ? Math.max(...serverOrder.map(s => s.length), 10) : 0;
    const totalW  = hasServers ? (ipColW + srvColW + 36) : (ipColW + 32);
    const divider = '='.repeat(totalW);
    const thin    = '-'.repeat(totalW);

    const colHead = hasServers
        ? `${'ST'.padStart(2)}  ${'SERVER'.padEnd(srvColW)}  ${'IP'.padEnd(ipColW)}  ${'IN'.padStart(9)}  ${'OUT'.padStart(9)}  ${'RATE'.padStart(6)}`
        : `${'ST'.padStart(2)}  ${'IP'.padEnd(ipColW)}  ${'IN'.padStart(9)}  ${'OUT'.padStart(9)}  ${'RATE'.padStart(6)}`;

    const ipRows = ipResults.map(r => {
        if (r.serverDown) {
            const srvPart = hasServers ? `${(r.server || '').padEnd(srvColW)}  ` : '';
            return `[DOWN]  ${srvPart}${r.ip.padEnd(ipColW)}  ${'---'.padStart(9)}  ${'---'.padStart(9)}  ${'DOWN'.padStart(6)}`;
        }
        const pctIp     = r.target > 0 ? ((r.reallySent / r.target) * 100).toFixed(1) : '0.0';
        const threshold = 100 - toleranceRate;
        const icon      = parseFloat(pctIp) >= threshold ? '[ OK ]' : '[ !! ]';
        const srvPart   = hasServers ? `${(r.server || '').padEnd(srvColW)}  ` : '';
        return `${icon}  ${srvPart}${r.ip.padEnd(ipColW)}  ${tgFmt(r.target).padStart(9)}  ${tgFmt(r.reallySent).padStart(9)}  ${(pctIp + '%').padStart(6)}`;
    }).join('\n');

    // Per-server subtotal section
    let serverSection = [];
    if (hasServers) {
        serverSection = [
            ``,
            `SERVER TOTALS`,
            thin,
            `${'ST'.padStart(6)}  ${'SERVER'.padEnd(srvColW)}  ${'TOTAL IN'.padStart(9)}  ${'TOTAL OUT'.padStart(10)}  ${'RATE'.padStart(6)}`,
            thin,
        ];

        serverOrder.forEach(srv => {
            const srvIps    = ipResults.filter(r => r.server === srv);
            const isDown    = downServers.includes(srv) || srvIps.every(r => r.serverDown);
            const srvIn     = srvIps.reduce((s, r) => s + r.target,     0);
            const srvOut    = srvIps.reduce((s, r) => s + r.reallySent, 0);
            const srvRate   = srvIn > 0 ? ((srvOut / srvIn) * 100).toFixed(1) : '0.0';
            const threshold = 100 - toleranceRate;

            if (isDown) {
                serverSection.push(
                    `[DOWN]  ${srv.padEnd(srvColW)}  ${'---'.padStart(9)}  ${'---'.padStart(10)}  ${'DOWN'.padStart(6)}`
                );
            } else {
                const icon = parseFloat(srvRate) >= threshold ? '[ OK ]' : '[ !! ]';
                serverSection.push(
                    `${icon}  ${srv.padEnd(srvColW)}  ${tgFmt(srvIn).padStart(9)}  ${tgFmt(srvOut).padStart(10)}  ${(srvRate + '%').padStart(6)}`
                );
            }
        });
        serverSection.push(thin);
    }

    const processLabel = processType === 'datalists' ? 'Data Lists' : 'Lists Passive';

    const lines = [
        `WARMUP REPORT`,
        divider,
        `Drop     :  ${drop} / ${totalDrops}`,
        `Date     :  ${dateStr}`,
        `Mode     :  ${processLabel}`,
        divider,
        ``,
        `SUMMARY`,
        thin,
        `Total IPs    :  ${ipResults.length}`,
        `Total IN     :  ${tgFmt(totalIn)}`,
        `Total OUT    :  ${tgFmt(totalOut)}`,
        `Delivery     :  ${rate}%`,
        `Tolerance    :  ${toleranceRate}%`,
        ...(downServers.length > 0 ? [`Down Servers :  ${downServers.join(', ')}`] : []),
        thin,
        ...serverSection,
        ``,
        `DETAIL PER IP`,
        thin,
        colHead,
        thin,
        ipRows,
        thin,
    ];

    return lines.join('\n');
}

// ── Send report as a .txt document to Telegram ───────────────
async function sendTelegramReportAsFile(drop, totalDrops, ipResults, chatId, toleranceRate = 0, downServers = [], processType = 'passive') {
    const plainText = buildPlainTextReport(drop, totalDrops, ipResults, toleranceRate, downServers, processType);

    const now     = new Date();
    const pad     = n => String(n).padStart(2, '0');
    const stamp   = `${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}`;
    const fileName = `warmup_report_drop${drop}_${stamp}.txt`;

    // Build multipart/form-data manually using Blob + FormData
    const blob     = new Blob([plainText], { type: 'text/plain' });
    const formData = new FormData();
    formData.append('chat_id', chatId);
    formData.append('caption', `📎 Warmup Report — Drop ${drop}/${totalDrops}\n(report attached as file — too large for inline message)`);
    formData.append('document', blob, fileName);

    try {
        const response = await fetch(
            `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument`,
            {
                method : 'POST',
                body   : formData
            }
        );

        const data = await response.json();

        if (response.ok && data.ok) {
            return { success: true };
        } else {
            return { success: false, error: data.description || `HTTP ${response.status}` };
        }
    } catch (err) {
        return { success: false, error: err.message };
    }
}

// ── Send message to Telegram ─────────────────────────────────
// chatId is passed at runtime from the popup input
// ipResults: array of { ip, server, serverDown, target, reallySent }
async function sendTelegramReport(drop, totalDrops, ipResults, chatId, toleranceRate = 0, downServers = [], processType = 'passive') {
    const message = buildTelegramMessage(drop, totalDrops, ipResults, toleranceRate, downServers, processType);

    // If message exceeds Telegram's limit, send as .txt file instead
    if (message.length > 4090) {
        return sendTelegramReportAsFile(drop, totalDrops, ipResults, chatId, toleranceRate, downServers, processType);
    }

    try {
        const response = await fetch(
            `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
            {
                method  : 'POST',
                headers : { 'Content-Type': 'application/json' },
                body    : JSON.stringify({
                    chat_id    : chatId,
                    text       : message,
                    parse_mode : 'Markdown'
                })
            }
        );

        const data = await response.json();

        if (response.ok && data.ok) {
            return { success: true };
        } else {
            return { success: false, error: data.description || `HTTP ${response.status}` };
        }
    } catch (err) {
        return { success: false, error: err.message };
    }
}