const GOOGLE_SHEETS_CONFIG = {
  spreadsheetId: "1GHQMEQ73FYG_FAm6oghEVcYZpWHhnhzCNooKn5mvvf8",
  credentialsFile: "queues-monitor.json"
};


const GOOGLE_SHEETS_CREDENTIALS = {
  "type": "service_account",
  "project_id": "omega-moonlight-468714-t6",
  "private_key_id": "15021df993e115c2c66c42dc444a0e616d4bde66",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCcjWtRGril/P2n\nQOH7q+C0uspagFk4QgBvIP5dHWBVRB2Zwj6qhs9/sRlvYPg/5D+UWQWSP5MojNJJ\nzga0o/mK2RxIIRWv0GFn9WAyP+tP3aJ6hEg3f2x2DRvHik+T2t8dW4E5SxQupB6G\nHkv01GpbnCrt5GKbe/mLMV9KASdtJRArFraJbeKt24Qqa0w2EU6R+d5KK5XqSotW\nU/XgLTU6LdrO6nTHan7cFmsUsz+hmXbCoYgmQqoOn7Vp7po6NP7DM8fO0pu9tHjA\nsZSIxA+0NNz7uU+VBkwzlgrfL/wiVFzmhBlPo8Pl11AOLJXKBCgGO27Anwi9PcjM\nXMQU+QVTAgMBAAECggEASQ/A8WF4olK/KGLh9FvjK0Vvcawrt1MqM7LgsyEmF7UJ\n4XvjVh9DUJMczTuir+K8f2XKcVYFPiv2aiZiP8S1DcVEay8xmVM1WliMU/c7wRKt\nJON+dpQb0L5OZCIbAGRpsyBE3zG4UgobCrmx9il6F5X6/PoUwP6rV/grQfTm6wrh\nsd1JUnWLgQea5VAormi0O4VYdtFz2IOQVC1TTxGsy3ULajTf2lE6te58KIZZpv7a\nxCodjhbV2xaL4Y0iJ2JVor/6QFEhPrhH2wQZLEZMj5VGhFy4L8UIkhiq1aMhXs/u\nk+zsH4FvYQMM0qi+QoZiU/aCx0QUHU65oR/LH6ROYQKBgQDKNCIOIamfANKjR9in\niQ5Al8NJeCfN5685ZSly89czhySDGnFGzlwpe032qIhyR76NZpQtHvBbCfcrJlRa\nomw1Xa6R+Oa+1ESw9yO+0qkD8SzOoRZUADYEkO/HhNxAURwTI5JS2m2lEmKlzxXk\nVUK0dW/BUwy/3krvnrDrTQ7ZIQKBgQDGNAgWUV6lDknrAlyOdyxJwhInwhdx95JY\nN6+fncm8PF006KuZjxmIRTcBNJtxoCzqC7bDGngA2gKMAzh0vw5tz8FfqpQR2ElN\nkP+cTG0wt16IquccGlrSMN7C0zgbxWyOLcy96adxSZgp2nfoMHa73eSRWCurcfGM\nHxdnNHyL8wKBgQCDVV81PIoWm4s0wKqpDq0yKSCPrLp10+EM73b/kf+aGVIO0XL3\n4Xsc+ljGN+sABzduUk02DV1iVFO1NB0gDVUpSGLlrvv4wJipNKyD+gILbG+E+j4t\na0Gqr5T+S35fTA9nIvicVgFXcVyfg6UdfH9qBMkEkXO7f5++iZ0yCAf34QKBgFB/\nZ11xFMhigkDxR5gQ7KrUKD1/hbgivYwYqbphAkLyHUTUzoTiapM+0TUrIYrHbBZu\nRX797Akkge5NjItV4U1WGIp7JAIPXs4i+r2HCL3Fa56EErMGPSaq9H4Z/OrChvFD\nxqjHEdtf8W3mLdbegAqS9zbUoX/TGjA3nHCtD3xjAoGANVOpOCnwOcXq0i6a9yRe\nul7vLNOd5jiRtnOD6dcisysu7vtMihX8OsrBLNne5R0RXwp02M0SL6UEq4AbmZYW\nreSkqmEoAPcaht3Ul1imr3RrmE4c2oho1SYWu+0TRnF4p/0Lxg1k41WfV+A0Gav7\n7uGIz33zuDfvpOmpR0UAp1c=\n-----END PRIVATE KEY-----\n",
  "client_email": "save-queues@omega-moonlight-468714-t6.iam.gserviceaccount.com",
  "client_id": "117659096978759170852",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/save-queues%40omega-moonlight-468714-t6.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};