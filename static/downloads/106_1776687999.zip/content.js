// Wait a bit in case the table/buttons load dynamically
window.addEventListener('load', () => {
  setTimeout(injectButton, 1000);
});

function injectButton() {
  const dkimButton = document.getElementById('test-dkim');
  if (!dkimButton) {
    console.log('DKIM button not found — page may not be fully loaded');
    return;
  }

  if (document.getElementById('copy-ips-wrapper')) {
    return;
  }

  // Wrapper
  const wrapper = document.createElement('div');
  wrapper.id = 'copy-ips-wrapper';
  wrapper.style.display = 'inline-flex';
  wrapper.style.alignItems = 'center';
  wrapper.style.marginLeft = '5px';

  // Copy button
  const mainBtn = document.createElement('button');
  mainBtn.type = 'button';
  mainBtn.className = 'btn btn-success';
  mainBtn.innerHTML = '<i class="fa fa-save"></i> Copy';

  // Separator input
  const input = document.createElement('input');
  input.type = 'text';
  input.placeholder = ';';
  input.value = ';'; // default
  input.style.width = '50px';
  input.style.marginLeft = '5px';
  input.style.padding = '4px';
  input.style.border = '1px solid #ccc';
  input.style.borderRadius = '4px';

  // Copy logic
  mainBtn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();

    const rows = document.querySelectorAll('#rdns-table tbody tr');
    const lines = [];

    let separator = input.value;
    if (!separator) separator = ';'; // fallback

    rows.forEach(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 4) {
        const server  = cells[0].textContent.trim();
        const ip      = cells[1].textContent.trim();
        const rdns    = cells[2].textContent.trim();
        const sttatus = cells[3].textContent.trim();

        lines.push(`${server}${separator}${ip}${separator}${rdns}${separator}${sttatus}`);
      }
    });

    if (lines.length === 0) {
      alert('No data found in the table!');
      return;
    }

    const output = lines.join('\n');

    // Copy (fallback)
    const textarea = document.createElement('textarea');
    textarea.value = output;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();

    let copied = false;
    try {
      copied = document.execCommand('copy');
    } catch (err) {
      console.error('execCommand failed:', err);
    }
    document.body.removeChild(textarea);

    // Feedback
    const originalText = mainBtn.innerHTML;
    if (copied) {
      mainBtn.innerHTML = '<i class="fa fa-check"></i> Copied!';
      setTimeout(() => {
        mainBtn.innerHTML = originalText;
      }, 2000);
    } else {
      mainBtn.innerHTML = '<i class="fa fa-times"></i> Failed!';
      setTimeout(() => {
        mainBtn.innerHTML = originalText;
      }, 2000);
    }

    navigator.clipboard.writeText(output).catch(() => {});
  });

  // Assemble
  wrapper.appendChild(mainBtn);
  wrapper.appendChild(input);

  dkimButton.parentNode.insertBefore(wrapper, dkimButton.nextSibling);
}